// MatchaMap v2 screens (revised based on user feedback)
// 14 screens total — softer/whiter palette, login replaces preference, mini-SNS feed, country wishlist

// ─────────────────────────────────────────────────────────────
// 01. Splash (lighter)
// ─────────────────────────────────────────────────────────────
const Screen2Splash = () => (
  <Phone2 bg={MM2.cream}>
    <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 40 }}>
      <div style={{ position: 'relative', marginBottom: 26 }}>
        <svg width="84" height="100" viewBox="0 0 84 100">
          <path d="M42 6 C18 6, 4 24, 4 46 C4 70, 42 96, 42 96 C42 96, 80 70, 80 46 C80 24, 66 6, 42 6 Z" fill={MM2.deep}/>
          <path d="M22 56 C22 36, 36 24, 60 24 C58 46, 44 56, 22 56 Z" fill={MM2.matchaSoft} opacity="0.95"/>
          <path d="M22 56 Q40 46, 56 30" stroke={MM2.deep} strokeWidth="0.8" fill="none" opacity="0.4"/>
        </svg>
      </div>
      <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 40, fontWeight: 700, color: MM2.deep, letterSpacing: '-0.02em' }}>말차맵</div>
      <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 11, color: MM2.muted, letterSpacing: '0.3em', marginTop: 8 }}>MATCHAMAP</div>
      <div style={{ fontSize: 14, color: MM2.text, marginTop: 26, textAlign: 'center', lineHeight: 1.7, maxWidth: 280 }}>
        세상의 말차를<br/>한 잔씩 모아두는 곳
      </div>
    </div>
    <div style={{ position: 'absolute', bottom: 50, left: 0, right: 0, textAlign: 'center', fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM2.muted, letterSpacing: '0.2em' }}>EST. 2025 · KYOTO</div>
    <StatusBar2/>
    <HomeIndicator2/>
  </Phone2>
);

// ─────────────────────────────────────────────────────────────
// 02. Login — Apple / Passkey
// ─────────────────────────────────────────────────────────────
const Screen2Login = () => (
  <Phone2 bg={MM2.bg}>
    <StatusBar2/>
    <div style={{ padding: '40px 28px 0', display: 'flex', flexDirection: 'column', height: 'calc(100% - 54px)' }}>
      {/* Brand */}
      <div style={{ marginTop: 30 }}>
        <svg width="44" height="52" viewBox="0 0 84 100">
          <path d="M42 6 C18 6, 4 24, 4 46 C4 70, 42 96, 42 96 C42 96, 80 70, 80 46 C80 24, 66 6, 42 6 Z" fill={MM2.deep}/>
          <path d="M22 56 C22 36, 36 24, 60 24 C58 46, 44 56, 22 56 Z" fill={MM2.matchaSoft}/>
        </svg>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 32, fontWeight: 700, color: MM2.deep, marginTop: 24, lineHeight: 1.2 }}>
          말차맵에<br/>오신 걸 환영해요
        </div>
        <div style={{ fontSize: 14, color: MM2.muted, marginTop: 12, lineHeight: 1.6 }}>
          로그인하면 마신 말차와 위시리스트를<br/>모든 기기에서 동기화할 수 있어요.
        </div>
      </div>

      {/* Auth options */}
      <div style={{ marginTop: 'auto', marginBottom: 20 }}>
        {/* Apple */}
        <button style={{ width: '100%', height: 56, borderRadius: 28, background: '#000', color: '#fff', border: 'none', fontSize: 15, fontWeight: 600, fontFamily: 'inherit', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginBottom: 12 }}>
          <svg width="18" height="22" viewBox="0 0 16 20" fill="#fff"><path d="M11.7 10.6c0-2.3 1.9-3.4 2-3.4-1.1-1.6-2.7-1.8-3.3-1.8-1.4-.1-2.7.8-3.4.8-.7 0-1.8-.8-3-.8-1.6 0-3 .9-3.8 2.3-1.6 2.8-.4 7 1.2 9.3.8 1.1 1.7 2.4 2.9 2.3 1.2 0 1.6-.7 3-.7 1.4 0 1.8.7 3 .7 1.2 0 2-1.1 2.8-2.3.9-1.3 1.2-2.6 1.3-2.7-.1 0-2.5-1-2.5-3.7zM9.5 3.8c.6-.8 1.1-1.9 1-3-.9 0-2.1.6-2.7 1.4-.6.7-1.2 1.8-1 2.9 1 .1 2.1-.5 2.7-1.3z"/></svg>
          Apple로 계속하기
        </button>

        {/* Passkey */}
        <button style={{ width: '100%', height: 56, borderRadius: 28, background: '#fff', color: MM2.deep, border: `1.5px solid ${MM2.deep}`, fontSize: 15, fontWeight: 600, fontFamily: 'inherit', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, position: 'relative' }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={MM2.deep} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="9" cy="11" r="4"/>
            <path d="M13 11h8M17 8v6M19 11v3"/>
          </svg>
          패스키로 계속하기
        </button>

        {/* Passkey trust note */}
        <div style={{ marginTop: 16, padding: 14, background: MM2.matchaPale, borderRadius: 12, display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <div style={{ width: 24, height: 24, borderRadius: '50%', background: MM2.matcha, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1 }}>
            <Icon name="check" size={13} color="#fff" strokeWidth={2.5}/>
          </div>
          <div style={{ fontSize: 12, color: MM2.deep, lineHeight: 1.55 }}>
            <span style={{ fontWeight: 700 }}>패스키는 더 안전해요</span><br/>
            <span style={{ color: MM2.text }}>비밀번호 없이 Face ID나 Touch ID로 로그인하고, 피싱에 강하며 기기에만 안전하게 저장돼요.</span>
          </div>
        </div>

        {/* Divider */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '20px 0 14px' }}>
          <div style={{ flex: 1, height: 1, background: MM2.line }}/>
          <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM2.muted, letterSpacing: '0.2em' }}>OR</span>
          <div style={{ flex: 1, height: 1, background: MM2.line }}/>
        </div>

        <button style={{ width: '100%', padding: '12px 0', background: 'transparent', color: MM2.text, border: 'none', fontSize: 13, fontFamily: 'inherit', textDecoration: 'underline', textUnderlineOffset: 4, textDecorationColor: MM2.line }}>
          이메일로 가입하기
        </button>
      </div>

      <div style={{ paddingBottom: 30, fontSize: 10.5, color: MM2.muted, textAlign: 'center', lineHeight: 1.6 }}>
        계속하면 <span style={{ color: MM2.deep, textDecoration: 'underline', textUnderlineOffset: 2 }}>이용약관</span> 및 <span style={{ color: MM2.deep, textDecoration: 'underline', textUnderlineOffset: 2 }}>개인정보 처리방침</span>에<br/>동의하는 것으로 간주돼요.
      </div>
    </div>
    <HomeIndicator2/>
  </Phone2>
);

// ─────────────────────────────────────────────────────────────
// 03. Location permission (with Lottie)
// ─────────────────────────────────────────────────────────────
const Screen2Location = () => (
  <Phone2 bg={MM2.bg}>
    <StatusBar2/>
    <div style={{ padding: '20px 24px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <Icon name="arrow-left" size={22} color={MM2.text}/>
      <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 11, color: MM2.muted }}>2 / 2</span>
      <div style={{ width: 22 }}/>
    </div>
    <div style={{ padding: '40px 32px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <div style={{ marginBottom: 56 }}>
        <LottiePlaceholder size={220} label="LOTTIE · 말차잎 회전 애니메이션"/>
      </div>
      <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 26, fontWeight: 700, color: MM2.deep, lineHeight: 1.3 }}>
        주변의 말차를<br/>발견하세요
      </div>
      <div style={{ fontSize: 14, color: MM2.muted, marginTop: 14, lineHeight: 1.7, maxWidth: 280 }}>
        위치 권한을 허용하면 지금 있는 곳<br/>근처의 말차 매장을 추천해드려요.
      </div>
    </div>
    <div style={{ position: 'absolute', bottom: 60, left: 24, right: 24 }}>
      <button style={{ width: '100%', height: 54, borderRadius: 28, background: MM2.deep, color: '#fff', border: 'none', fontSize: 15, fontWeight: 600, fontFamily: 'inherit', marginBottom: 8 }}>위치 허용하기</button>
      <button style={{ width: '100%', height: 48, borderRadius: 28, background: 'transparent', color: MM2.muted, border: 'none', fontSize: 14, fontFamily: 'inherit' }}>나중에 설정</button>
    </div>
    <HomeIndicator2/>
  </Phone2>
);

// ─────────────────────────────────────────────────────────────
// 04. Map World (no Lottie — just markers)
// ─────────────────────────────────────────────────────────────
const Screen2MapWorld = () => (
  <Phone2 bg={MM2.bg}>
    <WorldMap2/>
    <StatusBar2/>
    <div style={{ position: 'absolute', top: 60, left: 16, right: 16, zIndex: 5 }}>
      <div style={{ background: 'rgba(255,255,255,0.96)', backdropFilter: 'blur(12px)', borderRadius: 14, padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 10, boxShadow: '0 4px 16px rgba(0,0,0,0.06)' }}>
        <Icon name="search" size={18} color={MM2.muted}/>
        <div style={{ flex: 1, fontSize: 14, color: MM2.muted }}>도시, 매장, 말차 종류 검색</div>
        <div style={{ width: 28, height: 28, borderRadius: 8, background: MM2.deep, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="sliders" size={14} color="#fff"/></div>
      </div>
      <div style={{ display: 'flex', gap: 8, marginTop: 10, overflow: 'hidden' }}>
        {['전체', '🇯🇵 일본', '🇰🇷 한국', '🇺🇸 미국', '🇪🇺 유럽'].map((r,i) => (
          <div key={i} style={{ padding: '7px 14px', borderRadius: 20, fontSize: 12, fontWeight: 500, background: i === 0 ? MM2.deep : 'rgba(255,255,255,0.92)', color: i === 0 ? '#fff' : MM2.text, backdropFilter: 'blur(8px)', whiteSpace: 'nowrap', boxShadow: '0 2px 6px rgba(0,0,0,0.04)' }}>{r}</div>
        ))}
      </div>
    </div>
    {/* markers only — no Lottie/glow */}
    <div style={{ position: 'absolute', top: '32%', left: '88%', zIndex: 4 }}><MatchaPin2 size={26} grade="S"/></div>
    <div style={{ position: 'absolute', top: '34%', left: '82%', zIndex: 4 }}><MatchaPin2 size={20} grade="A"/></div>
    <div style={{ position: 'absolute', top: '38%', left: '78%', zIndex: 4 }}><MatchaPin2 size={18} grade="B"/></div>
    <div style={{ position: 'absolute', top: '28%', left: '50%', zIndex: 4 }}><MatchaPin2 size={22} grade="A"/></div>
    <div style={{ position: 'absolute', top: '32%', left: '53%', zIndex: 4 }}><MatchaPin2 size={18} grade="B"/></div>
    <div style={{ position: 'absolute', top: '32%', left: '20%', zIndex: 4 }}><MatchaPin2 size={24} grade="A"/></div>
    <div style={{ position: 'absolute', top: '38%', left: '22%', zIndex: 4 }}><MatchaPin2 size={18} grade="B"/></div>
    <div style={{ position: 'absolute', top: '52%', left: '43%', zIndex: 4 }}><MatchaPin2 size={18} grade="C"/></div>
    {/* Cluster */}
    <div style={{ position: 'absolute', top: '30%', left: '70%', zIndex: 4 }}>
      <div style={{ width: 42, height: 42, borderRadius: '50%', background: MM2.matcha, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13, border: '3px solid #fff', boxShadow: '0 4px 10px rgba(0,0,0,0.12)' }}>247</div>
    </div>
    {/* Stats banner */}
    <div style={{ position: 'absolute', bottom: 180, left: 16, right: 16, background: '#fff', borderRadius: 16, padding: 16, boxShadow: '0 8px 20px rgba(0,0,0,0.06)' }}>
      <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, letterSpacing: '0.2em', color: MM2.rose, marginBottom: 6 }}>지금 이 순간</div>
      <div style={{ fontSize: 15, fontWeight: 600, color: MM2.deep, lineHeight: 1.5 }}>
        전 세계 <span style={{ color: MM2.rose }}>1,847개</span> 매장에서<br/>말차가 우려지고 있어요
      </div>
      <div style={{ display: 'flex', gap: 16, marginTop: 12, paddingTop: 12, borderTop: `1px solid ${MM2.lineSoft}` }}>
        <div><div style={{ fontSize: 18, fontWeight: 700, color: MM2.deep, fontFamily: 'Noto Serif KR, serif' }}>43</div><div style={{ fontSize: 10, color: MM2.muted }}>국가</div></div>
        <div><div style={{ fontSize: 18, fontWeight: 700, color: MM2.deep, fontFamily: 'Noto Serif KR, serif' }}>1,847</div><div style={{ fontSize: 10, color: MM2.muted }}>매장</div></div>
        <div><div style={{ fontSize: 18, fontWeight: 700, color: MM2.deep, fontFamily: 'Noto Serif KR, serif' }}>12k</div><div style={{ fontSize: 10, color: MM2.muted }}>리뷰</div></div>
      </div>
    </div>
    <TabBar2 active="map"/>
    <HomeIndicator2/>
  </Phone2>
);

// ─────────────────────────────────────────────────────────────
// 05. Map City zoom
// ─────────────────────────────────────────────────────────────
const Screen2MapCity = () => (
  <Phone2>
    <CityMap2>
      <div style={{ position: 'absolute', top: '15%', left: '14%', fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM2.muted, letterSpacing: '0.15em' }}>YOYOGI PARK</div>
      <div style={{ position: 'absolute', top: '50%', left: '30%', fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM2.text, letterSpacing: '0.1em', fontWeight: 500 }}>SHIBUYA</div>
      <div style={{ position: 'absolute', top: '30%', left: '72%', fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM2.text, letterSpacing: '0.1em', fontWeight: 500 }}>OMOTESANDO</div>
      <div style={{ position: 'absolute', top: '32%', left: '38%' }}><MatchaPin2 size={36} grade="S" glow/></div>
      <div style={{ position: 'absolute', top: '48%', left: '52%' }}><MatchaPin2 size={32} grade="A"/></div>
      <div style={{ position: 'absolute', top: '60%', left: '32%' }}><MatchaPin2 size={28} grade="A"/></div>
      <div style={{ position: 'absolute', top: '24%', left: '68%' }}><MatchaPin2 size={28} grade="B"/></div>
      <div style={{ position: 'absolute', top: '70%', left: '60%' }}><MatchaPin2 size={26} grade="C"/></div>
      <div style={{ position: 'absolute', top: '40%', left: '78%' }}><MatchaPin2 size={26} grade="B"/></div>
    </CityMap2>
    <StatusBar2/>
    <div style={{ position: 'absolute', top: 60, left: 16, right: 16, zIndex: 5 }}>
      <div style={{ background: '#fff', borderRadius: 14, padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 10, boxShadow: '0 4px 12px rgba(0,0,0,0.06)' }}>
        <Icon name="arrow-left" size={18} color={MM2.text}/>
        <div style={{ flex: 1, fontSize: 14, fontWeight: 500, color: MM2.deep }}>도쿄 시부야</div>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM2.muted }}>24 매장</div>
      </div>
    </div>
    <div style={{ position: 'absolute', top: 118, left: 16, right: 16, display: 'flex', gap: 6, zIndex: 5 }}>
      {[{l:'정렬', i:'sort'},{l:'등급'},{l:'영업중'},{l:'우스차'}].map((p,i) => (
        <div key={i} style={{ padding: '7px 12px', borderRadius: 16, fontSize: 12, fontWeight: 500, background: '#fff', boxShadow: '0 2px 4px rgba(0,0,0,0.04)', display: 'flex', alignItems: 'center', gap: 4, color: MM2.text }}>
          {p.i && <Icon name={p.i} size={12} color={MM2.text}/>}
          {p.l}
        </div>
      ))}
    </div>
    <div style={{ position: 'absolute', top: 200, right: 16, display: 'flex', flexDirection: 'column', gap: 8, zIndex: 5 }}>
      {['plus', 'world-pin', 'compass'].map((i,k) => (
        <div key={k} style={{ width: 40, height: 40, borderRadius: 12, background: '#fff', boxShadow: '0 2px 6px rgba(0,0,0,0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Icon name={i} size={18} color={MM2.deep}/>
        </div>
      ))}
    </div>
    <div style={{ position: 'absolute', bottom: 100, left: 0, right: 0, display: 'flex', gap: 10, paddingLeft: 16, overflow: 'hidden', zIndex: 4 }}>
      {[
        { name: '茶筅 시부야', grade: 'S', dist: '0.3km', rating: 4.9, tone: 'matcha' },
        { name: 'Marufuji', grade: 'A', dist: '0.5km', rating: 4.7, tone: 'cream' },
      ].map((s,i) => (
        <div key={i} style={{ width: 280, background: '#fff', borderRadius: 16, padding: 12, display: 'flex', gap: 12, boxShadow: '0 4px 14px rgba(0,0,0,0.06)', flexShrink: 0 }}>
          <Photo w={72} h={72} tone={s.tone} label={s.name} radius={10}/>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <GradeChip2 grade={s.grade} size="sm"/>
              <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM2.muted }}>{s.dist}</div>
            </div>
            <div style={{ fontSize: 14, fontWeight: 600, color: MM2.deep, marginTop: 4 }}>{s.name}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 4 }}>
              <Stars value={s.rating} size={11}/>
              <span style={{ fontSize: 11, color: MM2.muted }}>{s.rating}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
    <TabBar2 active="map"/>
    <HomeIndicator2/>
  </Phone2>
);

// ─────────────────────────────────────────────────────────────
// 06. Map preview (store mini-card)
// ─────────────────────────────────────────────────────────────
const Screen2MapPreview = () => (
  <Phone2>
    <CityMap2>
      <div style={{ position: 'absolute', top: '32%', left: '38%' }}><MatchaPin2 size={48} grade="S" glow/></div>
      <div style={{ position: 'absolute', top: '48%', left: '52%' }}><MatchaPin2 size={26} grade="A"/></div>
      <div style={{ position: 'absolute', top: '24%', left: '68%' }}><MatchaPin2 size={24} grade="B"/></div>
    </CityMap2>
    <StatusBar2/>
    <div style={{ position: 'absolute', top: 60, left: 16, right: 16, zIndex: 5 }}>
      <div style={{ background: '#fff', borderRadius: 14, padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 10, boxShadow: '0 4px 12px rgba(0,0,0,0.06)' }}>
        <Icon name="arrow-left" size={18} color={MM2.text}/>
        <div style={{ flex: 1, fontSize: 14, fontWeight: 500, color: MM2.deep }}>茶筅 시부야</div>
        <Icon name="bookmark" size={18} color={MM2.text}/>
      </div>
    </div>
    {/* Store preview card */}
    <div style={{ position: 'absolute', bottom: 100, left: 16, right: 16, background: '#fff', borderRadius: 18, overflow: 'hidden', boxShadow: '0 12px 32px rgba(0,0,0,0.1)' }}>
      <Photo h={150} tone="matcha" label="茶筅 시부야"/>
      <div style={{ padding: '14px 16px 16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
          <GradeChip2 grade="S" size="sm"/>
          <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM2.muted, letterSpacing: '0.15em' }}>TEA HOUSE · ¥¥¥¥</span>
        </div>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 22, fontWeight: 700, color: MM2.deep, lineHeight: 1.2 }}>茶筅 시부야</div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginTop: 8 }}>
          <Stars value={4.9} size={13}/>
          <span style={{ fontSize: 12, color: MM2.deep, fontWeight: 600 }}>4.9</span>
          <span style={{ fontSize: 11, color: MM2.muted }}>(1,820)</span>
          <div style={{ width: 1, height: 10, background: MM2.line }}/>
          <span style={{ fontSize: 11, color: MM2.matcha, fontWeight: 600 }}>● 영업중</span>
        </div>
        <div style={{ fontSize: 12, color: MM2.text, marginTop: 10, lineHeight: 1.5 }}>
          시부야의 정통 다실. 200년 된 우지 농원의 코이차를 맛볼 수 있어요.
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
          <button style={{ flex: 1, padding: '12px 0', borderRadius: 14, background: MM2.deep, color: '#fff', border: 'none', fontSize: 13, fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
            <Icon name="compass" size={14} color="#fff"/> 길찾기 · 14분
          </button>
          <button style={{ width: 48, padding: '12px 0', borderRadius: 14, background: '#fff', border: `1px solid ${MM2.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="phone" size={16} color={MM2.deep}/>
          </button>
        </div>
      </div>
    </div>
    <TabBar2 active="map"/>
    <HomeIndicator2/>
  </Phone2>
);

// ─────────────────────────────────────────────────────────────
// 07. Store Detail (whiter, lighter)
// ─────────────────────────────────────────────────────────────
const Screen2StoreDetail = () => (
  <Phone2 bg={MM2.bg}>
    <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 240, overflow: 'hidden' }}>
      <Photo w="100%" h={240} tone="matcha" label="HERO · 47 PHOTOS"/>
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(0,0,0,0.3) 0%, transparent 30%, rgba(251,250,247,1) 100%)' }}/>
    </div>
    <StatusBar2/>
    <div style={{ position: 'absolute', top: 60, left: 16, right: 16, display: 'flex', justifyContent: 'space-between', zIndex: 10 }}>
      <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="arrow-left" size={16} color={MM2.deep}/></div>
      <div style={{ display: 'flex', gap: 8 }}>
        <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="share" size={15} color={MM2.deep}/></div>
        <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="bookmark" size={15} color={MM2.deep}/></div>
      </div>
    </div>
    <div style={{ position: 'absolute', top: 220, left: 0, right: 0, bottom: 0, padding: '20px 20px 100px', overflow: 'auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
        <GradeChip2 grade="S" size="sm"/>
        <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM2.muted, letterSpacing: '0.15em' }}>TEA HOUSE · ¥¥¥¥</span>
      </div>
      <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 26, fontWeight: 700, color: MM2.deep, lineHeight: 1.2 }}>宇治園 시부야</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 10 }}>
        <Stars value={4.8} size={13}/>
        <span style={{ fontSize: 14, fontWeight: 700, color: MM2.deep }}>4.8</span>
        <span style={{ fontSize: 11, color: MM2.muted }}>(2,341)</span>
        <div style={{ width: 1, height: 12, background: MM2.line }}/>
        <span style={{ fontSize: 11, color: MM2.matcha, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 3 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: MM2.matcha }}/>영업중
        </span>
        <span style={{ fontSize: 11, color: MM2.muted }}>· 21:00 마감</span>
      </div>
      {/* Quick actions */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 8, marginTop: 18 }}>
        {[{i:'compass',l:'길찾기',h:true},{i:'phone',l:'전화'},{i:'globe',l:'웹사이트'},{i:'share',l:'공유'}].map(a => (
          <div key={a.l} style={{ padding: '10px 4px', background: a.h ? MM2.deep : '#fff', color: a.h ? '#fff' : MM2.deep, borderRadius: 12, border: a.h ? 'none' : `1px solid ${MM2.line}`, textAlign: 'center', boxShadow: a.h ? 'none' : '0 1px 3px rgba(0,0,0,0.03)' }}>
            <Icon name={a.i} size={16} color={a.h ? '#fff' : MM2.deep}/>
            <div style={{ fontSize: 10, marginTop: 4, fontWeight: 500 }}>{a.l}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 24, marginTop: 22, borderBottom: `1px solid ${MM2.line}` }}>
        {['소개', '메뉴', '리뷰 (2,341)'].map((t, i) => (
          <div key={i} style={{ padding: '10px 0', fontSize: 13, fontWeight: i === 0 ? 700 : 500, color: i === 0 ? MM2.deep : MM2.muted, borderBottom: i === 0 ? `2px solid ${MM2.deep}` : 'none', marginBottom: -1 }}>{t}</div>
        ))}
      </div>

      <div style={{ marginTop: 18, fontSize: 13, color: MM2.text, lineHeight: 1.7 }}>
        시부야 한복판, 14층 고요한 공간에서 우지의 정통 다도식을 만나는 곳. 200년 역사의 농원에서 직접 수확한 첫물 잎을 매일 갈아 코이차를 우려냅니다.
      </div>

      {/* Address mini-map */}
      <div style={{ marginTop: 16, display: 'flex', gap: 10, padding: 12, background: '#fff', borderRadius: 12, border: `1px solid ${MM2.lineSoft}` }}>
        <div style={{ width: 60, height: 60, borderRadius: 8, overflow: 'hidden', position: 'relative', flexShrink: 0 }}>
          <CityMap2><div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-100%)' }}><MatchaPin2 size={20} grade="S"/></div></CityMap2>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM2.muted, letterSpacing: '0.1em' }}>ADDRESS</div>
          <div style={{ fontSize: 12, color: MM2.text, marginTop: 2, lineHeight: 1.4 }}>東京都渋谷区道玄坂2-29-5<br/>渋谷スクランブルスクエア 14F</div>
        </div>
      </div>

      {/* Hours preview */}
      <div style={{ marginTop: 12, padding: 14, background: '#fff', borderRadius: 12, border: `1px solid ${MM2.lineSoft}`, display: 'flex', alignItems: 'center', gap: 10 }}>
        <Icon name="clock" size={14} color={MM2.matcha}/>
        <span style={{ fontSize: 12, fontWeight: 600, color: MM2.matcha }}>영업중</span>
        <span style={{ fontSize: 11, color: MM2.muted, flex: 1 }}>오후 9시에 닫음 · 화 ~ 일</span>
        <Icon name="chevron-down" size={14} color={MM2.muted}/>
      </div>

      {/* Attributes */}
      <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM2.muted, letterSpacing: '0.15em', marginTop: 22, marginBottom: 10 }}>매장 속성</div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
        {[
          { l:'테이크아웃', y:true }, { l:'예약 가능', y:true },
          { l:'카드 결제', y:true }, { l:'Wi-Fi 무료', y:true },
          { l:'휠체어 접근', y:true }, { l:'야외석', y:false },
        ].map((a,i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 10px', background: '#fff', borderRadius: 8, border: `1px solid ${MM2.lineSoft}` }}>
            <Icon name={a.y ? 'check' : 'close'} size={12} color={a.y ? MM2.matcha : MM2.muted}/>
            <span style={{ fontSize: 11, color: a.y ? MM2.text : MM2.muted, textDecoration: a.y ? 'none' : 'line-through' }}>{a.l}</span>
          </div>
        ))}
      </div>
    </div>
    <TabBar2 active="map"/>
    <HomeIndicator2/>
  </Phone2>
);

// ─────────────────────────────────────────────────────────────
// 08. Store Reviews tab
// ─────────────────────────────────────────────────────────────
const Screen2Reviews = () => (
  <Phone2 bg={MM2.bg}>
    <StatusBar2/>
    <div style={{ padding: '8px 16px 14px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: `1px solid ${MM2.lineSoft}` }}>
      <Icon name="arrow-left" size={20} color={MM2.text}/>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: MM2.deep }}>宇治園 시부야</div>
        <div style={{ fontSize: 10, color: MM2.muted }}>리뷰 2,341</div>
      </div>
      <Icon name="edit" size={18} color={MM2.deep}/>
    </div>
    {/* Rating summary */}
    <div style={{ padding: '20px 20px 16px', display: 'flex', gap: 16, alignItems: 'center' }}>
      <div>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 44, fontWeight: 700, color: MM2.deep, lineHeight: 1 }}>4.8</div>
        <Stars value={4.8} size={12}/>
        <div style={{ fontSize: 10, color: MM2.muted, marginTop: 4, fontFamily: 'IBM Plex Mono, monospace' }}>2,341 REVIEWS</div>
      </div>
      <div style={{ flex: 1 }}>
        {[5,4,3,2,1].map(n => {
          const w = [82,12,4,1,1][5-n];
          return (
            <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
              <span style={{ fontSize: 10, color: MM2.muted, width: 8 }}>{n}</span>
              <div style={{ flex: 1, height: 4, background: MM2.lineSoft, borderRadius: 2 }}>
                <div style={{ width: `${w}%`, height: '100%', background: MM2.matcha, borderRadius: 2 }}/>
              </div>
              <span style={{ fontSize: 10, color: MM2.muted, width: 28, fontFamily: 'IBM Plex Mono, monospace', textAlign: 'right' }}>{w}%</span>
            </div>
          );
        })}
      </div>
    </div>
    {/* Filter chips */}
    <div style={{ padding: '4px 16px 14px', display: 'flex', gap: 6, borderBottom: `1px solid ${MM2.lineSoft}` }}>
      {[{l:'전체',c:'2,341',sel:true},{l:'사진',c:'847'},{l:'5점',c:'1,920'},{l:'친구',c:'12'}].map((c,i) => (
        <div key={i} style={{ padding: '6px 12px', borderRadius: 14, fontSize: 11, fontWeight: 500, background: c.sel ? MM2.deep : '#fff', color: c.sel ? '#fff' : MM2.text, border: c.sel ? 'none' : `1px solid ${MM2.line}`, display: 'flex', gap: 5 }}>
          <span>{c.l}</span><span style={{ opacity: 0.6, fontFamily: 'IBM Plex Mono, monospace' }}>{c.c}</span>
        </div>
      ))}
    </div>
    {/* Reviews list */}
    <div style={{ padding: '6px 20px 100px', overflow: 'auto', height: 'calc(100% - 290px)' }}>
      {[
        { n: '서연', d: '2일 전', r: 5, t: '코이차 한 잔에 반했어요', body: '정말 진하고 부드러웠어요. 화과자랑 같이 나오는 방식이 너무 우아해요. 시부야에 가면 무조건 들러요 ✨', tone: 'matcha', likes: 24 },
        { n: '지민', d: '5일 전', r: 5, t: '분위기가 정말 좋아요', body: '14층이라 시부야가 한눈에 내려다보여요. 친구랑 같이 갔는데 둘 다 만족했어요.', tone: 'cream', likes: 12 },
        { n: 'Yuki', d: '1주 전', r: 4, t: '가격은 있지만 그만큼의 가치', body: '코이차 ¥3,800은 살짝 부담스럽지만 다도식 경험으로는 충분히 가치 있어요.', tone: null, likes: 8 },
      ].map((r,i) => (
        <div key={i} style={{ padding: '16px 0', borderBottom: i < 2 ? `1px solid ${MM2.lineSoft}` : 'none' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: i === 0 ? MM2.matcha : i === 1 ? MM2.rose : MM2.gold, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 13 }}>{r.n[0]}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: MM2.deep }}>{r.n}</div>
              <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginTop: 1 }}>
                <Stars value={r.r} size={10}/>
                <span style={{ fontSize: 10, color: MM2.muted, fontFamily: 'IBM Plex Mono, monospace' }}>{r.d}</span>
              </div>
            </div>
          </div>
          <div style={{ fontSize: 13, fontWeight: 600, color: MM2.deep, marginTop: 10 }}>{r.t}</div>
          <div style={{ fontSize: 12, color: MM2.text, marginTop: 4, lineHeight: 1.6 }}>{r.body}</div>
          {r.tone && <div style={{ marginTop: 10 }}><Photo h={140} tone={r.tone} label="" radius={10}/></div>}
          <div style={{ display: 'flex', gap: 14, marginTop: 10 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, color: MM2.muted, fontSize: 11 }}><Icon name="heart" size={13}/> {r.likes}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, color: MM2.muted, fontSize: 11 }}><Icon name="message" size={13}/> 답글</div>
          </div>
        </div>
      ))}
    </div>
    <HomeIndicator2/>
  </Phone2>
);

// ─────────────────────────────────────────────────────────────
// 09. Search results
// ─────────────────────────────────────────────────────────────
const Screen2Search = () => (
  <Phone2 bg={MM2.bg}>
    <StatusBar2/>
    <div style={{ padding: '6px 16px 12px', display: 'flex', gap: 10, alignItems: 'center' }}>
      <Icon name="arrow-left" size={20} color={MM2.text}/>
      <div style={{ flex: 1, height: 40, borderRadius: 20, background: '#fff', border: `1px solid ${MM2.line}`, display: 'flex', alignItems: 'center', padding: '0 14px', gap: 8 }}>
        <Icon name="search" size={14} color={MM2.muted}/>
        <span style={{ fontSize: 13, color: MM2.deep, fontWeight: 500 }}>코이차</span>
        <div style={{ flex: 1 }}/>
        <Icon name="close" size={14} color={MM2.muted}/>
      </div>
      <Icon name="sliders" size={20} color={MM2.deep}/>
    </div>
    <div style={{ padding: '0 16px 8px', display: 'flex', gap: 6, overflow: 'hidden' }}>
      {[{l:'전체',c:'47',sel:true},{l:'매장',c:'24'},{l:'메뉴',c:'18'},{l:'리뷰',c:'5'}].map((c,i) => (
        <div key={i} style={{ padding: '6px 12px', borderRadius: 14, fontSize: 11, background: c.sel ? MM2.deep : '#fff', color: c.sel ? '#fff' : MM2.text, border: c.sel ? 'none' : `1px solid ${MM2.line}`, display: 'flex', gap: 4 }}>
          <span>{c.l}</span><span style={{ opacity: 0.6, fontFamily: 'IBM Plex Mono, monospace' }}>{c.c}</span>
        </div>
      ))}
    </div>
    <div style={{ padding: '12px 16px 100px', overflow: 'auto', height: 'calc(100% - 170px)' }}>
      <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM2.muted, letterSpacing: '0.2em', marginBottom: 10 }}>매장 24곳 · 거리순</div>
      {[
        { n:'宇治園 시부야', loc:'시부야, 도쿄', dist:'1.2km', g:'S', r:4.8, c:847, tone:'matcha' },
        { n:'茶筅', loc:'오모테산도, 도쿄', dist:'2.1km', g:'S', r:4.9, c:1820, tone:'cream' },
        { n:'Marufuji', loc:'에비스, 도쿄', dist:'3.4km', g:'A', r:4.7, c:512, tone:'deep' },
        { n:'Tea House Tokyo', loc:'롯폰기, 도쿄', dist:'4.8km', g:'A', r:4.6, c:340, tone:'matcha' },
      ].map((s,i) => (
        <div key={i} style={{ display: 'flex', gap: 12, padding: '12px 0', borderBottom: i < 3 ? `1px solid ${MM2.lineSoft}` : 'none', alignItems: 'center' }}>
          <Photo w={68} h={68} tone={s.tone} label="" radius={10}/>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <GradeChip2 grade={s.g} size="sm"/>
              <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM2.rose, fontWeight: 600 }}>{s.dist}</span>
            </div>
            <div style={{ fontSize: 14, fontWeight: 700, color: MM2.deep, marginTop: 3 }}>{s.n}</div>
            <div style={{ fontSize: 11, color: MM2.muted, marginTop: 1 }}>{s.loc}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 4 }}>
              <Stars value={s.r} size={11}/>
              <span style={{ fontSize: 11, color: MM2.deep, fontWeight: 600 }}>{s.r}</span>
              <span style={{ fontSize: 11, color: MM2.muted }}>({s.c})</span>
            </div>
          </div>
          <Icon name="bookmark" size={16} color={MM2.muted}/>
        </div>
      ))}
    </div>
    <TabBar2 active="map"/>
    <HomeIndicator2/>
  </Phone2>
);

// ─────────────────────────────────────────────────────────────
// 10. Review write
// ─────────────────────────────────────────────────────────────
const Screen2ReviewWrite = () => (
  <Phone2 bg={MM2.bg}>
    <StatusBar2/>
    <div style={{ padding: '8px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
      <Icon name="close" size={22} color={MM2.text}/>
      <div style={{ fontSize: 14, fontWeight: 600, color: MM2.deep }}>리뷰 작성</div>
      <button style={{ padding: '6px 14px', borderRadius: 14, background: MM2.deep, color: '#fff', border: 'none', fontSize: 12, fontWeight: 600 }}>등록</button>
    </div>
    <div style={{ padding: '16px 20px', overflow: 'auto', height: 'calc(100% - 110px)' }}>
      {/* Store row */}
      <div style={{ display: 'flex', gap: 10, padding: 12, background: '#fff', borderRadius: 12, alignItems: 'center', border: `1px solid ${MM2.lineSoft}` }}>
        <Photo w={48} h={48} tone="matcha" label="" radius={8}/>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: MM2.deep }}>宇治園 시부야</div>
          <div style={{ fontSize: 10, color: MM2.muted, marginTop: 2 }}>도쿄 · 시부야</div>
        </div>
        <Icon name="chevron-right" size={14} color={MM2.muted}/>
      </div>

      {/* Stars */}
      <div style={{ marginTop: 22, textAlign: 'center' }}>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM2.muted, letterSpacing: '0.2em' }}>전체 평점</div>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 6, marginTop: 12 }}>
          {[1,2,3,4,5].map(i => (
            <Icon key={i} name="star" size={36} color={i <= 5 ? MM2.gold : MM2.line}/>
          ))}
        </div>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 22, fontWeight: 700, color: MM2.deep, marginTop: 10 }}>완벽해요!</div>
      </div>

      {/* Photo upload */}
      <div style={{ marginTop: 24, fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM2.muted, letterSpacing: '0.2em', marginBottom: 8 }}>사진 (3 / 9)</div>
      <div style={{ display: 'flex', gap: 6 }}>
        {['matcha','cream','deep'].map((t,i) => (
          <div key={i} style={{ position: 'relative' }}>
            <Photo w={70} h={70} tone={t} label="" radius={10}/>
            <div style={{ position: 'absolute', top: 4, right: 4, width: 18, height: 18, borderRadius: '50%', background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="close" size={10} color="#fff" strokeWidth={2}/></div>
          </div>
        ))}
        <div style={{ width: 70, height: 70, borderRadius: 10, border: `1.5px dashed ${MM2.line}`, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
          <Icon name="camera" size={18} color={MM2.muted}/>
          <span style={{ fontSize: 9, color: MM2.muted }}>추가</span>
        </div>
      </div>

      {/* Tags */}
      <div style={{ marginTop: 22, fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM2.muted, letterSpacing: '0.2em', marginBottom: 8 }}>태그</div>
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        {[{l:'코이차',sel:true},{l:'정통',sel:true},{l:'분위기',sel:true},{l:'다도식'},{l:'데이트'},{l:'혼자'},{l:'가성비'}].map((t,i) => (
          <div key={i} style={{ padding: '7px 12px', borderRadius: 16, fontSize: 12, background: t.sel ? MM2.matchaPale : '#fff', color: t.sel ? MM2.deep : MM2.text, border: t.sel ? `1px solid ${MM2.matchaSoft}` : `1px solid ${MM2.line}`, fontWeight: t.sel ? 600 : 500 }}>
            {t.sel && '✓ '}{t.l}
          </div>
        ))}
      </div>

      {/* Body */}
      <div style={{ marginTop: 22, fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM2.muted, letterSpacing: '0.2em', marginBottom: 8 }}>리뷰</div>
      <div style={{ padding: 14, background: '#fff', borderRadius: 12, border: `1px solid ${MM2.lineSoft}`, fontSize: 13, color: MM2.text, lineHeight: 1.7, minHeight: 100 }}>
        코이차가 정말 진하고 부드러웠어요. 화과자랑 같이 나오는 방식이 너무 우아해요...<span style={{ background: MM2.deep, width: 1.5, height: 16, display: 'inline-block', verticalAlign: 'middle', marginLeft: 1, animation: 'mm-blink 1s infinite' }}/>
      </div>
    </div>
    <HomeIndicator2/>
  </Phone2>
);

// ─────────────────────────────────────────────────────────────
// 11. Feed (mini-SNS)
// ─────────────────────────────────────────────────────────────
const Screen2Feed = () => (
  <Phone2 bg={MM2.bg}>
    <StatusBar2/>
    {/* Header with stories */}
    <div style={{ padding: '6px 16px 14px', borderBottom: `1px solid ${MM2.lineSoft}`, background: '#fff' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 22, fontWeight: 700, color: MM2.deep }}>피드</div>
        <div style={{ display: 'flex', gap: 14 }}>
          <Icon name="search" size={20} color={MM2.deep}/>
          <Icon name="bell" size={20} color={MM2.deep}/>
        </div>
      </div>
      {/* Stories row */}
      <div style={{ display: 'flex', gap: 12, overflow: 'hidden' }}>
        {[
          { n:'내', s:false, t:'cream', plus:true },
          { n:'서연', s:true, t:'matcha' },
          { n:'지민', s:true, t:'rose' },
          { n:'Yuki', s:true, t:'deep' },
          { n:'민지', s:false, t:'cream' },
          { n:'하늘', s:true, t:'matcha' },
        ].map((u,i) => (
          <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
            <div style={{ width: 56, height: 56, borderRadius: '50%', padding: 2, background: u.s ? `linear-gradient(135deg, ${MM2.matcha}, ${MM2.rose})` : MM2.line, position: 'relative' }}>
              <div style={{ width: '100%', height: '100%', borderRadius: '50%', background: u.t === 'matcha' ? MM2.matcha : u.t === 'rose' ? MM2.rose : u.t === 'deep' ? MM2.deep : MM2.cream, border: '2px solid #fff' }}/>
              {u.plus && <div style={{ position: 'absolute', bottom: -2, right: -2, width: 20, height: 20, borderRadius: '50%', background: MM2.deep, border: '2px solid #fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="plus" size={10} color="#fff" strokeWidth={2.5}/></div>}
            </div>
            <span style={{ fontSize: 10, color: MM2.text, fontWeight: 500 }}>{u.n}</span>
          </div>
        ))}
      </div>
    </div>
    {/* Feed list */}
    <div style={{ overflow: 'auto', height: 'calc(100% - 220px)', padding: '0 0 100px' }}>
      {[
        { u:'서연', avatar:MM2.matcha, ago:'2시간 전', loc:'宇治園 시부야 · 도쿄', body:'시부야 와서 처음으로 진짜 다도식 경험. 코이차 한 잔에 마음이 차분해져요 🍵', tone:'matcha', likes:24, comments:5, country:'jp' },
        { u:'지민', avatar:MM2.rose, ago:'어제', loc:'다실 안국 · 서울', body:'안국역 작은 다실에서 첫 만남. 직접 갈아주시는 우스차가 너무 부드러웠어요.', tone:'cream', likes:42, comments:8, country:'kr' },
        { u:'Yuki', avatar:MM2.gold, ago:'2일 전', loc:'Tea Master · 교토', body:'교토 우지 본점 방문기. 200년 농원이라는 게 무슨 뜻인지 알겠어요.', tone:'deep', likes:67, comments:12, country:'jp' },
      ].map((p,i) => (
        <div key={i} style={{ borderBottom: `1px solid ${MM2.lineSoft}`, padding: '14px 16px 16px', background: '#fff', marginBottom: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 38, height: 38, borderRadius: '50%', background: p.avatar, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 14 }}>{p.u[0]}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: MM2.deep }}>{p.u}</div>
              <div style={{ fontSize: 10, color: MM2.muted, marginTop: 1, display: 'flex', alignItems: 'center', gap: 4 }}>
                <CountryFlag code={p.country} size={11}/>
                <span>{p.loc}</span>
                <span>·</span>
                <span>{p.ago}</span>
              </div>
            </div>
            <Icon name="menu" size={16} color={MM2.muted}/>
          </div>
          <div style={{ fontSize: 13, color: MM2.text, marginTop: 10, lineHeight: 1.6 }}>{p.body}</div>
          <div style={{ marginTop: 12, marginLeft: -16, marginRight: -16 }}><Photo h={300} tone={p.tone} label=""/></div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 18, marginTop: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, color: i === 1 ? MM2.rose : MM2.text }}>
              <Icon name={i === 1 ? 'heart-fill' : 'heart'} size={20} color={i === 1 ? MM2.rose : MM2.text}/>
              <span style={{ fontSize: 13, fontWeight: 600 }}>{p.likes}</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, color: MM2.text }}>
              <Icon name="message" size={19}/>
              <span style={{ fontSize: 13, fontWeight: 600 }}>{p.comments}</span>
            </div>
            <Icon name="share" size={19} color={MM2.text}/>
            <div style={{ flex: 1 }}/>
            <Icon name="bookmark" size={19} color={MM2.text}/>
          </div>
        </div>
      ))}
    </div>
    <TabBar2 active="feed"/>
    <HomeIndicator2/>
  </Phone2>
);

// ─────────────────────────────────────────────────────────────
// 12. Wishlist (with country/region grouping)
// ─────────────────────────────────────────────────────────────
const Screen2Wishlist = () => (
  <Phone2 bg={MM2.bg}>
    <StatusBar2/>
    <div style={{ padding: '6px 20px 14px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 22, fontWeight: 700, color: MM2.deep }}>위시리스트</div>
        <div style={{ display: 'flex', gap: 14 }}>
          <Icon name="grid" size={18} color={MM2.muted}/>
          <Icon name="map" size={18} color={MM2.deep}/>
        </div>
      </div>
      <div style={{ fontSize: 12, color: MM2.muted, marginTop: 4 }}>가고 싶은 매장 28곳 · 7개 국가</div>
    </div>
    {/* Mini world map header */}
    <div style={{ position: 'relative', height: 160, margin: '0 16px', borderRadius: 14, overflow: 'hidden', background: '#f1ece0' }}>
      <WorldMap2/>
      <div style={{ position: 'absolute', top: '32%', left: '78%' }}><MatchaPin2 size={18} grade="S"/></div>
      <div style={{ position: 'absolute', top: '36%', left: '76%' }}><MatchaPin2 size={16} grade="A"/></div>
      <div style={{ position: 'absolute', top: '32%', left: '50%' }}><MatchaPin2 size={16} grade="A"/></div>
      <div style={{ position: 'absolute', top: '32%', left: '20%' }}><MatchaPin2 size={16} grade="A"/></div>
      <div style={{ position: 'absolute', top: '38%', left: '22%' }}><MatchaPin2 size={14} grade="B"/></div>
      <div style={{ position: 'absolute', bottom: 10, right: 10, padding: '4px 10px', borderRadius: 12, background: 'rgba(255,255,255,0.95)', fontSize: 10, fontFamily: 'IBM Plex Mono, monospace', color: MM2.deep, fontWeight: 600 }}>28 PINS</div>
    </div>

    {/* Country tabs */}
    <div style={{ padding: '14px 16px 8px', display: 'flex', gap: 6, overflow: 'hidden' }}>
      {[
        { f:'jp', l:'일본', c:14, sel:true },
        { f:'kr', l:'한국', c:8 },
        { f:'us', l:'미국', c:3 },
        { f:'tw', l:'대만', c:2 },
        { f:'fr', l:'프랑스', c:1 },
      ].map((c,i) => (
        <div key={i} style={{ padding: '7px 12px', borderRadius: 16, background: c.sel ? MM2.deep : '#fff', color: c.sel ? '#fff' : MM2.text, border: c.sel ? 'none' : `1px solid ${MM2.line}`, fontSize: 12, fontWeight: c.sel ? 600 : 500, display: 'flex', alignItems: 'center', gap: 5, whiteSpace: 'nowrap' }}>
          <CountryFlag code={c.f} size={13}/>
          <span>{c.l}</span>
          <span style={{ opacity: 0.6, fontFamily: 'IBM Plex Mono, monospace', fontSize: 10 }}>{c.c}</span>
        </div>
      ))}
    </div>

    {/* List with region groupings */}
    <div style={{ padding: '4px 16px 100px', overflow: 'auto', height: 'calc(100% - 380px)' }}>
      {/* Region: 도쿄 */}
      <div style={{ marginTop: 10, marginBottom: 6, display: 'flex', alignItems: 'baseline', gap: 8 }}>
        <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM2.muted, letterSpacing: '0.2em' }}>TOKYO</span>
        <div style={{ flex: 1, height: 1, background: MM2.lineSoft }}/>
        <span style={{ fontSize: 11, color: MM2.deep, fontWeight: 600 }}>8곳</span>
      </div>
      {[
        { n:'宇治園 시부야', loc:'시부야', g:'S', tone:'matcha', note:'서연 추천' },
        { n:'茶筅', loc:'오모테산도', g:'S', tone:'cream', note:null },
        { n:'Marufuji', loc:'에비스', g:'A', tone:'deep', note:'다음 도쿄 갈때' },
      ].map((s,i) => (
        <div key={i} style={{ display: 'flex', gap: 12, padding: '10px 0', alignItems: 'center', borderBottom: `1px solid ${MM2.lineSoft}` }}>
          <Photo w={56} h={56} tone={s.tone} label="" radius={10}/>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <GradeChip2 grade={s.g} size="sm"/>
              <span style={{ fontSize: 11, color: MM2.muted }}>{s.loc}</span>
            </div>
            <div style={{ fontSize: 13, fontWeight: 700, color: MM2.deep, marginTop: 3 }}>{s.n}</div>
            {s.note && <div style={{ fontSize: 10, color: MM2.rose, marginTop: 2, fontStyle: 'italic' }}>“{s.note}”</div>}
          </div>
          <Icon name="bookmark-fill" size={16} color={MM2.deep}/>
        </div>
      ))}

      {/* Region: 교토 */}
      <div style={{ marginTop: 22, marginBottom: 6, display: 'flex', alignItems: 'baseline', gap: 8 }}>
        <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM2.muted, letterSpacing: '0.2em' }}>KYOTO</span>
        <div style={{ flex: 1, height: 1, background: MM2.lineSoft }}/>
        <span style={{ fontSize: 11, color: MM2.deep, fontWeight: 600 }}>4곳</span>
      </div>
      {[
        { n:'Tea Master', loc:'우지', g:'S', tone:'matcha' },
        { n:'伊藤久右衛門', loc:'기온', g:'A', tone:'cream' },
      ].map((s,i) => (
        <div key={i} style={{ display: 'flex', gap: 12, padding: '10px 0', alignItems: 'center', borderBottom: `1px solid ${MM2.lineSoft}` }}>
          <Photo w={56} h={56} tone={s.tone} label="" radius={10}/>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <GradeChip2 grade={s.g} size="sm"/>
              <span style={{ fontSize: 11, color: MM2.muted }}>{s.loc}</span>
            </div>
            <div style={{ fontSize: 13, fontWeight: 700, color: MM2.deep, marginTop: 3 }}>{s.n}</div>
          </div>
          <Icon name="bookmark-fill" size={16} color={MM2.deep}/>
        </div>
      ))}

      {/* Region: 오사카 */}
      <div style={{ marginTop: 22, marginBottom: 6, display: 'flex', alignItems: 'baseline', gap: 8 }}>
        <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM2.muted, letterSpacing: '0.2em' }}>OSAKA</span>
        <div style={{ flex: 1, height: 1, background: MM2.lineSoft }}/>
        <span style={{ fontSize: 11, color: MM2.deep, fontWeight: 600 }}>2곳</span>
      </div>
    </div>
    <TabBar2 active="wish"/>
    <HomeIndicator2/>
  </Phone2>
);

// ─────────────────────────────────────────────────────────────
// 13. Profile (My matcha journey)
// ─────────────────────────────────────────────────────────────
const Screen2Profile = () => (
  <Phone2 bg={MM2.bg}>
    <StatusBar2/>
    <div style={{ padding: '6px 20px 0', display: 'flex', justifyContent: 'space-between' }}>
      <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 22, fontWeight: 700, color: MM2.deep }}>내 정보</div>
      <Icon name="settings" size={20} color={MM2.text}/>
    </div>
    <div style={{ padding: '20px 20px 0', display: 'flex', alignItems: 'center', gap: 14 }}>
      <div style={{ width: 64, height: 64, borderRadius: '50%', background: `linear-gradient(135deg, ${MM2.matcha}, ${MM2.rose})`, padding: 2 }}>
        <div style={{ width: '100%', height: '100%', borderRadius: '50%', background: MM2.cream, display: 'flex', alignItems: 'center', justifyContent: 'center', color: MM2.deep, fontWeight: 700, fontSize: 22, fontFamily: 'Noto Serif KR, serif' }}>서</div>
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 16, fontWeight: 700, color: MM2.deep }}>서연</div>
        <div style={{ fontSize: 11, color: MM2.muted, marginTop: 2, fontFamily: 'IBM Plex Mono, monospace' }}>@seoyeon · 교토 출신</div>
        <div style={{ fontSize: 11, color: MM2.text, marginTop: 4 }}>친구 24 · 팔로워 132 · 팔로잉 87</div>
      </div>
      <button style={{ padding: '7px 14px', borderRadius: 14, background: '#fff', border: `1px solid ${MM2.deep}`, color: MM2.deep, fontSize: 12, fontWeight: 600 }}>편집</button>
    </div>

    {/* Stats hero */}
    <div style={{ margin: '20px 20px 0', padding: 18, background: '#fff', borderRadius: 16, border: `1px solid ${MM2.lineSoft}` }}>
      <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM2.rose, letterSpacing: '0.2em', marginBottom: 8 }}>나의 말차 여정</div>
      <div style={{ display: 'flex', gap: 18 }}>
        <div>
          <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 28, fontWeight: 700, color: MM2.deep, lineHeight: 1 }}>47</div>
          <div style={{ fontSize: 10, color: MM2.muted, marginTop: 4 }}>마신 잔</div>
        </div>
        <div style={{ width: 1, background: MM2.lineSoft }}/>
        <div>
          <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 28, fontWeight: 700, color: MM2.deep, lineHeight: 1 }}>12</div>
          <div style={{ fontSize: 10, color: MM2.muted, marginTop: 4 }}>방문 매장</div>
        </div>
        <div style={{ width: 1, background: MM2.lineSoft }}/>
        <div>
          <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 28, fontWeight: 700, color: MM2.deep, lineHeight: 1 }}>3</div>
          <div style={{ fontSize: 10, color: MM2.muted, marginTop: 4 }}>국가</div>
        </div>
        <div style={{ width: 1, background: MM2.lineSoft }}/>
        <div>
          <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 28, fontWeight: 700, color: MM2.deep, lineHeight: 1 }}>18</div>
          <div style={{ fontSize: 10, color: MM2.muted, marginTop: 4 }}>리뷰</div>
        </div>
      </div>
    </div>

    {/* My matcha — recent visits */}
    <div style={{ padding: '20px 20px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: MM2.deep }}>최근 마신 말차</div>
      <span style={{ fontSize: 11, color: MM2.rose }}>전체 →</span>
    </div>
    <div style={{ padding: '10px 0 0 16px', display: 'flex', gap: 10, overflow: 'hidden' }}>
      {[
        { n:'코이차', s:'宇治園 시부야', d:'2일 전', tone:'matcha', f:'jp' },
        { n:'우스차', s:'다실 안국', d:'1주 전', tone:'cream', f:'kr' },
        { n:'호우지차', s:'伊藤久右衛門', d:'2주 전', tone:'deep', f:'jp' },
      ].map((m,i) => (
        <div key={i} style={{ width: 130, flexShrink: 0 }}>
          <Photo w={130} h={130} tone={m.tone} label="" radius={12}/>
          <div style={{ marginTop: 8, display: 'flex', alignItems: 'center', gap: 4 }}>
            <CountryFlag code={m.f} size={11}/>
            <span style={{ fontSize: 13, fontWeight: 700, color: MM2.deep }}>{m.n}</span>
          </div>
          <div style={{ fontSize: 10, color: MM2.muted, marginTop: 1 }}>{m.s} · {m.d}</div>
        </div>
      ))}
    </div>

    {/* Menu links */}
    <div style={{ padding: '20px 20px 100px' }}>
      <div style={{ background: '#fff', borderRadius: 14, border: `1px solid ${MM2.lineSoft}`, overflow: 'hidden' }}>
        {[
          { i:'bookmark', l:'위시리스트', c:'28곳' },
          { i:'edit', l:'내 리뷰', c:'18개' },
          { i:'users', l:'친구', c:'24명' },
          { i:'bell', l:'알림 설정' },
        ].map((m,i,arr) => (
          <div key={i} style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: i < arr.length - 1 ? `1px solid ${MM2.lineSoft}` : 'none' }}>
            <Icon name={m.i} size={17} color={MM2.deep}/>
            <span style={{ flex: 1, fontSize: 13, color: MM2.deep, fontWeight: 500 }}>{m.l}</span>
            {m.c && <span style={{ fontSize: 11, color: MM2.muted, fontFamily: 'IBM Plex Mono, monospace' }}>{m.c}</span>}
            <Icon name="chevron-right" size={14} color={MM2.muted}/>
          </div>
        ))}
      </div>
    </div>
    <TabBar2 active="me"/>
    <HomeIndicator2/>
  </Phone2>
);

Object.assign(window, {
  Screen2Splash, Screen2Login, Screen2Location,
  Screen2MapWorld, Screen2MapCity, Screen2MapPreview,
  Screen2StoreDetail, Screen2Reviews, Screen2Search, Screen2ReviewWrite,
  Screen2Feed, Screen2Wishlist, Screen2Profile,
});
