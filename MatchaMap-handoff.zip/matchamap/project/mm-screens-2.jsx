// MatchaMap — Screens 13–24
// Filters, review write, collection, feed, ranking, nearby, planner, profile, wishlist, editorial

// ─────────────────────────────────────────────────────────────
// 13. Filter Sheet
// ─────────────────────────────────────────────────────────────
const ScreenFilterSheet = () => (
  <Phone>
    <StatusBar/>
    <div style={{ position: 'absolute', inset: 0, background: 'rgba(26,26,16,0.4)', backdropFilter: 'blur(2px)' }}/>
    {/* Background hint */}
    <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 200, opacity: 0.3 }}>
      <Photo h={200} tone="warm" label="" w="100%"/>
    </div>
    {/* Sheet */}
    <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, top: 100, background: MM.cream, borderRadius: '24px 24px 0 0', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '12px 0', display: 'flex', justifyContent: 'center' }}>
        <div style={{ width: 40, height: 4, background: MM.line, borderRadius: 2 }}/>
      </div>
      <div style={{ padding: '0 24px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: `1px solid ${MM.lineSoft}` }}>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 22, fontWeight: 700, color: MM.deep }}>필터</div>
        <div style={{ fontSize: 13, color: MM.terracotta, fontWeight: 600 }}>초기화</div>
      </div>
      <div style={{ flex: 1, overflow: 'auto', padding: '20px 24px 24px' }}>
        {/* Matcha types */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: MM.deep }}>말차 종류</div>
            <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.muted }}>3 SELECTED</div>
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {[{n:'우스차',s:1},{n:'코이차',s:1},{n:'말차 라떼',s:0},{n:'아이스 말차',s:0},{n:'말차 디저트',s:1},{n:'호우지차',s:0},{n:'센차',s:0}].map(t => (
              <div key={t.n} style={{ padding: '8px 14px', borderRadius: 20, fontSize: 12, fontWeight: 500, background: t.s ? MM.deep : '#fff', color: t.s ? '#fff' : MM.charcoal, border: t.s ? 'none' : `1px solid ${MM.line}` }}>{t.n}</div>
            ))}
          </div>
        </div>
        {/* Grade */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: MM.deep, marginBottom: 12 }}>품질 등급</div>
          <div style={{ display: 'flex', gap: 8 }}>
            {[{g:'S',l:'프리미엄',sel:true},{g:'A',l:'고급',sel:true},{g:'B',l:'스탠다드',sel:false},{g:'C',l:'캐주얼',sel:false}].map(t => (
              <div key={t.g} style={{ flex: 1, padding: 12, borderRadius: 12, background: t.sel ? MM.deep : '#fff', border: t.sel ? 'none' : `1px solid ${MM.line}`, textAlign: 'center' }}>
                <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 18, fontWeight: 600, color: t.sel ? '#fff' : MM.deep }}>{t.g}</div>
                <div style={{ fontSize: 10, color: t.sel ? 'rgba(255,255,255,0.7)' : MM.muted, marginTop: 2 }}>{t.l}</div>
              </div>
            ))}
          </div>
        </div>
        {/* Distance */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: MM.deep }}>거리</div>
            <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 12, color: MM.terracotta, fontWeight: 600 }}>~ 2.5 KM</div>
          </div>
          <div style={{ height: 4, background: MM.lineSoft, borderRadius: 2, position: 'relative', marginTop: 18 }}>
            <div style={{ width: '50%', height: '100%', background: MM.deep, borderRadius: 2 }}/>
            <div style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)', width: 22, height: 22, borderRadius: '50%', background: '#fff', border: `2px solid ${MM.deep}`, boxShadow: '0 2px 6px rgba(0,0,0,0.15)' }}/>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, color: MM.muted, marginTop: 6, fontFamily: 'IBM Plex Mono, monospace' }}>
            <span>0 KM</span><span>5+ KM</span>
          </div>
        </div>
        {/* More options */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: MM.deep, marginBottom: 12 }}>편의</div>
          {[{l:'영업중',sel:true},{l:'예약 가능',sel:false},{l:'테이크아웃',sel:false},{l:'비건 옵션',sel:false}].map(o => (
            <div key={o.l} style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', borderBottom: `1px solid ${MM.lineSoft}` }}>
              <span style={{ fontSize: 14, color: MM.charcoal }}>{o.l}</span>
              <div style={{ width: 44, height: 26, borderRadius: 13, background: o.sel ? MM.matcha : MM.line, position: 'relative', transition: 'all .2s' }}>
                <div style={{ position: 'absolute', top: 2, left: o.sel ? 20 : 2, width: 22, height: 22, borderRadius: '50%', background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,0.15)' }}/>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div style={{ padding: '12px 24px 28px', borderTop: `1px solid ${MM.lineSoft}`, display: 'flex', gap: 10 }}>
        <button style={{ flex: 1, height: 50, borderRadius: 25, background: '#fff', border: `1px solid ${MM.line}`, fontSize: 14, fontWeight: 600, color: MM.charcoal }}>닫기</button>
        <button style={{ flex: 2, height: 50, borderRadius: 25, background: MM.deep, color: '#fff', border: 'none', fontSize: 14, fontWeight: 600 }}>247개 결과 보기</button>
      </div>
    </div>
    <HomeIndicator/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 14. Review Write — Rating
// ─────────────────────────────────────────────────────────────
const ScreenReviewRating = () => (
  <Phone>
    <StatusBar/>
    <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: `1px solid ${MM.lineSoft}` }}>
      <Icon name="close" size={20}/>
      <div style={{ fontSize: 14, fontWeight: 600, color: MM.deep }}>리뷰 작성 1/2</div>
      <div style={{ fontSize: 13, color: MM.muted }}>다음</div>
    </div>
    <div style={{ padding: '24px' }}>
      <div style={{ display: 'flex', gap: 12, padding: 14, background: '#fff', borderRadius: 14, border: `1px solid ${MM.lineSoft}` }}>
        <Photo w={56} h={56} tone="matcha" label="UJI" radius={10}/>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: MM.deep, fontFamily: 'Noto Serif KR, serif' }}>宇治園 시부야</div>
          <div style={{ fontSize: 11, color: MM.muted, marginTop: 2 }}>도쿄 · 시부야</div>
        </div>
      </div>
      <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 24, fontWeight: 700, color: MM.deep, marginTop: 32, lineHeight: 1.3 }}>
        오늘의 한 잔은<br/>어떠셨나요?
      </div>
      <div style={{ fontSize: 13, color: MM.muted, marginTop: 6 }}>전체 만족도를 별점으로 남겨주세요</div>
      <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 36 }}>
        {[1,2,3,4,5].map(i => (
          <Icon key={i} name={i <= 4 ? 'star' : 'star-empty'} size={44} color={i <= 4 ? MM.gold : MM.line}/>
        ))}
      </div>
      <div style={{ textAlign: 'center', fontSize: 14, color: MM.terracotta, fontWeight: 600, marginTop: 12 }}>훌륭해요!</div>

      <div style={{ marginTop: 36 }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: MM.deep, marginBottom: 12 }}>세부 평가</div>
        {[
          { l: '말차 품질', v: 5 },
          { l: '서비스', v: 4.5 },
          { l: '분위기', v: 5 },
          { l: '가격 만족도', v: 3.5 },
        ].map(d => (
          <div key={d.l} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0', borderBottom: `1px dotted ${MM.line}` }}>
            <span style={{ fontSize: 13, color: MM.charcoal }}>{d.l}</span>
            <Stars value={d.v} size={16}/>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 24 }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: MM.deep, marginBottom: 10 }}>마셔본 메뉴</div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {[{n:'특상 코이차',s:true},{n:'우스차 (碧)',s:false},{n:'말차 와라비',s:true},{n:'+ 직접 입력',s:false,add:true}].map((m,i) => (
            <div key={i} style={{ padding: '7px 12px', borderRadius: 16, fontSize: 12, background: m.s ? MM.deep : '#fff', color: m.s ? '#fff' : m.add ? MM.muted : MM.charcoal, border: m.s ? 'none' : `1px solid ${m.add ? MM.line : MM.line}`, fontWeight: 500 }}>{m.n}</div>
          ))}
        </div>
      </div>
    </div>
    <HomeIndicator/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 15. Review Write — Photo + Text
// ─────────────────────────────────────────────────────────────
const ScreenReviewWrite = () => (
  <Phone>
    <StatusBar/>
    <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: `1px solid ${MM.lineSoft}` }}>
      <Icon name="arrow-left" size={20}/>
      <div style={{ fontSize: 14, fontWeight: 600, color: MM.deep }}>리뷰 작성 2/2</div>
      <div style={{ fontSize: 13, fontWeight: 600, color: MM.terracotta }}>등록</div>
    </div>
    <div style={{ padding: '20px 24px' }}>
      {/* Photos */}
      <div style={{ fontSize: 13, fontWeight: 600, color: MM.deep, marginBottom: 10, display: 'flex', justifyContent: 'space-between' }}>
        <span>사진</span>
        <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.muted }}>3 / 9</span>
      </div>
      <div style={{ display: 'flex', gap: 8, overflow: 'hidden' }}>
        <div style={{ width: 78, height: 78, borderRadius: 10, background: '#fff', border: `1.5px dashed ${MM.line}`, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4, flexShrink: 0 }}>
          <Icon name="camera" size={20} color={MM.muted}/>
          <span style={{ fontSize: 9, color: MM.muted, fontFamily: 'IBM Plex Mono, monospace' }}>3 / 9</span>
        </div>
        {['matcha','deep','clay'].map((t,i) => (
          <div key={i} style={{ position: 'relative' }}>
            <Photo w={78} h={78} tone={t} label="" radius={10}/>
            <div style={{ position: 'absolute', top: 4, right: 4, width: 18, height: 18, borderRadius: '50%', background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="close" size={10} color="#fff"/></div>
          </div>
        ))}
      </div>
      {/* Body */}
      <div style={{ fontSize: 13, fontWeight: 600, color: MM.deep, marginTop: 24, marginBottom: 8 }}>리뷰 내용</div>
      <div style={{ background: '#fff', border: `1px solid ${MM.line}`, borderRadius: 14, padding: 16, minHeight: 160 }}>
        <div style={{ fontSize: 14, lineHeight: 1.7, color: MM.charcoal }}>
          교토 우지 본점만큼 깊은 코이차의 풍미. 다완을 받쳐드는 다도가의 손짓 하나하나가 예술이었어요. 특히 첫물 잎으로 만든 한정 메뉴는 꼭 마셔봐야 합니다.
          <span style={{ borderRight: `2px solid ${MM.deep}`, marginLeft: 1 }}/>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 14, paddingTop: 12, borderTop: `1px dotted ${MM.line}` }}>
          <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.muted }}>78 / 1000</span>
          <Icon name="sparkle" size={14} color={MM.matcha}/>
        </div>
      </div>
      {/* Tags */}
      <div style={{ fontSize: 13, fontWeight: 600, color: MM.deep, marginTop: 22, marginBottom: 10 }}>분위기 태그</div>
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        {[{l:'#조용한',s:true},{l:'#정통',s:true},{l:'#데이트',s:false},{l:'#혼차',s:true},{l:'#친절',s:false},{l:'#가격높음',s:false}].map(t => (
          <div key={t.l} style={{ padding: '6px 11px', borderRadius: 14, fontSize: 12, background: t.s ? MM.matcha : '#fff', color: t.s ? '#fff' : MM.charcoal, border: t.s ? 'none' : `1px solid ${MM.line}` }}>{t.l}</div>
        ))}
      </div>
    </div>
    <HomeIndicator/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 16. Collection — 도감 grid
// ─────────────────────────────────────────────────────────────
const ScreenCollection = () => {
  const items = [
    { n: '宇治園', city: '도쿄', t: 'matcha', date: '04.28', collected: true, grade: 'S' },
    { n: '一保堂', city: '쿄토', t: 'deep', date: '03.12', collected: true, grade: 'S' },
    { n: '茶筅', city: '도쿄', t: 'cream', date: '02.04', collected: true, grade: 'A' },
    { n: 'Kettl', city: '뉴욕', t: 'clay', date: '01.18', collected: true, grade: 'A' },
    { n: 'Marufuji', city: '도쿄', t: 'warm', date: '01.02', collected: true, grade: 'A' },
    { n: 'Setsugekka', city: '서울', t: 'cool', date: '2025.12', collected: true, grade: 'B' },
    { n: '???', city: '쿄토', t: 'dark', collected: false },
    { n: '???', city: '오사카', t: 'dark', collected: false },
    { n: '???', city: '런던', t: 'dark', collected: false },
  ];
  return (
    <Phone>
      <StatusBar/>
      <div style={{ padding: '0 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, paddingTop: 12 }}>
          <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, letterSpacing: '0.2em', color: MM.terracotta }}>MY MATCHA · 2026</div>
        </div>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 32, fontWeight: 700, color: MM.deep, marginTop: 4, lineHeight: 1.1 }}>말차 도감</div>
        {/* Stats card */}
        <div style={{ marginTop: 18, padding: 16, background: MM.deep, borderRadius: 18, color: '#fff', display: 'flex', gap: 16 }}>
          <div>
            <div style={{ fontSize: 11, opacity: 0.6, fontFamily: 'IBM Plex Mono, monospace' }}>VISITED</div>
            <div className="mm-display" style={{ fontSize: 36, fontWeight: 700, fontFamily: 'Noto Serif KR, serif', lineHeight: 1.1 }}>23</div>
            <div style={{ fontSize: 11, opacity: 0.7 }}>매장</div>
          </div>
          <div style={{ width: 1, background: 'rgba(255,255,255,0.15)' }}/>
          <div>
            <div style={{ fontSize: 11, opacity: 0.6, fontFamily: 'IBM Plex Mono, monospace' }}>CITIES</div>
            <div className="mm-display" style={{ fontSize: 36, fontWeight: 700, fontFamily: 'Noto Serif KR, serif', lineHeight: 1.1 }}>7</div>
            <div style={{ fontSize: 11, opacity: 0.7 }}>도시</div>
          </div>
          <div style={{ width: 1, background: 'rgba(255,255,255,0.15)' }}/>
          <div>
            <div style={{ fontSize: 11, opacity: 0.6, fontFamily: 'IBM Plex Mono, monospace' }}>PROGRESS</div>
            <div className="mm-display" style={{ fontSize: 36, fontWeight: 700, fontFamily: 'Noto Serif KR, serif', lineHeight: 1.1, color: MM.matchaBright }}>14<span style={{ fontSize: 18, opacity: 0.7 }}>%</span></div>
            <div style={{ fontSize: 11, opacity: 0.7 }}>달성</div>
          </div>
        </div>
        {/* Filter row */}
        <div style={{ display: 'flex', gap: 6, marginTop: 18, overflow: 'hidden' }}>
          {['전체','수집함','미수집','등급별','국가별'].map((t,i) => (
            <div key={t} style={{ padding: '6px 12px', borderRadius: 14, fontSize: 12, fontWeight: 500, background: i === 0 ? MM.deep : 'transparent', color: i === 0 ? '#fff' : MM.muted, border: i === 0 ? 'none' : `1px solid ${MM.line}` }}>{t}</div>
          ))}
        </div>
      </div>
      {/* Grid */}
      <div style={{ padding: '16px 24px 100px', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, overflow: 'auto', height: 'calc(100% - 280px)' }}>
        {items.map((it,i) => (
          <div key={i} style={{ aspectRatio: '1 / 1.2', borderRadius: 12, overflow: 'hidden', position: 'relative', background: it.collected ? '' : '#e5e0cf', filter: it.collected ? 'none' : 'grayscale(1)' }}>
            <Photo w="100%" h="78%" tone={it.t} label={it.n} radius={0}/>
            {!it.collected && <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '78%', background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26, color: '#fff' }}>?</div>}
            {it.grade && <div style={{ position: 'absolute', top: 4, right: 4 }}><GradeChip grade={it.grade} size="sm"/></div>}
            <div style={{ padding: '4px 6px', background: '#fff' }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: MM.deep, fontFamily: 'Noto Serif KR, serif' }}>{it.n}</div>
              <div style={{ fontSize: 9, color: MM.muted, display: 'flex', justifyContent: 'space-between' }}>
                <span>{it.city}</span>
                {it.date && <span style={{ fontFamily: 'IBM Plex Mono, monospace' }}>{it.date}</span>}
              </div>
            </div>
          </div>
        ))}
      </div>
      <TabBar active="collect"/>
      <HomeIndicator/>
    </Phone>
  );
};

// ─────────────────────────────────────────────────────────────
// 17. Collection Detail — Memory page (magazine style)
// ─────────────────────────────────────────────────────────────
const ScreenCollectionDetail = () => (
  <Phone>
    <StatusBar/>
    <div style={{ position: 'absolute', top: 60, left: 16, right: 16, display: 'flex', justifyContent: 'space-between', zIndex: 10 }}>
      <div style={{ width: 36, height: 36, borderRadius: '50%', background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 6px rgba(0,0,0,0.08)' }}><Icon name="arrow-left" size={16}/></div>
      <div style={{ width: 36, height: 36, borderRadius: '50%', background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 6px rgba(0,0,0,0.08)' }}><Icon name="share" size={15}/></div>
    </div>
    <div style={{ padding: '64px 28px 100px', overflow: 'auto', height: '100%' }}>
      <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.terracotta, letterSpacing: '0.25em', marginTop: 8 }}>NO. 23 · 2026.04.28</div>
      <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 36, fontWeight: 700, color: MM.deep, lineHeight: 1.1, marginTop: 8, letterSpacing: '-0.02em' }}>
        시부야의<br/><em style={{ fontStyle: 'italic', color: MM.terracotta }}>고요한</em><br/>한 잔.
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 14, paddingBottom: 16, borderBottom: `2px solid ${MM.deep}` }}>
        <GradeChip grade="S" size="sm"/>
        <span style={{ fontSize: 11, color: MM.muted, fontFamily: 'IBM Plex Mono, monospace', letterSpacing: '0.1em' }}>UJI · TOKYO</span>
        <div style={{ marginLeft: 'auto', fontSize: 12, color: MM.deep, fontWeight: 600 }}>★★★★★</div>
      </div>
      {/* Big photo */}
      <Photo w="100%" h={300} tone="matcha" label="MEMORY · 04.28" radius={0} style={{ marginTop: 18 }}/>
      <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM.muted, marginTop: 6, letterSpacing: '0.1em' }}>오후 3시 · 햇살 깊게 들던 자리에서.</div>
      {/* Body two-column */}
      <div style={{ marginTop: 22, fontSize: 14, lineHeight: 1.85, color: MM.charcoal, columnCount: 1 }}>
        <span style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 38, fontWeight: 700, color: MM.terracotta, float: 'left', lineHeight: 0.85, marginRight: 6, marginTop: 4 }}>七</span>
        대째 이어진 다실. 다도가가 직접 갈아낸 가루를 미지근한 물에 풀어내는 동안, 시부야 거리의 소음이 사라지는 신기한 경험을 했다. 코이차 한 잔에 시간이 잠시 멈췄다.
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginTop: 18 }}>
        <Photo w="100%" h={120} tone="deep" label="01"/>
        <Photo w="100%" h={120} tone="clay" label="02"/>
      </div>
      <div style={{ marginTop: 22, padding: 16, background: '#fff', borderRadius: 12, border: `1px solid ${MM.lineSoft}` }}>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM.muted, letterSpacing: '0.2em', marginBottom: 6 }}>TASTE NOTE</div>
        <div style={{ fontSize: 14, fontFamily: 'Noto Serif KR, serif', color: MM.deep, lineHeight: 1.5, fontStyle: 'italic' }}>"풀잎 끝의 단맛, 그 뒤로 깊게 따라오는 우마미. 한 모금 마시고 두 번 숨을 쉬게 되는 그런 차."</div>
      </div>
      <div style={{ marginTop: 18, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        {['#코이차','#노포','#정통','#혼차','#04월'].map(t => <span key={t} style={{ fontSize: 11, color: MM.muted, padding: '4px 10px', background: '#fff', borderRadius: 12, border: `1px solid ${MM.lineSoft}` }}>{t}</span>)}
      </div>
    </div>
    <HomeIndicator/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 18. Friends Activity Feed
// ─────────────────────────────────────────────────────────────
const ScreenFeed = () => {
  const posts = [
    { user: '미나', city: '도쿄', avatar: 'cream', time: '2시간 전', store: '宇治園 시부야', tone: 'matcha', text: '도쿄 출장 마지막 날, 가장 깊었던 한 잔.', rating: 5, likes: 47, comments: 8 },
    { user: 'Yuki', city: '쿄토', avatar: 'matcha', time: '5시간 전', store: '一保堂 본점', tone: 'deep', text: '300년 된 다실에서 마시는 코이차는 다른 차원이었다. 차분히 호흡을 맞춰가며 마시는 의식.', rating: 5, likes: 124, comments: 23 },
    { user: 'Hiro', city: '서울', avatar: 'clay', time: '어제', store: 'Setsugekka 성수', tone: 'cream', text: '서울에서 발견한 숨겨진 보석.', rating: 4.5, likes: 38, comments: 5 },
  ];
  return (
    <Phone>
      <StatusBar/>
      <div style={{ padding: '0 24px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: `1px solid ${MM.lineSoft}` }}>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 26, fontWeight: 700, color: MM.deep }}>피드</div>
        <div style={{ display: 'flex', gap: 12 }}>
          <Icon name="search" size={20} color={MM.deep}/>
          <Icon name="bell" size={20} color={MM.deep}/>
        </div>
      </div>
      {/* Story row */}
      <div style={{ padding: '14px 16px', display: 'flex', gap: 14, overflow: 'hidden', borderBottom: `1px solid ${MM.lineSoft}` }}>
        {[{n:'나',a:'cream',my:true},{n:'미나',a:'matcha'},{n:'Yuki',a:'deep'},{n:'Hiro',a:'clay'},{n:'Naomi',a:'warm'},{n:'Toshi',a:'cool'}].map((s,i) => (
          <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, flexShrink: 0 }}>
            <div style={{ width: 56, height: 56, borderRadius: '50%', padding: 2, background: s.my ? MM.line : `conic-gradient(${MM.matcha}, ${MM.terracotta}, ${MM.matcha})`, position: 'relative' }}>
              <Photo w={52} h={52} tone={s.a} label="" radius={26}/>
              {s.my && <div style={{ position: 'absolute', bottom: -2, right: -2, width: 22, height: 22, borderRadius: '50%', background: MM.deep, display: 'flex', alignItems: 'center', justifyContent: 'center', border: '2px solid #fff' }}><Icon name="plus" size={12} color="#fff" strokeWidth={2.5}/></div>}
            </div>
            <span style={{ fontSize: 10, color: MM.charcoal }}>{s.n}</span>
          </div>
        ))}
      </div>
      <div style={{ overflow: 'auto', height: 'calc(100% - 200px)', padding: '0 0 100px' }}>
        {posts.map((p,i) => (
          <div key={i} style={{ padding: '16px 24px', borderBottom: `1px solid ${MM.lineSoft}` }}>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 10 }}>
              <Photo w={36} h={36} tone={p.avatar} label="" radius={18}/>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: MM.deep }}>{p.user} <span style={{ fontWeight: 400, color: MM.muted }}>· {p.city}</span></div>
                <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.muted }}>{p.time}</div>
              </div>
              <Icon name="bookmark" size={16} color={MM.muted}/>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 10px', background: 'rgba(90,122,58,0.08)', borderRadius: 8, marginBottom: 10, alignSelf: 'flex-start', width: 'fit-content' }}>
              <Icon name="pin" size={12} color={MM.matcha}/>
              <span style={{ fontSize: 12, fontWeight: 600, color: MM.matcha }}>{p.store}</span>
              <Stars value={p.rating} size={10}/>
            </div>
            <div style={{ fontSize: 14, color: MM.charcoal, lineHeight: 1.6, marginBottom: 10 }}>{p.text}</div>
            <Photo w="100%" h={200} tone={p.tone} label="POST PHOTO" radius={12}/>
            <div style={{ display: 'flex', gap: 18, marginTop: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, color: MM.charcoal }}><Icon name="heart" size={16}/>{p.likes}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, color: MM.charcoal }}><Icon name="message" size={16}/>{p.comments}</div>
              <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, color: MM.terracotta, fontWeight: 600 }}>가본 매장 추가 <Icon name="plus" size={12} color={MM.terracotta}/></div>
            </div>
          </div>
        ))}
      </div>
      <TabBar active="feed"/>
      <HomeIndicator/>
    </Phone>
  );
};

// ─────────────────────────────────────────────────────────────
// 19. Ranking — Best Stores
// ─────────────────────────────────────────────────────────────
const ScreenRanking = () => {
  const top = [
    { r: 1, n: '一保堂 본점', city: '쿄토 · 일본', score: 4.98, reviews: 8421, t: 'deep', delta: 0 },
    { r: 2, n: '宇治園 시부야', city: '도쿄 · 일본', score: 4.96, reviews: 2341, t: 'matcha', delta: 1 },
    { r: 3, n: 'Marukyu Koyamaen', city: '쿄토 · 일본', score: 4.94, reviews: 5102, t: 'cream', delta: -1 },
  ];
  const next = [
    { r: 4, n: 'Kettl Tea', city: '뉴욕 · 미국', score: 4.91, t: 'clay' },
    { r: 5, n: 'Setsugekka', city: '서울 · 한국', score: 4.89, t: 'warm' },
    { r: 6, n: 'Sazen Tea', city: '런던 · 영국', score: 4.87, t: 'cool' },
    { r: 7, n: 'Cha-an', city: '뉴욕 · 미국', score: 4.85, t: 'matcha' },
    { r: 8, n: 'Nakamura Tokichi', city: '쿄토 · 일본', score: 4.83, t: 'deep' },
  ];
  return (
    <Phone>
      <StatusBar/>
      <div style={{ padding: '0 24px 16px', borderBottom: `1px solid ${MM.lineSoft}` }}>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.terracotta, letterSpacing: '0.2em', marginTop: 6 }}>2026 · APRIL</div>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 28, fontWeight: 700, color: MM.deep, marginTop: 4 }}>월간 베스트</div>
        <div style={{ fontSize: 13, color: MM.muted, marginTop: 4 }}>전 세계 말차맵 사용자가 선정한 매장</div>
        <div style={{ display: 'flex', gap: 6, marginTop: 14 }}>
          {['글로벌','아시아','일본','한국','유럽','미국'].map((c,i) => (
            <div key={c} style={{ padding: '6px 12px', borderRadius: 14, fontSize: 12, fontWeight: 500, background: i === 0 ? MM.deep : 'transparent', color: i === 0 ? '#fff' : MM.muted, border: i === 0 ? 'none' : `1px solid ${MM.line}` }}>{c}</div>
          ))}
        </div>
      </div>
      <div style={{ padding: '20px 24px 100px', overflow: 'auto', height: 'calc(100% - 200px)' }}>
        {/* Top 3 podium */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end', marginBottom: 24 }}>
          {[top[1], top[0], top[2]].map((s,i) => {
            const heights = [120, 160, 100];
            return (
              <div key={s.r} style={{ flex: 1 }}>
                <Photo w="100%" h={heights[i]} tone={s.t} label={`#${s.r}`} radius={10}/>
                <div style={{ marginTop: 8, fontSize: 11, color: MM.terracotta, fontFamily: 'IBM Plex Mono, monospace', fontWeight: 600 }}>RANK 0{s.r}</div>
                <div style={{ fontSize: 13, fontWeight: 700, color: MM.deep, fontFamily: 'Noto Serif KR, serif', lineHeight: 1.2, marginTop: 2 }}>{s.n}</div>
                <div style={{ fontSize: 10, color: MM.muted, marginTop: 2 }}>{s.city}</div>
                <div style={{ fontSize: 12, color: MM.deep, fontWeight: 600, marginTop: 4, fontFamily: 'IBM Plex Mono, monospace' }}>★ {s.score}</div>
              </div>
            );
          })}
        </div>
        {/* Next list */}
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.muted, letterSpacing: '0.15em', marginBottom: 8, paddingBottom: 8, borderBottom: `1px solid ${MM.deep}` }}>NEXT 04 — 50</div>
        {next.map(s => (
          <div key={s.r} style={{ display: 'flex', gap: 14, padding: '12px 0', borderBottom: `1px dotted ${MM.line}`, alignItems: 'center' }}>
            <div style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 22, fontWeight: 700, color: MM.muted, width: 30 }}>{s.r}</div>
            <Photo w={50} h={50} tone={s.t} label="" radius={8}/>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: MM.deep, fontFamily: 'Noto Serif KR, serif' }}>{s.n}</div>
              <div style={{ fontSize: 10, color: MM.muted, marginTop: 1 }}>{s.city}</div>
            </div>
            <div style={{ fontSize: 13, fontWeight: 600, color: MM.deep, fontFamily: 'IBM Plex Mono, monospace' }}>★ {s.score}</div>
          </div>
        ))}
      </div>
      <TabBar active="discover"/>
      <HomeIndicator/>
    </Phone>
  );
};

// ─────────────────────────────────────────────────────────────
// 20. Nearby — Current location based
// ─────────────────────────────────────────────────────────────
const ScreenNearby = () => {
  const items = [
    { n: '茶筅 시부야', dist: '120m', walk: '2분', grade: 'S', open: '21시 마감', t: 'matcha' },
    { n: 'Marufuji', dist: '340m', walk: '5분', grade: 'A', open: '20시 마감', t: 'deep' },
    { n: 'Sabō Tsubaki', dist: '580m', walk: '8분', grade: 'B', open: '19시 마감', t: 'clay' },
    { n: '宇治園 시부야', dist: '720m', walk: '10분', grade: 'S', open: '21시 마감', t: 'cream' },
  ];
  return (
    <Phone>
      <StatusBar/>
      <div style={{ padding: '0 24px 14px' }}>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.terracotta, letterSpacing: '0.2em', marginTop: 8 }}>NOW · 시부야 · 도쿄</div>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 28, fontWeight: 700, color: MM.deep, marginTop: 4 }}>주변의 한 잔</div>
        <div style={{ fontSize: 13, color: MM.muted, marginTop: 4 }}>지금 있는 곳에서 걸어갈 수 있는 곳</div>
      </div>
      {/* Mini map */}
      <div style={{ height: 200, position: 'relative', overflow: 'hidden', margin: '0 16px', borderRadius: 16 }}>
        <CityMap>
          <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)' }}>
            <div style={{ width: 16, height: 16, borderRadius: '50%', background: '#1e90ff', border: '3px solid #fff', boxShadow: '0 0 0 6px rgba(30,144,255,0.2)', position: 'relative' }}/>
          </div>
          <div style={{ position: 'absolute', top: '40%', left: '60%' }}><MatchaPin size={26} grade="S"/></div>
          <div style={{ position: 'absolute', top: '60%', left: '40%' }}><MatchaPin size={24} grade="A"/></div>
          <div style={{ position: 'absolute', top: '30%', left: '30%' }}><MatchaPin size={22} grade="B"/></div>
          <div style={{ position: 'absolute', top: '65%', left: '70%' }}><MatchaPin size={22} grade="S"/></div>
        </CityMap>
        <div style={{ position: 'absolute', bottom: 10, right: 10, padding: '6px 10px', background: '#fff', borderRadius: 14, fontSize: 11, fontWeight: 600, color: MM.deep, display: 'flex', alignItems: 'center', gap: 4, boxShadow: '0 2px 6px rgba(0,0,0,0.08)' }}>
          <Icon name="map" size={11}/> 지도에서 보기
        </div>
      </div>
      <div style={{ padding: '14px 24px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.muted, letterSpacing: '0.1em' }}>가까운 순 · {items.length}개</div>
        <div style={{ fontSize: 12, color: MM.muted, display: 'flex', alignItems: 'center', gap: 4 }}>정렬 <Icon name="chevron-down" size={12}/></div>
      </div>
      <div style={{ overflow: 'auto', height: 'calc(100% - 480px)', padding: '0 24px 100px' }}>
        {items.map((it,i) => (
          <div key={i} style={{ display: 'flex', gap: 14, padding: '14px 0', borderBottom: `1px solid ${MM.lineSoft}`, alignItems: 'center' }}>
            <div style={{ position: 'relative' }}>
              <Photo w={70} h={70} tone={it.t} label={it.n.slice(0,2)} radius={10}/>
              <div style={{ position: 'absolute', top: -4, left: -4 }}><GradeChip grade={it.grade} size="sm"/></div>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: MM.deep, fontFamily: 'Noto Serif KR, serif' }}>{it.n}</div>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 4 }}>
                <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 11, color: MM.terracotta, fontWeight: 600 }}>{it.dist}</span>
                <span style={{ fontSize: 10, color: MM.muted }}>· 도보 {it.walk}</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 4 }}>
                <Icon name="clock" size={11} color={MM.matcha}/>
                <span style={{ fontSize: 11, color: MM.matcha, fontWeight: 500 }}>영업중</span>
                <span style={{ fontSize: 10, color: MM.muted }}>· {it.open}</span>
              </div>
            </div>
            <div style={{ width: 36, height: 36, borderRadius: '50%', background: MM.deep, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="arrow-right" size={16} color="#fff"/>
            </div>
          </div>
        ))}
      </div>
      <TabBar active="discover"/>
      <HomeIndicator/>
    </Phone>
  );
};

// ─────────────────────────────────────────────────────────────
// 21. Travel Planner — City course
// ─────────────────────────────────────────────────────────────
const ScreenPlanner = () => {
  const stops = [
    { time: '10:00', n: '一保堂 본점', cat: '오전 · 정통 다실', dur: '90분', t: 'deep', grade: 'S' },
    { time: '12:30', n: 'Itoh Kyuemon', cat: '점심 · 우지차 식사', dur: '60분', t: 'matcha', grade: 'A' },
    { time: '14:30', n: 'Marukyu Koyamaen', cat: '오후 · 다원 견학', dur: '120분', t: 'warm', grade: 'S' },
    { time: '17:00', n: 'Nakamura Tokichi', cat: '저녁 · 디저트', dur: '60분', t: 'cream', grade: 'A' },
  ];
  return (
    <Phone>
      <StatusBar/>
      <div style={{ position: 'relative' }}>
        <Photo w="100%" h={180} tone="deep" label="KYOTO · UJI"/>
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, transparent 30%, rgba(247,245,238,0.85) 100%)' }}/>
        <div style={{ position: 'absolute', top: 20, left: 16, right: 16, display: 'flex', justifyContent: 'space-between' }}>
          <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(247,245,238,0.9)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="arrow-left" size={16}/></div>
          <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(247,245,238,0.9)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="bookmark" size={15}/></div>
        </div>
      </div>
      <div style={{ padding: '0 24px', marginTop: -50, position: 'relative' }}>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.terracotta, letterSpacing: '0.2em' }}>COURSE · 1일 · 쿄토 우지</div>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 28, fontWeight: 700, color: MM.deep, lineHeight: 1.2, marginTop: 4 }}>
          쿄토 우지<br/>말차 순례 코스
        </div>
        <div style={{ display: 'flex', gap: 14, marginTop: 14, fontSize: 11, color: MM.muted, fontFamily: 'IBM Plex Mono, monospace', letterSpacing: '0.05em' }}>
          <span>4 STOPS</span><span>·</span><span>5.5H</span><span>·</span><span>WALK 3KM</span>
        </div>
      </div>
      <div style={{ padding: '24px 24px 100px', overflow: 'auto', height: 'calc(100% - 230px)', position: 'relative' }}>
        {/* Vertical line */}
        <div style={{ position: 'absolute', top: 24, bottom: 100, left: 60, width: 2, background: MM.line, backgroundImage: `repeating-linear-gradient(180deg, ${MM.matcha} 0, ${MM.matcha} 4px, transparent 4px, transparent 8px)` }}/>
        {stops.map((s,i) => (
          <div key={i} style={{ display: 'flex', gap: 14, marginBottom: 20, position: 'relative' }}>
            <div style={{ width: 32, fontSize: 11, fontFamily: 'IBM Plex Mono, monospace', color: MM.deep, fontWeight: 600, paddingTop: 16 }}>{s.time}</div>
            <div style={{ width: 28, position: 'relative', display: 'flex', justifyContent: 'center' }}>
              <div style={{ width: 28, height: 28, borderRadius: '50%', background: MM.deep, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, fontFamily: 'IBM Plex Mono, monospace', position: 'relative', zIndex: 2, marginTop: 14 }}>{i + 1}</div>
            </div>
            <div style={{ flex: 1, padding: 14, background: '#fff', borderRadius: 14, border: `1px solid ${MM.lineSoft}` }}>
              <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.muted, letterSpacing: '0.1em' }}>{s.cat.toUpperCase()}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4 }}>
                <div style={{ fontSize: 15, fontWeight: 700, color: MM.deep, fontFamily: 'Noto Serif KR, serif' }}>{s.n}</div>
                <GradeChip grade={s.grade} size="sm"/>
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                <Photo w={60} h={60} tone={s.t} label="" radius={8}/>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: MM.muted, marginBottom: 4 }}>
                    <Icon name="clock" size={11}/>{s.dur} 머무르기
                  </div>
                  <div style={{ fontSize: 11, color: MM.charcoal, lineHeight: 1.5 }}>{s.cat.split('·')[1]}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ position: 'absolute', bottom: 28, left: 16, right: 16, padding: 14, background: MM.deep, borderRadius: 18, display: 'flex', alignItems: 'center', justifyContent: 'space-between', boxShadow: '0 6px 20px rgba(45,59,31,0.25)' }}>
        <div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.6)' }}>이 코스 시작하기</div>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#fff' }}>4월 30일 · 토요일</div>
        </div>
        <button style={{ padding: '10px 18px', borderRadius: 22, background: MM.matchaBright, color: '#fff', border: 'none', fontSize: 13, fontWeight: 700 }}>출발하기</button>
      </div>
      <HomeIndicator/>
    </Phone>
  );
};

// ─────────────────────────────────────────────────────────────
// 22. Profile / My
// ─────────────────────────────────────────────────────────────
const ScreenProfile = () => (
  <Phone>
    <StatusBar/>
    <div style={{ padding: '0 24px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <div style={{ fontSize: 16, fontWeight: 700, color: MM.deep }}>내 정보</div>
      <div style={{ display: 'flex', gap: 14 }}>
        <Icon name="bell" size={20}/>
        <Icon name="settings" size={20}/>
      </div>
    </div>
    {/* Profile card */}
    <div style={{ margin: '0 16px', padding: 18, background: MM.deep, borderRadius: 20, color: '#fff', position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: -20, right: -20, width: 140, height: 140, borderRadius: '50%', background: 'radial-gradient(circle, rgba(127,164,80,0.3) 0%, transparent 70%)' }}/>
      <div style={{ display: 'flex', gap: 14, alignItems: 'center', position: 'relative' }}>
        <div style={{ width: 64, height: 64, borderRadius: '50%', background: MM.cream, padding: 2 }}>
          <Photo w={60} h={60} tone="warm" label="" radius={30}/>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 18, fontWeight: 700, fontFamily: 'Noto Serif KR, serif' }}>김지민</div>
          <div style={{ fontSize: 11, opacity: 0.7, fontFamily: 'IBM Plex Mono, monospace' }}>@jimin · MATCHA SEEKER</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 4 }}>
            <Icon name="trophy" size={12} color={MM.gold}/>
            <span style={{ fontSize: 11, color: MM.gold }}>LV.4 · 입문 다인(茶人)</span>
          </div>
        </div>
      </div>
      <div style={{ display: 'flex', gap: 4, marginTop: 16 }}>
        {[{l:'방문',v:'23'},{l:'리뷰',v:'18'},{l:'팔로워',v:'247'},{l:'팔로잉',v:'89'}].map(s => (
          <div key={s.l} style={{ flex: 1, textAlign: 'center', padding: '8px 4px', background: 'rgba(255,255,255,0.06)', borderRadius: 10 }}>
            <div className="mm-display" style={{ fontSize: 18, fontWeight: 700, fontFamily: 'Noto Serif KR, serif' }}>{s.v}</div>
            <div style={{ fontSize: 10, opacity: 0.6 }}>{s.l}</div>
          </div>
        ))}
      </div>
    </div>
    {/* Level bar */}
    <div style={{ margin: '14px 16px 0', padding: 14, background: '#fff', borderRadius: 14, border: `1px solid ${MM.lineSoft}` }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
        <span style={{ fontSize: 12, color: MM.charcoal, fontWeight: 600 }}>다음 레벨까지</span>
        <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 11, color: MM.terracotta, fontWeight: 600 }}>23 / 30</span>
      </div>
      <div style={{ height: 6, background: MM.lineSoft, borderRadius: 3, overflow: 'hidden' }}>
        <div style={{ width: '76%', height: '100%', background: `linear-gradient(90deg, ${MM.matcha}, ${MM.matchaBright})`, borderRadius: 3 }}/>
      </div>
      <div style={{ fontSize: 11, color: MM.muted, marginTop: 6 }}>7곳 더 방문하면 LV.5 · 차예가가 돼요</div>
    </div>
    {/* Menu list */}
    <div style={{ padding: '20px 24px 100px', overflow: 'auto' }}>
      {[
        { i:'bookmark', l: '저장한 매장', d: '34곳' },
        { i:'leaf', l: '나의 도감', d: '23 / 168' },
        { i:'edit', l: '내가 쓴 리뷰', d: '18개' },
        { i:'compass', l: '나의 여행 코스', d: '4개' },
        { i:'users', l: '친구 관리', d: null },
        { i:'globe', l: '언어 / 지역', d: '한국어' },
        { i:'settings', l: '설정', d: null },
      ].map(m => (
        <div key={m.l} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 0', borderBottom: `1px solid ${MM.lineSoft}` }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: '#fff', border: `1px solid ${MM.lineSoft}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name={m.i} size={16} color={MM.deep}/></div>
          <span style={{ flex: 1, fontSize: 14, color: MM.charcoal }}>{m.l}</span>
          {m.d && <span style={{ fontSize: 12, color: MM.muted }}>{m.d}</span>}
          <Icon name="chevron-right" size={14} color={MM.muted}/>
        </div>
      ))}
    </div>
    <TabBar active="me"/>
    <HomeIndicator/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 23. Wishlist / Bookmarks
// ─────────────────────────────────────────────────────────────
const ScreenWishlist = () => {
  const lists = [
    { n: '쿄토 다음 여행', count: 12, t: 'matcha', last: '어제 추가' },
    { n: '뉴욕 비즈니스 트립', count: 7, t: 'clay', last: '3일 전' },
    { n: '서울 데이트', count: 5, t: 'cream', last: '1주 전' },
    { n: '언젠가 가고싶은', count: 24, t: 'deep', last: '2주 전' },
  ];
  const recent = [
    { n: 'Sazen Tea', city: '런던', t: 'cool', grade: 'A' },
    { n: 'Cha-an Teahouse', city: '뉴욕', t: 'matcha', grade: 'A' },
    { n: 'Setsugekka', city: '서울', t: 'warm', grade: 'B' },
  ];
  return (
    <Phone>
      <StatusBar/>
      <div style={{ padding: '0 24px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 26, fontWeight: 700, color: MM.deep }}>나의 위시리스트</div>
        <div style={{ width: 32, height: 32, borderRadius: 10, background: MM.deep, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="plus" size={16} color="#fff"/>
        </div>
      </div>
      <div style={{ padding: '0 16px', overflow: 'auto', height: 'calc(100% - 130px)', paddingBottom: 100 }}>
        {/* Lists */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {lists.map(l => (
            <div key={l.n} style={{ borderRadius: 14, overflow: 'hidden', background: '#fff', border: `1px solid ${MM.lineSoft}` }}>
              <div style={{ position: 'relative' }}>
                <Photo w="100%" h={120} tone={l.t} label=""/>
                <div style={{ position: 'absolute', top: 8, right: 8, padding: '3px 8px', background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(8px)', borderRadius: 10, fontSize: 10, color: '#fff', fontFamily: 'IBM Plex Mono, monospace' }}>{l.count}</div>
                <Icon name="bookmark-fill" size={20} color="#fff" style={{ position: 'absolute', bottom: 8, left: 8 }}/>
              </div>
              <div style={{ padding: 12 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: MM.deep, fontFamily: 'Noto Serif KR, serif' }}>{l.n}</div>
                <div style={{ fontSize: 10, color: MM.muted, marginTop: 2, fontFamily: 'IBM Plex Mono, monospace' }}>{l.last}</div>
              </div>
            </div>
          ))}
        </div>
        {/* Recent saved */}
        <div style={{ marginTop: 28, paddingBottom: 8, borderBottom: `1px solid ${MM.deep}`, display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 17, fontWeight: 700, color: MM.deep }}>최근 저장</div>
          <div style={{ fontSize: 11, color: MM.muted, fontFamily: 'IBM Plex Mono, monospace' }}>전체 보기</div>
        </div>
        {recent.map((r,i) => (
          <div key={i} style={{ display: 'flex', gap: 12, padding: '12px 8px', borderBottom: `1px solid ${MM.lineSoft}`, alignItems: 'center' }}>
            <Photo w={56} h={56} tone={r.t} label="" radius={10}/>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <GradeChip grade={r.grade} size="sm"/>
                <span style={{ fontSize: 13, fontWeight: 700, color: MM.deep, fontFamily: 'Noto Serif KR, serif' }}>{r.n}</span>
              </div>
              <div style={{ fontSize: 11, color: MM.muted, marginTop: 2 }}>{r.city}</div>
            </div>
            <Icon name="bookmark-fill" size={18} color={MM.terracotta}/>
          </div>
        ))}
      </div>
      <TabBar active="me"/>
      <HomeIndicator/>
    </Phone>
  );
};

// ─────────────────────────────────────────────────────────────
// 24. Editorial Discover (magazine style)
// ─────────────────────────────────────────────────────────────
const ScreenEditorial = () => (
  <Phone>
    <StatusBar/>
    <div style={{ padding: '0 24px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: `1px solid ${MM.lineSoft}` }}>
      <div>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, letterSpacing: '0.25em', color: MM.terracotta }}>VOL. 04 · 2026</div>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 24, fontWeight: 700, color: MM.deep, marginTop: 2 }}>발견</div>
      </div>
      <div style={{ display: 'flex', gap: 14 }}>
        <Icon name="search" size={20}/>
        <Icon name="bell" size={20}/>
      </div>
    </div>
    <div style={{ overflow: 'auto', height: 'calc(100% - 130px)', paddingBottom: 100 }}>
      {/* Cover story */}
      <div style={{ padding: '20px 24px 0' }}>
        <div style={{ position: 'relative', borderRadius: 14, overflow: 'hidden' }}>
          <Photo w="100%" h={320} tone="deep" label="COVER · KYOTO UJI" radius={14}/>
          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, transparent 30%, rgba(0,0,0,0.7))', padding: 18, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
            <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: '#fff', opacity: 0.7, letterSpacing: '0.25em' }}>COVER STORY · 04월</div>
            <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 26, fontWeight: 700, color: '#fff', lineHeight: 1.2, marginTop: 8 }}>
              우지의 봄,<br/>첫 잎이 우려지는<br/><em style={{ fontStyle: 'italic', color: MM.matchaBright }}>일주일.</em>
            </div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', marginTop: 10, fontFamily: 'IBM Plex Mono, monospace' }}>READ — 6 MIN · 12 PHOTOS</div>
          </div>
        </div>
      </div>
      {/* Editorial list */}
      <div style={{ padding: '24px 24px 0' }}>
        <div style={{ paddingBottom: 8, borderBottom: `1px solid ${MM.deep}`, display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 17, fontWeight: 700, color: MM.deep }}>이번 주 에디터스 픽</div>
          <div style={{ fontSize: 10, color: MM.muted, fontFamily: 'IBM Plex Mono, monospace', letterSpacing: '0.1em' }}>04 / 30</div>
        </div>
        {[
          { num: '01', tag: 'TOKYO', title: '시부야 골목의 7대 노포', sub: '한 가족이 170년 동안 지켜온 다실', t: 'matcha' },
          { num: '02', tag: 'NEW YORK', title: '브루클린에서 만난 우지', sub: '교토 출신 다인이 차린 작은 공간', t: 'clay' },
          { num: '03', tag: 'SEOUL', title: '성수의 새로운 다실 다섯', sub: '한국식 다도와 일본 말차의 만남', t: 'cream' },
        ].map(e => (
          <div key={e.num} style={{ display: 'flex', gap: 14, padding: '16px 0', borderBottom: `1px dotted ${MM.line}` }}>
            <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 28, fontWeight: 700, color: MM.deep, lineHeight: 1, width: 46 }}>{e.num}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM.terracotta, letterSpacing: '0.2em' }}>{e.tag}</div>
              <div style={{ fontSize: 15, fontWeight: 700, color: MM.deep, fontFamily: 'Noto Serif KR, serif', marginTop: 2 }}>{e.title}</div>
              <div style={{ fontSize: 12, color: MM.muted, marginTop: 4, lineHeight: 1.5 }}>{e.sub}</div>
            </div>
            <Photo w={70} h={70} tone={e.t} label="" radius={8}/>
          </div>
        ))}
      </div>
      {/* Quote block */}
      <div style={{ margin: '28px 24px 0', padding: '24px 20px', background: MM.cream, borderTop: `2px solid ${MM.deep}`, borderBottom: `2px solid ${MM.deep}` }}>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM.terracotta, letterSpacing: '0.25em' }}>QUOTE OF THE WEEK</div>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 22, fontStyle: 'italic', color: MM.deep, lineHeight: 1.4, marginTop: 12, letterSpacing: '-0.01em' }}>
          "한 잔의 말차는 한 사람이 들이는 시간의 모양이다."
        </div>
        <div style={{ fontSize: 11, color: MM.muted, marginTop: 14, fontFamily: 'IBM Plex Mono, monospace', letterSpacing: '0.1em' }}>— 모리 슈코 · 一保堂 7대 다인</div>
      </div>
      <div style={{ padding: '24px 24px 0', display: 'flex', gap: 8 }}>
        {[{n:'노포',c:'matcha'},{n:'신상',c:'clay'},{n:'비건',c:'cream'},{n:'다도',c:'deep'}].map(g => (
          <div key={g.n} style={{ flex: 1, position: 'relative', borderRadius: 12, overflow: 'hidden', height: 90 }}>
            <Photo w="100%" h={90} tone={g.c} label="" radius={12}/>
            <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, transparent, rgba(0,0,0,0.5))', display: 'flex', alignItems: 'flex-end', padding: 8 }}>
              <span style={{ fontSize: 12, fontWeight: 700, color: '#fff', fontFamily: 'Noto Serif KR, serif' }}>{g.n}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
    <TabBar active="discover"/>
    <HomeIndicator/>
  </Phone>
);

Object.assign(window, {
  ScreenFilterSheet, ScreenReviewRating, ScreenReviewWrite,
  ScreenCollection, ScreenCollectionDetail, ScreenFeed, ScreenRanking,
  ScreenNearby, ScreenPlanner, ScreenProfile, ScreenWishlist, ScreenEditorial,
});
