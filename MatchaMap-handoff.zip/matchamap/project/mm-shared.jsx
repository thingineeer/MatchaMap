// MatchaMap shared components & icons
// Magazine-style with Deep Matcha palette.

const MM = {
  cream: '#f7f5ee',
  creamWarm: '#efeadb',
  paper: '#faf9f4',
  matcha: '#5a7a3a',
  matchaBright: '#6b9039',
  deep: '#2d3b1f',
  deepDark: '#1a2410',
  terracotta: '#c2410c',
  clay: '#b8744a',
  ink: '#1a1a1a',
  charcoal: '#2a2a2a',
  muted: '#8a8576',
  line: '#d9d4c3',
  lineSoft: '#e8e3d4',
  gold: '#b8943f',
};

// ─────────────────────────────────────────────────────────────
// Icons (line, 1.5px, sharp)
// ─────────────────────────────────────────────────────────────
const Icon = ({ name, size = 20, color = 'currentColor', strokeWidth = 1.5 }) => {
  const p = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: color, strokeWidth, strokeLinecap: 'round', strokeLinejoin: 'round' };
  switch (name) {
    case 'pin': return <svg {...p}><path d="M12 21s-7-7.5-7-12a7 7 0 1114 0c0 4.5-7 12-7 12z"/><circle cx="12" cy="9" r="2.5"/></svg>;
    case 'search': return <svg {...p}><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>;
    case 'star': return <svg {...p} fill={color}><path d="M12 2l3 7 7 .8-5.5 4.8L18 22l-6-3.7L6 22l1.5-7.4L2 9.8 9 9z"/></svg>;
    case 'star-empty': return <svg {...p}><path d="M12 2l3 7 7 .8-5.5 4.8L18 22l-6-3.7L6 22l1.5-7.4L2 9.8 9 9z"/></svg>;
    case 'heart': return <svg {...p}><path d="M12 21s-8-5-8-12a5 5 0 019-3 5 5 0 019 3c0 7-8 12-8 12z"/></svg>;
    case 'heart-fill': return <svg {...p} fill={color}><path d="M12 21s-8-5-8-12a5 5 0 019-3 5 5 0 019 3c0 7-8 12-8 12z"/></svg>;
    case 'bookmark': return <svg {...p}><path d="M6 3h12v18l-6-4-6 4z"/></svg>;
    case 'bookmark-fill': return <svg {...p} fill={color}><path d="M6 3h12v18l-6-4-6 4z"/></svg>;
    case 'share': return <svg {...p}><path d="M4 12v7a2 2 0 002 2h12a2 2 0 002-2v-7"/><path d="M16 6l-4-4-4 4"/><path d="M12 2v14"/></svg>;
    case 'arrow-right': return <svg {...p}><path d="M5 12h14M13 5l7 7-7 7"/></svg>;
    case 'arrow-left': return <svg {...p}><path d="M19 12H5M11 5l-7 7 7 7"/></svg>;
    case 'arrow-up': return <svg {...p}><path d="M12 19V5M5 12l7-7 7 7"/></svg>;
    case 'chevron-right': return <svg {...p}><path d="M9 6l6 6-6 6"/></svg>;
    case 'chevron-down': return <svg {...p}><path d="M6 9l6 6 6-6"/></svg>;
    case 'plus': return <svg {...p}><path d="M12 5v14M5 12h14"/></svg>;
    case 'close': return <svg {...p}><path d="M18 6L6 18M6 6l12 12"/></svg>;
    case 'check': return <svg {...p}><path d="M20 6L9 17l-5-5"/></svg>;
    case 'filter': return <svg {...p}><path d="M3 5h18M6 12h12M10 19h4"/></svg>;
    case 'sliders': return <svg {...p}><path d="M4 6h10M18 6h2M4 12h2M10 12h10M4 18h14M18 18h2"/><circle cx="16" cy="6" r="2"/><circle cx="8" cy="12" r="2"/><circle cx="16" cy="18" r="2"/></svg>;
    case 'list': return <svg {...p}><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/></svg>;
    case 'grid': return <svg {...p}><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>;
    case 'map': return <svg {...p}><path d="M9 4l-6 2v14l6-2 6 2 6-2V4l-6 2z"/><path d="M9 4v14M15 6v14"/></svg>;
    case 'compass': return <svg {...p}><circle cx="12" cy="12" r="10"/><path d="M16 8l-2 6-6 2 2-6z"/></svg>;
    case 'clock': return <svg {...p}><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>;
    case 'phone': return <svg {...p}><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg>;
    case 'globe': return <svg {...p}><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 010 20M12 2a15 15 0 000 20"/></svg>;
    case 'user': return <svg {...p}><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/></svg>;
    case 'users': return <svg {...p}><circle cx="9" cy="8" r="4"/><path d="M2 21a7 7 0 0114 0"/><circle cx="17" cy="8" r="3"/><path d="M22 21a5 5 0 00-7-4.6"/></svg>;
    case 'camera': return <svg {...p}><path d="M3 7h4l2-3h6l2 3h4v13H3z"/><circle cx="12" cy="13" r="4"/></svg>;
    case 'edit': return <svg {...p}><path d="M11 4H4v16h16v-7"/><path d="M18.5 2.5a2.1 2.1 0 113 3L12 15l-4 1 1-4z"/></svg>;
    case 'settings': return <svg {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3h0a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8v0a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/></svg>;
    case 'bell': return <svg {...p}><path d="M18 16v-5a6 6 0 10-12 0v5l-2 3h16z"/><path d="M10 21a2 2 0 004 0"/></svg>;
    case 'message': return <svg {...p}><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>;
    case 'leaf': return <svg {...p}><path d="M6 21c0-9 6-15 15-15-1 9-6 15-15 15z"/><path d="M6 21c4-4 9-7 12-9"/></svg>;
    case 'leaf-fill': return <svg {...p} fill={color}><path d="M6 21c0-9 6-15 15-15-1 9-6 15-15 15z"/></svg>;
    case 'cup': return <svg {...p}><path d="M5 8h12v6a4 4 0 01-4 4H9a4 4 0 01-4-4z"/><path d="M17 10h2a2 2 0 010 4h-2"/><path d="M7 4v2M11 3v3M15 4v2"/></svg>;
    case 'fire': return <svg {...p}><path d="M12 2s5 5 5 10a5 5 0 11-10 0c0-3 2-4 2-7 1 1 3 0 3-3z"/></svg>;
    case 'trophy': return <svg {...p}><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 01-10 0z"/><path d="M7 6H4v2a3 3 0 003 3M17 6h3v2a3 3 0 01-3 3"/></svg>;
    case 'sparkle': return <svg {...p}><path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8"/></svg>;
    case 'image': return <svg {...p}><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/></svg>;
    case 'mic': return <svg {...p}><rect x="9" y="2" width="6" height="13" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v3"/></svg>;
    case 'world-pin': return <svg {...p}><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18"/><circle cx="17" cy="8" r="1.5" fill={color}/></svg>;
    case 'door': return <svg {...p}><path d="M5 21V4a1 1 0 011-1h12a1 1 0 011 1v17"/><path d="M3 21h18M14 12h.5"/></svg>;
    case 'menu': return <svg {...p}><path d="M3 6h18M3 12h18M3 18h18"/></svg>;
    case 'sort': return <svg {...p}><path d="M3 6h18M6 12h12M9 18h6"/></svg>;
    default: return null;
  }
};

// ─────────────────────────────────────────────────────────────
// Matcha Leaf Pin (illustrated)
// ─────────────────────────────────────────────────────────────
const MatchaPin = ({ size = 36, grade = 'S', glow = false }) => {
  const colors = {
    S: { bg: MM.deep, fg: '#fff', leaf: MM.matchaBright },
    A: { bg: MM.matcha, fg: '#fff', leaf: '#e8d9b8' },
    B: { bg: MM.clay, fg: '#fff', leaf: '#fff' },
    C: { bg: MM.cream, fg: MM.deep, leaf: MM.matcha },
  };
  const c = colors[grade] || colors.A;
  return (
    <div style={{ position: 'relative', width: size, height: size * 1.2, filter: 'drop-shadow(0 4px 8px rgba(0,0,0,0.18))' }}>
      {glow && <div style={{ position: 'absolute', inset: -4, borderRadius: '50%', background: c.bg, opacity: 0.2, animation: 'mm-pulse 2s ease-out infinite' }} />}
      <svg width={size} height={size * 1.2} viewBox="0 0 36 44">
        {/* tear-drop pin */}
        <path d="M18 2 C8 2, 2 9, 2 18 C2 28, 18 42, 18 42 C18 42, 34 28, 34 18 C34 9, 28 2, 18 2 Z" fill={c.bg} stroke={MM.deepDark} strokeWidth="0.8"/>
        {/* matcha leaf inside */}
        <path d="M11 22 C11 14, 17 10, 25 10 C24 18, 19 22, 11 22 Z" fill={c.leaf} opacity="0.95"/>
        <path d="M11 22 C15 19, 20 15, 24 12" stroke={c.bg} strokeWidth="0.6" fill="none" opacity="0.5"/>
      </svg>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// Matcha grade chip
// ─────────────────────────────────────────────────────────────
const GradeChip = ({ grade = 'S', size = 'md' }) => {
  const palette = {
    S: { bg: MM.deep, fg: '#fff' },
    A: { bg: MM.matcha, fg: '#fff' },
    B: { bg: MM.clay, fg: '#fff' },
    C: { bg: '#e8e3d4', fg: MM.deep },
  };
  const c = palette[grade] || palette.A;
  const dim = size === 'sm' ? { w: 20, h: 20, fs: 10 } : size === 'lg' ? { w: 32, h: 32, fs: 14 } : { w: 24, h: 24, fs: 11 };
  return (
    <div style={{
      width: dim.w, height: dim.h, borderRadius: 4,
      background: c.bg, color: c.fg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: 'IBM Plex Mono, monospace', fontWeight: 500, fontSize: dim.fs, letterSpacing: '-0.02em',
    }}>{grade}</div>
  );
};

// Stars
const Stars = ({ value = 4.5, size = 12, color = MM.gold }) => {
  const full = Math.floor(value);
  const hasHalf = value - full >= 0.5;
  return (
    <div style={{ display: 'flex', gap: 1 }}>
      {[0,1,2,3,4].map(i => {
        const filled = i < full || (i === full && hasHalf);
        return <Icon key={i} name={filled ? 'star' : 'star-empty'} size={size} color={filled ? color : MM.line} />;
      })}
    </div>
  );
};

// Magazine-style image placeholder (with caption)
const Photo = ({ w = '100%', h = 200, label = 'PHOTO', tone = 'warm', radius = 0, style = {} }) => {
  const tones = {
    warm: 'linear-gradient(135deg, #d6cfb9 0%, #b8a983 60%, #8a7a52 100%)',
    cool: 'linear-gradient(135deg, #b8c2a8 0%, #7e8e6c 100%)',
    matcha: 'linear-gradient(135deg, #9bb878 0%, #4d6a2c 100%)',
    deep: 'linear-gradient(135deg, #3a4a2a 0%, #1f2a14 100%)',
    clay: 'linear-gradient(135deg, #d4a380 0%, #a06440 100%)',
    cream: 'linear-gradient(135deg, #ede5cf 0%, #d4c8a3 100%)',
    dark: 'linear-gradient(135deg, #3a3a32 0%, #1a1a16 100%)',
  };
  return (
    <div style={{ width: w, height: h, background: tones[tone] || tones.warm, borderRadius: radius, position: 'relative', overflow: 'hidden', flexShrink: 0, ...style }}>
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: 'repeating-linear-gradient(45deg, rgba(0,0,0,0.04) 0, rgba(0,0,0,0.04) 1px, transparent 1px, transparent 10px)',
      }}/>
      <div style={{
        position: 'absolute', bottom: 8, left: 10,
        fontFamily: 'IBM Plex Mono, monospace', fontSize: 9,
        color: tone === 'cream' ? 'rgba(0,0,0,0.4)' : 'rgba(255,255,255,0.55)',
        letterSpacing: '0.1em', textTransform: 'uppercase',
      }}>{label}</div>
    </div>
  );
};

// Bottom tab bar (5 tabs)
const TabBar = ({ active = 'map' }) => {
  const tabs = [
    { id: 'map', label: '지도', icon: 'map' },
    { id: 'discover', label: '발견', icon: 'compass' },
    { id: 'feed', label: '피드', icon: 'users' },
    { id: 'collect', label: '도감', icon: 'leaf' },
    { id: 'me', label: '내정보', icon: 'user' },
  ];
  return (
    <div className="mm-tabshadow" style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      background: 'rgba(247,245,238,0.96)', backdropFilter: 'blur(20px)',
      borderTop: `0.5px solid ${MM.lineSoft}`,
      padding: '8px 12px 28px',
      display: 'flex', justifyContent: 'space-around',
      zIndex: 30,
    }}>
      {tabs.map(t => {
        const isActive = active === t.id;
        return (
          <div key={t.id} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, flex: 1 }}>
            <Icon name={isActive && t.icon === 'leaf' ? 'leaf-fill' : t.icon} size={22} color={isActive ? MM.deep : MM.muted} strokeWidth={isActive ? 2 : 1.5}/>
            <div style={{ fontSize: 10, color: isActive ? MM.deep : MM.muted, fontWeight: isActive ? 600 : 500 }}>{t.label}</div>
          </div>
        );
      })}
    </div>
  );
};

// iOS status bar (custom — Korean time)
const StatusBar = ({ dark = false, time = '9:41' }) => {
  const c = dark ? '#fff' : MM.ink;
  return (
    <div style={{
      height: 54, padding: '18px 28px 6px',
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      position: 'relative', zIndex: 20, fontFamily: '-apple-system, system-ui',
    }}>
      <div style={{ fontSize: 16, fontWeight: 600, color: c }}>{time}</div>
      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        <svg width="17" height="11" viewBox="0 0 17 11"><rect x="0" y="7" width="3" height="4" rx="0.5" fill={c}/><rect x="4.5" y="5" width="3" height="6" rx="0.5" fill={c}/><rect x="9" y="2.5" width="3" height="8.5" rx="0.5" fill={c}/><rect x="13.5" y="0" width="3" height="11" rx="0.5" fill={c}/></svg>
        <svg width="25" height="12" viewBox="0 0 25 12"><rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/><rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/></svg>
      </div>
    </div>
  );
};

// Home indicator
const HomeIndicator = ({ dark = false }) => (
  <div style={{
    position: 'absolute', bottom: 8, left: 0, right: 0,
    display: 'flex', justifyContent: 'center', zIndex: 60, pointerEvents: 'none',
  }}>
    <div style={{ width: 134, height: 5, borderRadius: 3, background: dark ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.3)' }}/>
  </div>
);

// Phone shell
const Phone = ({ children, dark = false, w = 390, h = 844 }) => (
  <div className="mm" style={{
    width: w, height: h, background: dark ? MM.deepDark : MM.cream,
    overflow: 'hidden', position: 'relative',
    fontFamily: 'Pretendard, -apple-system, system-ui, sans-serif',
  }}>
    {children}
  </div>
);

// World map background (simplified)
const WorldMap = ({ height = 500, dark = false }) => (
  <div style={{ position: 'absolute', inset: 0, background: dark ? '#1a2410' : '#ece4d2', overflow: 'hidden' }}>
    {/* Continents as soft blobs */}
    <svg width="100%" height="100%" viewBox="0 0 390 844" preserveAspectRatio="xMidYMid slice" style={{ position: 'absolute', inset: 0 }}>
      <defs>
        <pattern id="dots" width="6" height="6" patternUnits="userSpaceOnUse">
          <circle cx="1" cy="1" r="0.6" fill={dark ? 'rgba(255,255,255,0.06)' : 'rgba(45,59,31,0.1)'}/>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#dots)"/>
      {/* North America */}
      <path d="M30 200 Q15 230, 25 280 Q40 320, 80 330 Q110 320, 120 290 Q130 250, 100 210 Q70 180, 30 200 Z" fill={dark ? '#2d3b1f' : '#dcd2b8'} opacity="0.85"/>
      {/* South America */}
      <path d="M90 380 Q80 420, 95 480 Q110 540, 125 540 Q140 510, 130 460 Q120 400, 110 380 Z" fill={dark ? '#2d3b1f' : '#dcd2b8'} opacity="0.85"/>
      {/* Europe */}
      <path d="M170 200 Q165 220, 180 240 Q200 245, 215 230 Q220 210, 200 195 Q180 190, 170 200 Z" fill={dark ? '#2d3b1f' : '#dcd2b8'} opacity="0.85"/>
      {/* Africa */}
      <path d="M180 280 Q170 320, 185 380 Q205 430, 230 420 Q240 380, 230 320 Q215 280, 195 275 Z" fill={dark ? '#2d3b1f' : '#dcd2b8'} opacity="0.85"/>
      {/* Asia */}
      <path d="M230 180 Q260 170, 320 195 Q360 220, 360 260 Q340 290, 290 285 Q250 275, 230 240 Q220 210, 230 180 Z" fill={dark ? '#2d3b1f' : '#dcd2b8'} opacity="0.85"/>
      {/* Japan */}
      <path d="M340 250 Q345 260, 348 275 Q346 285, 340 280 Q336 265, 340 250 Z" fill={MM.matcha} opacity="0.7"/>
      {/* Australia */}
      <path d="M310 430 Q300 450, 320 470 Q350 470, 355 450 Q345 430, 320 425 Z" fill={dark ? '#2d3b1f' : '#dcd2b8'} opacity="0.85"/>
    </svg>
  </div>
);

// Custom city map (beige minimal style for store/zoom views)
const CityMap = ({ children, dark = false }) => (
  <div className="mm-map" style={{ position: 'absolute', inset: 0, background: dark ? '#1a2410' : '#ece4d2' }}>
    <div style={{
      position: 'absolute', inset: 0,
      backgroundImage: dark
        ? `linear-gradient(0deg, transparent 49.7%, rgba(255,255,255,0.04) 49.7%, rgba(255,255,255,0.04) 50.3%, transparent 50.3%),
           linear-gradient(90deg, transparent 49.7%, rgba(255,255,255,0.04) 49.7%, rgba(255,255,255,0.04) 50.3%, transparent 50.3%)`
        : `linear-gradient(0deg, transparent 49.5%, #f5f0e3 49.5%, #f5f0e3 50.5%, transparent 50.5%),
           linear-gradient(90deg, transparent 49.5%, #f5f0e3 49.5%, #f5f0e3 50.5%, transparent 50.5%),
           linear-gradient(33deg, transparent 49.7%, #efe7d3 49.7%, #efe7d3 50.3%, transparent 50.3%)`,
      backgroundSize: '60px 60px, 60px 60px, 110px 110px',
    }}/>
    {/* Park */}
    <div style={{ position: 'absolute', top: '20%', left: '12%', width: 90, height: 70, background: dark ? '#243218' : '#c9d8b3', borderRadius: 18, opacity: 0.7 }}/>
    {/* River */}
    <div style={{ position: 'absolute', top: 0, bottom: 0, left: '62%', width: 30, background: dark ? '#1a2a30' : '#cfdcd4', transform: 'rotate(-8deg)' }}/>
    {/* Blocks */}
    <div style={{ position: 'absolute', top: '35%', left: '25%', width: 50, height: 30, background: dark ? '#222d18' : '#e3dcc7', borderRadius: 2 }}/>
    <div style={{ position: 'absolute', top: '55%', left: '40%', width: 70, height: 24, background: dark ? '#222d18' : '#e3dcc7', borderRadius: 2 }}/>
    <div style={{ position: 'absolute', top: '15%', left: '70%', width: 40, height: 50, background: dark ? '#222d18' : '#e3dcc7', borderRadius: 2 }}/>
    {children}
  </div>
);

Object.assign(window, { MM, Icon, MatchaPin, GradeChip, Stars, Photo, TabBar, StatusBar, HomeIndicator, Phone, WorldMap, CityMap });
