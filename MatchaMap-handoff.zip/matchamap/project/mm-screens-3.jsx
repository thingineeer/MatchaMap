// MatchaMap — Screens 25–30
// Google Maps Places API data visualizations

// ─────────────────────────────────────────────────────────────
// 25. 매장 종합 정보 (Places API full detail)
// ─────────────────────────────────────────────────────────────
const ScreenPlaceFull = () => (
  <Phone>
    <StatusBar/>
    <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 220, overflow: 'hidden' }}>
      <Photo w="100%" h={220} tone="matcha" label="GOOGLE PHOTOS · 47"/>
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(0,0,0,0.4) 0%, transparent 40%, rgba(247,245,238,1) 100%)' }}/>
    </div>
    <div style={{ position: 'absolute', top: 60, left: 16, right: 16, display: 'flex', justifyContent: 'space-between', zIndex: 10 }}>
      <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(247,245,238,0.9)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="arrow-left" size={16}/></div>
      <div style={{ display: 'flex', gap: 8 }}>
        <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(247,245,238,0.9)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="share" size={15}/></div>
        <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(247,245,238,0.9)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="bookmark" size={15}/></div>
      </div>
    </div>
    <div style={{ position: 'absolute', bottom: 12, right: 12, top: 188, width: 'auto', height: 'auto', display: 'none' }}/>
    <div style={{ position: 'absolute', top: 174, right: 12, padding: '5px 10px', borderRadius: 14, background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(8px)', color: '#fff', fontSize: 10, fontFamily: 'IBM Plex Mono, monospace', display: 'flex', alignItems: 'center', gap: 5, zIndex: 10 }}>
      <Icon name="image" size={11} color="#fff"/> 47 사진 · Google
    </div>
    <div style={{ position: 'absolute', top: 200, left: 0, right: 0, bottom: 0, padding: '20px 20px 40px', overflow: 'auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
        <GradeChip grade="S" size="sm"/>
        <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM.muted, letterSpacing: '0.15em' }}>TEA HOUSE · ¥¥¥¥</span>
      </div>
      <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 26, fontWeight: 700, color: MM.deep, lineHeight: 1.2 }}>宇治園 시부야</div>

      {/* Rating row with Google attribution */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          <Stars value={4.8} size={13}/>
          <span style={{ fontSize: 14, fontWeight: 700, color: MM.deep }}>4.8</span>
          <span style={{ fontSize: 11, color: MM.muted }}>(2,341)</span>
        </div>
        <div style={{ width: 1, height: 12, background: MM.line }}/>
        <div style={{ fontSize: 11, color: MM.matcha, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 3 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: MM.matcha }}/>
          영업중
        </div>
        <div style={{ fontSize: 11, color: MM.muted }}>· 21:00 마감</div>
      </div>

      {/* Quick action grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 8, marginTop: 16 }}>
        {[{i:'compass',l:'길찾기',h:true},{i:'phone',l:'전화'},{i:'globe',l:'웹사이트'},{i:'share',l:'공유'}].map(a => (
          <div key={a.l} style={{ padding: '10px 4px', background: a.h ? MM.deep : '#fff', color: a.h ? '#fff' : MM.deep, borderRadius: 12, border: a.h ? 'none' : `1px solid ${MM.lineSoft}`, textAlign: 'center' }}>
            <Icon name={a.i} size={16} color={a.h ? '#fff' : MM.deep}/>
            <div style={{ fontSize: 10, marginTop: 4, fontWeight: 500 }}>{a.l}</div>
          </div>
        ))}
      </div>

      {/* Address + map preview */}
      <div style={{ marginTop: 18, display: 'flex', gap: 10, padding: 12, background: '#fff', borderRadius: 12, border: `1px solid ${MM.lineSoft}` }}>
        <div style={{ width: 60, height: 60, borderRadius: 8, overflow: 'hidden', position: 'relative', flexShrink: 0 }}>
          <CityMap><div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-100%)' }}><MatchaPin size={20} grade="S"/></div></CityMap>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM.muted, letterSpacing: '0.1em' }}>ADDRESS</div>
          <div style={{ fontSize: 12, color: MM.charcoal, marginTop: 2, lineHeight: 1.4 }}>東京都渋谷区道玄坂2-29-5<br/>渋谷スクランブルスクエア 14F</div>
          <div style={{ fontSize: 10, color: MM.terracotta, fontFamily: 'IBM Plex Mono, monospace', marginTop: 4, fontWeight: 600 }}>📍 35.6580° N, 139.7016° E</div>
        </div>
      </div>

      {/* Hours expandable */}
      <div style={{ marginTop: 14, padding: 12, background: '#fff', borderRadius: 12, border: `1px solid ${MM.lineSoft}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
          <Icon name="clock" size={14} color={MM.matcha}/>
          <span style={{ fontSize: 12, fontWeight: 600, color: MM.matcha }}>영업중</span>
          <span style={{ fontSize: 11, color: MM.muted, flex: 1 }}>오후 9시에 닫음</span>
          <Icon name="chevron-down" size={14} color={MM.muted}/>
        </div>
        <div style={{ borderTop: `1px dotted ${MM.line}`, paddingTop: 10 }}>
          {[{d:'월',h:'10:00 – 21:00',today:false},{d:'화',h:'10:00 – 21:00',today:false},{d:'수',h:'10:00 – 21:00',today:true},{d:'목',h:'10:00 – 21:00'},{d:'금',h:'10:00 – 22:00'},{d:'토',h:'09:00 – 22:00'},{d:'일',h:'09:00 – 20:00'}].map(d => (
            <div key={d.d} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', fontSize: 11, color: d.today ? MM.deep : MM.muted, fontWeight: d.today ? 600 : 400 }}>
              <span style={{ fontFamily: 'IBM Plex Mono, monospace' }}>{d.d}{d.today && ' · 오늘'}</span>
              <span style={{ fontFamily: 'IBM Plex Mono, monospace' }}>{d.h}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Attributes from Google Places */}
      <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.muted, letterSpacing: '0.15em', marginTop: 22, marginBottom: 10 }}>매장 속성 · GOOGLE</div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
        {[
          { i:'check', l:'테이크아웃 가능', y:true },
          { i:'check', l:'예약 가능', y:true },
          { i:'check', l:'카드 결제', y:true },
          { i:'check', l:'Wi-Fi 무료', y:true },
          { i:'check', l:'휠체어 접근', y:true },
          { i:'close', l:'야외석', y:false },
          { i:'check', l:'비건 옵션', y:true },
          { i:'close', l:'주차 가능', y:false },
        ].map((a,i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 10px', background: '#fff', borderRadius: 8, border: `1px solid ${MM.lineSoft}` }}>
            <Icon name={a.i} size={12} color={a.y ? MM.matcha : MM.muted}/>
            <span style={{ fontSize: 11, color: a.y ? MM.charcoal : MM.muted, textDecoration: a.y ? 'none' : 'line-through' }}>{a.l}</span>
          </div>
        ))}
      </div>

      {/* Google attribution */}
      <div style={{ marginTop: 18, padding: 10, fontSize: 9, color: MM.muted, fontFamily: 'IBM Plex Mono, monospace', textAlign: 'center', letterSpacing: '0.1em' }}>
        DATA · Google Places API · 마지막 업데이트 5분 전
      </div>
    </div>
    <HomeIndicator/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 26. 인기 시간대 (Popular Times)
// ─────────────────────────────────────────────────────────────
const ScreenPopularTimes = () => {
  // % busy by hour for each day
  const hours = ['8','9','10','11','12','13','14','15','16','17','18','19','20'];
  const days = [
    { d: '월', data: [10,30,55,72,85,75,55,40,50,65,72,55,30] },
    { d: '화', data: [12,35,60,78,90,82,60,45,55,70,75,60,35] },
    { d: '수', data: [15,40,65,80,95,88,70,55,65,75,80,68,40], today: true, now: 7 },
    { d: '목', data: [10,30,55,72,85,75,55,40,50,65,72,55,30] },
    { d: '금', data: [15,42,68,85,98,90,72,58,68,82,92,80,55] },
    { d: '토', data: [25,50,72,90,99,95,82,70,80,88,90,75,50] },
    { d: '일', data: [20,45,70,88,95,88,75,62,72,80,75,55,30] },
  ];
  const today = days.find(d => d.today);
  return (
    <Phone>
      <StatusBar/>
      <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: `1px solid ${MM.lineSoft}` }}>
        <Icon name="arrow-left" size={20}/>
        <div style={{ fontSize: 15, fontWeight: 600, color: MM.deep }}>인기 시간대</div>
      </div>
      <div style={{ padding: '16px 24px 0' }}>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM.terracotta, letterSpacing: '0.2em' }}>POPULAR TIMES · 宇治園 시부야</div>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 22, fontWeight: 700, color: MM.deep, marginTop: 4, lineHeight: 1.3 }}>
          평소엔 이맘때<br/>가장 붐벼요
        </div>
        {/* Live status */}
        <div style={{ marginTop: 14, padding: 14, background: MM.deep, borderRadius: 14, color: '#fff', display: 'flex', gap: 12, alignItems: 'center' }}>
          <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#ff6b35', boxShadow: '0 0 0 4px rgba(255,107,53,0.3)' }}/>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, opacity: 0.7, fontFamily: 'IBM Plex Mono, monospace', letterSpacing: '0.1em' }}>지금 · 오후 3시</div>
            <div style={{ fontSize: 14, fontWeight: 700, marginTop: 2 }}>평소보다 <span style={{ color: '#ff8a5b' }}>약간 더 붐빔</span></div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div className="mm-display" style={{ fontSize: 22, fontWeight: 700, fontFamily: 'Noto Serif KR, serif', color: '#ff8a5b' }}>72%</div>
            <div style={{ fontSize: 9, opacity: 0.6 }}>혼잡도</div>
          </div>
        </div>
      </div>

      {/* Day selector */}
      <div style={{ padding: '20px 24px 8px', display: 'flex', gap: 4 }}>
        {days.map(d => (
          <div key={d.d} style={{ flex: 1, textAlign: 'center', padding: '8px 0', borderRadius: 8, background: d.today ? MM.deep : 'transparent', color: d.today ? '#fff' : MM.charcoal, fontSize: 12, fontWeight: d.today ? 700 : 500 }}>{d.d}</div>
        ))}
      </div>

      {/* Bar chart */}
      <div style={{ padding: '16px 24px 0' }}>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 3, height: 140, position: 'relative', borderBottom: `1px solid ${MM.line}` }}>
          {today.data.map((v, i) => {
            const isNow = i === today.now;
            const hue = v >= 80 ? '#c2410c' : v >= 60 ? MM.matcha : MM.line;
            return (
              <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', position: 'relative', height: '100%' }}>
                <div style={{ flex: 1 }}/>
                <div style={{ width: '100%', height: `${v}%`, background: isNow ? '#ff6b35' : hue, borderRadius: '3px 3px 0 0', position: 'relative' }}>
                  {isNow && <div style={{ position: 'absolute', top: -22, left: '50%', transform: 'translateX(-50%)', padding: '2px 6px', background: MM.deep, color: '#fff', fontSize: 9, fontFamily: 'IBM Plex Mono, monospace', borderRadius: 4, fontWeight: 600, whiteSpace: 'nowrap' }}>지금 · {v}%</div>}
                </div>
              </div>
            );
          })}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6 }}>
          {hours.map((h,i) => (
            <span key={i} style={{ fontSize: 9, color: MM.muted, fontFamily: 'IBM Plex Mono, monospace', flex: 1, textAlign: 'center' }}>{i % 2 === 0 ? h : ''}</span>
          ))}
        </div>
      </div>

      {/* Insights */}
      <div style={{ padding: '24px 24px 100px' }}>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM.muted, letterSpacing: '0.2em', marginBottom: 10 }}>INSIGHTS</div>
        {[
          { i:'sparkle', t:'한적할 때 방문하기', d:'화요일 오전 10시 — 가장 한가하고 다인분들이 한가로워요', c: MM.matcha },
          { i:'fire', t:'피크 타임', d:'주말 정오 — 1시간 이상 대기가 일반적', c: '#c2410c' },
          { i:'clock', t:'평균 체류 시간', d:'45분 — 정통 다도식 한 잔을 음미하기 충분한 시간', c: MM.gold },
        ].map(ins => (
          <div key={ins.t} style={{ display: 'flex', gap: 12, padding: '12px 0', borderBottom: `1px solid ${MM.lineSoft}`, alignItems: 'flex-start' }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: 'rgba(90,122,58,0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Icon name={ins.i} size={16} color={ins.c}/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: MM.deep }}>{ins.t}</div>
              <div style={{ fontSize: 11, color: MM.muted, marginTop: 2, lineHeight: 1.5 }}>{ins.d}</div>
            </div>
          </div>
        ))}
      </div>
      <HomeIndicator/>
    </Phone>
  );
};

// ─────────────────────────────────────────────────────────────
// 27. 길찾기 (Directions API)
// ─────────────────────────────────────────────────────────────
const ScreenDirections = () => (
  <Phone>
    <CityMap>
      {/* Route line */}
      <svg width="100%" height="100%" viewBox="0 0 390 600" preserveAspectRatio="none" style={{ position: 'absolute', inset: 0 }}>
        <path d="M 60 480 Q 120 420, 150 350 Q 180 280, 250 220 Q 290 180, 320 130" stroke={MM.deep} strokeWidth="5" fill="none" strokeLinecap="round" strokeDasharray="0 14" strokeDashoffset="0"/>
      </svg>
      {/* Origin */}
      <div style={{ position: 'absolute', bottom: '20%', left: '14%' }}>
        <div style={{ width: 18, height: 18, borderRadius: '50%', background: '#1e90ff', border: '4px solid #fff', boxShadow: '0 0 0 4px rgba(30,144,255,0.25)' }}/>
      </div>
      {/* Destination pin */}
      <div style={{ position: 'absolute', top: '15%', right: '16%' }}><MatchaPin size={42} grade="S" glow/></div>
      {/* Step markers */}
      <div style={{ position: 'absolute', top: '40%', left: '36%', width: 14, height: 14, borderRadius: '50%', background: '#fff', border: `3px solid ${MM.deep}` }}/>
      <div style={{ position: 'absolute', top: '28%', left: '58%', width: 14, height: 14, borderRadius: '50%', background: '#fff', border: `3px solid ${MM.deep}` }}/>
    </CityMap>
    <StatusBar/>
    {/* Top mode selector */}
    <div style={{ position: 'absolute', top: 60, left: 16, right: 16, zIndex: 10 }}>
      <div style={{ background: '#fff', borderRadius: 14, padding: '12px 14px', boxShadow: '0 4px 16px rgba(0,0,0,0.1)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
          <Icon name="arrow-left" size={18}/>
          <div style={{ flex: 1, fontSize: 13, color: MM.charcoal }}>현재 위치 → 宇治園 시부야</div>
        </div>
        <div style={{ display: 'flex', gap: 4, padding: 3, background: MM.lineSoft, borderRadius: 10 }}>
          {[{i:'door',l:'도보',t:'14분',sel:true},{i:'compass',l:'대중교통',t:'8분'},{i:'compass',l:'택시',t:'6분'},{i:'compass',l:'자전거',t:'9분'}].map((m,i) => (
            <div key={i} style={{ flex: 1, padding: '8px 4px', background: m.sel ? '#fff' : 'transparent', borderRadius: 8, textAlign: 'center', boxShadow: m.sel ? '0 1px 3px rgba(0,0,0,0.1)' : 'none' }}>
              <Icon name={m.i} size={14} color={m.sel ? MM.deep : MM.muted}/>
              <div style={{ fontSize: 10, color: m.sel ? MM.deep : MM.muted, fontWeight: m.sel ? 700 : 500, marginTop: 2 }}>{m.t}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
    {/* Bottom panel */}
    <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, background: '#fff', borderRadius: '20px 20px 0 0', padding: '12px 20px 28px', boxShadow: '0 -4px 20px rgba(0,0,0,0.1)' }}>
      <div style={{ width: 36, height: 4, background: MM.line, borderRadius: 2, margin: '0 auto 14px' }}/>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 4 }}>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 32, fontWeight: 700, color: MM.deep, lineHeight: 1 }}>14분</div>
        <div style={{ fontSize: 13, color: MM.muted }}>· 1.1 km</div>
      </div>
      <div style={{ fontSize: 12, color: MM.matcha, fontWeight: 600, marginBottom: 14 }}>오후 3:14 도착 예정</div>

      {/* Steps preview */}
      <div style={{ borderTop: `1px solid ${MM.lineSoft}`, paddingTop: 12 }}>
        {[
          { t: '도겐자카 거리를 따라 동쪽', d: '350m', i: 'arrow-right' },
          { t: '시부야 스크램블 교차로 횡단', d: '200m', i: 'arrow-up' },
          { t: '메이지 거리 진입 후 우회전', d: '450m', i: 'arrow-right' },
          { t: '스크램블 스퀘어 14F 도착', d: '100m', i: 'pin' },
        ].map((s,i) => (
          <div key={i} style={{ display: 'flex', gap: 12, padding: '8px 0', alignItems: 'center' }}>
            <div style={{ width: 28, height: 28, borderRadius: 8, background: i === 3 ? MM.deep : MM.cream, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Icon name={s.i} size={14} color={i === 3 ? '#fff' : MM.deep}/>
            </div>
            <div style={{ flex: 1, fontSize: 12, color: MM.charcoal, lineHeight: 1.4 }}>{s.t}</div>
            <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.muted }}>{s.d}</div>
          </div>
        ))}
      </div>
      <button style={{ width: '100%', height: 50, marginTop: 12, borderRadius: 25, background: MM.deep, color: '#fff', border: 'none', fontSize: 14, fontWeight: 700 }}>출발</button>
    </div>
    <HomeIndicator/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 28. 스트리트 뷰 미리보기
// ─────────────────────────────────────────────────────────────
const ScreenStreetView = () => (
  <Phone>
    <div style={{ position: 'absolute', inset: 0 }}>
      <Photo w="100%" h="100%" tone="warm" label="STREET VIEW · 360°"/>
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(0,0,0,0.4) 0%, transparent 25%, transparent 65%, rgba(0,0,0,0.7) 100%)' }}/>
    </div>
    <StatusBar dark/>
    {/* Top */}
    <div style={{ position: 'absolute', top: 60, left: 16, right: 16, zIndex: 10, display: 'flex', justifyContent: 'space-between' }}>
      <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="close" size={16} color="#fff"/></div>
      <div style={{ padding: '8px 14px', borderRadius: 18, background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', gap: 6 }}>
        <Icon name="globe" size={14} color="#fff"/>
        <span style={{ fontSize: 11, color: '#fff', fontWeight: 600, fontFamily: 'IBM Plex Mono, monospace' }}>STREET VIEW · 360°</span>
      </div>
      <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="share" size={15} color="#fff"/></div>
    </div>

    {/* Compass */}
    <div style={{ position: 'absolute', top: 130, right: 20, width: 56, height: 56, borderRadius: '50%', background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10 }}>
      <svg width="42" height="42" viewBox="0 0 42 42">
        <circle cx="21" cy="21" r="20" fill="none" stroke="rgba(255,255,255,0.3)"/>
        <path d="M21 6 L24 21 L18 21 Z" fill="#ff6b35"/>
        <path d="M21 36 L24 21 L18 21 Z" fill="rgba(255,255,255,0.7)"/>
        <text x="21" y="14" fill="#fff" fontSize="8" fontFamily="IBM Plex Mono" textAnchor="middle" fontWeight="600">N</text>
      </svg>
    </div>

    {/* Pin overlay on street */}
    <div style={{ position: 'absolute', top: '38%', left: '56%' }}>
      <div style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)', padding: '6px 10px', borderRadius: 10, marginBottom: 6 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: '#fff', fontFamily: 'Noto Serif KR, serif' }}>宇治園 시부야</div>
        <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.7)', fontFamily: 'IBM Plex Mono, monospace' }}>14F · 30m 앞</div>
      </div>
      <div style={{ display: 'flex', justifyContent: 'center' }}><MatchaPin size={32} grade="S"/></div>
    </div>

    {/* Bottom info */}
    <div style={{ position: 'absolute', bottom: 110, left: 16, right: 16, padding: 14, background: 'rgba(247,245,238,0.95)', backdropFilter: 'blur(20px)', borderRadius: 16, zIndex: 10 }}>
      <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM.terracotta, letterSpacing: '0.2em', marginBottom: 4 }}>SHIBUYA · 도겐자카 2번가</div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontSize: 13, fontWeight: 700, color: MM.deep }}>매장 입구가 보여요</div>
          <div style={{ fontSize: 11, color: MM.muted, marginTop: 2 }}>2024년 11월 촬영 · Google</div>
        </div>
        <button style={{ padding: '8px 14px', borderRadius: 18, background: MM.deep, color: '#fff', border: 'none', fontSize: 12, fontWeight: 600 }}>지도로</button>
      </div>
    </div>

    {/* Drag indicator */}
    <div style={{ position: 'absolute', bottom: 60, left: '50%', transform: 'translateX(-50%)', display: 'flex', alignItems: 'center', gap: 6, color: 'rgba(255,255,255,0.7)', fontSize: 10, fontFamily: 'IBM Plex Mono, monospace', letterSpacing: '0.1em', zIndex: 10 }}>
      <Icon name="arrow-left" size={12} color="rgba(255,255,255,0.7)"/>
      DRAG TO LOOK AROUND
      <Icon name="arrow-right" size={12} color="rgba(255,255,255,0.7)"/>
    </div>
    <HomeIndicator dark/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 29. 가격대 / 분위기 / 적합인원 (Place Attributes)
// ─────────────────────────────────────────────────────────────
const ScreenAttributes = () => (
  <Phone>
    <StatusBar/>
    <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: `1px solid ${MM.lineSoft}` }}>
      <Icon name="arrow-left" size={20}/>
      <div style={{ fontSize: 15, fontWeight: 600, color: MM.deep }}>이런 곳이에요</div>
    </div>
    <div style={{ padding: '20px 24px 100px', overflow: 'auto', height: 'calc(100% - 110px)' }}>
      <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM.terracotta, letterSpacing: '0.2em' }}>PLACE PROFILE · 宇治園 시부야</div>
      <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 24, fontWeight: 700, color: MM.deep, marginTop: 6, lineHeight: 1.3 }}>
        Google이 본 이 매장
      </div>

      {/* Price level */}
      <div style={{ marginTop: 22, padding: 16, background: '#fff', borderRadius: 14, border: `1px solid ${MM.lineSoft}` }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: MM.deep }}>가격대</div>
          <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 11, color: MM.terracotta, fontWeight: 600 }}>₩₩₩₩ · VERY EXPENSIVE</div>
        </div>
        <div style={{ display: 'flex', gap: 4, marginTop: 12 }}>
          {['₩','₩₩','₩₩₩','₩₩₩₩'].map((p,i) => (
            <div key={i} style={{ flex: 1, padding: '10px 0', borderRadius: 8, background: i === 3 ? MM.deep : MM.lineSoft, color: i === 3 ? '#fff' : MM.muted, textAlign: 'center', fontSize: 13, fontWeight: 700, fontFamily: 'IBM Plex Mono, monospace' }}>{p}</div>
          ))}
        </div>
        <div style={{ fontSize: 11, color: MM.muted, marginTop: 8, lineHeight: 1.5 }}>
          1인 평균 ¥3,500 ~ ¥6,000 · Google 사용자 1,247명의 응답
        </div>
      </div>

      {/* Vibe */}
      <div style={{ marginTop: 14, padding: 16, background: '#fff', borderRadius: 14, border: `1px solid ${MM.lineSoft}` }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: MM.deep, marginBottom: 14 }}>분위기</div>
        {[
          { l:'조용함', v: 92, opp: '활기참' },
          { l:'정통', v: 88, opp: '캐주얼' },
          { l:'고급', v: 78, opp: '편안함' },
        ].map(b => (
          <div key={b.l} style={{ marginBottom: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, marginBottom: 6 }}>
              <span style={{ color: MM.deep, fontWeight: 600 }}>{b.l}</span>
              <span style={{ color: MM.muted }}>{b.opp}</span>
            </div>
            <div style={{ height: 6, background: MM.lineSoft, borderRadius: 3, position: 'relative' }}>
              <div style={{ position: 'absolute', left: 0, top: 0, width: `${b.v}%`, height: '100%', background: `linear-gradient(90deg, ${MM.matcha}, ${MM.deep})`, borderRadius: 3 }}/>
              <div style={{ position: 'absolute', left: `calc(${b.v}% - 7px)`, top: -4, width: 14, height: 14, borderRadius: '50%', background: '#fff', border: `2px solid ${MM.deep}`, boxShadow: '0 1px 3px rgba(0,0,0,0.15)' }}/>
            </div>
          </div>
        ))}
      </div>

      {/* Good for */}
      <div style={{ marginTop: 14, padding: 16, background: '#fff', borderRadius: 14, border: `1px solid ${MM.lineSoft}` }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: MM.deep, marginBottom: 12 }}>이런 분들에게 추천</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 6 }}>
          {[
            { i:'user', l:'혼자', v: true },
            { i:'users', l:'데이트', v: true },
            { i:'users', l:'그룹', v: false },
            { i:'cup', l:'다도 입문', v: true },
            { i:'sparkle', l:'특별한 날', v: true },
            { i:'door', l:'비즈니스', v: false },
          ].map(g => (
            <div key={g.l} style={{ padding: '10px 8px', borderRadius: 10, background: g.v ? 'rgba(90,122,58,0.08)' : MM.lineSoft, border: g.v ? `1px solid ${MM.matcha}` : 'none', textAlign: 'center', opacity: g.v ? 1 : 0.5 }}>
              <Icon name={g.i} size={16} color={g.v ? MM.matcha : MM.muted}/>
              <div style={{ fontSize: 11, color: g.v ? MM.deep : MM.muted, marginTop: 4, fontWeight: 500 }}>{g.l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* What people say (Review insights) */}
      <div style={{ marginTop: 14, padding: 16, background: '#fff', borderRadius: 14, border: `1px solid ${MM.lineSoft}` }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: MM.deep }}>리뷰에서 자주 언급된</div>
          <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM.muted, letterSpacing: '0.1em' }}>2,341 REVIEWS</span>
        </div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {[
            {l:'코이차',c:412,sent:'pos'},
            {l:'다도식',c:298,sent:'pos'},
            {l:'정통',c:267,sent:'pos'},
            {l:'다인',c:189,sent:'pos'},
            {l:'분위기',c:156,sent:'pos'},
            {l:'가격',c:134,sent:'neg'},
            {l:'대기시간',c:89,sent:'neg'},
            {l:'화과자',c:72,sent:'pos'},
          ].map(t => (
            <div key={t.l} style={{ padding: '6px 11px', borderRadius: 14, background: t.sent === 'pos' ? 'rgba(90,122,58,0.1)' : 'rgba(194,65,12,0.08)', display: 'flex', alignItems: 'center', gap: 5 }}>
              <span style={{ fontSize: 12, color: t.sent === 'pos' ? MM.matcha : MM.terracotta, fontWeight: 600 }}>{t.l}</span>
              <span style={{ fontSize: 9, color: MM.muted, fontFamily: 'IBM Plex Mono, monospace' }}>{t.c}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
    <HomeIndicator/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 30. 주변 둘러보기 (Nearby Search + 카테고리)
// ─────────────────────────────────────────────────────────────
const ScreenAround = () => (
  <Phone>
    <CityMap>
      {/* user location */}
      <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)' }}>
        <div style={{ width: 18, height: 18, borderRadius: '50%', background: '#1e90ff', border: '4px solid #fff', boxShadow: '0 0 0 8px rgba(30,144,255,0.18), 0 0 0 24px rgba(30,144,255,0.08)' }}/>
      </div>
      {/* Radius circle */}
      <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', width: 240, height: 240, borderRadius: '50%', border: `1px dashed ${MM.matcha}`, opacity: 0.4 }}/>
      {/* Pins */}
      <div style={{ position: 'absolute', top: '38%', left: '38%' }}><MatchaPin size={26} grade="S"/></div>
      <div style={{ position: 'absolute', top: '40%', left: '64%' }}><MatchaPin size={24} grade="A"/></div>
      <div style={{ position: 'absolute', top: '60%', left: '54%' }}><MatchaPin size={22} grade="B"/></div>
      <div style={{ position: 'absolute', top: '64%', left: '32%' }}><MatchaPin size={22} grade="A"/></div>
    </CityMap>
    <StatusBar/>
    {/* Top search */}
    <div style={{ position: 'absolute', top: 60, left: 16, right: 16, zIndex: 5 }}>
      <div style={{ background: '#fff', borderRadius: 14, padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 10, boxShadow: '0 4px 16px rgba(0,0,0,0.08)' }}>
        <Icon name="arrow-left" size={18}/>
        <div style={{ flex: 1, fontSize: 13, fontWeight: 500, color: MM.deep }}>이 지역 둘러보기</div>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.terracotta, fontWeight: 600 }}>500M</div>
      </div>
    </div>

    {/* Category chips */}
    <div style={{ position: 'absolute', top: 118, left: 16, right: 16, display: 'flex', gap: 6, overflow: 'hidden', zIndex: 5 }}>
      {[
        {l:'☕ 말차 카페',c:24,sel:true},
        {l:'🍵 다실',c:8},
        {l:'🍰 디저트',c:12},
        {l:'🛍 매장',c:5},
        {l:'🌿 다원',c:2},
      ].map((p,i) => (
        <div key={i} style={{ padding: '7px 12px', borderRadius: 16, fontSize: 12, fontWeight: 500, background: p.sel ? MM.deep : '#fff', color: p.sel ? '#fff' : MM.deep, boxShadow: '0 2px 6px rgba(0,0,0,0.08)', display: 'flex', alignItems: 'center', gap: 5, whiteSpace: 'nowrap' }}>
          <span>{p.l}</span>
          <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, opacity: 0.7 }}>{p.c}</span>
        </div>
      ))}
    </div>

    {/* Bottom sheet */}
    <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, top: 480, background: MM.cream, borderRadius: '24px 24px 0 0', boxShadow: '0 -8px 30px rgba(0,0,0,0.12)' }}>
      <div style={{ width: 40, height: 4, background: MM.line, borderRadius: 2, margin: '12px auto 0' }}/>
      <div style={{ padding: '14px 20px 8px', display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div>
          <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 18, fontWeight: 700, color: MM.deep }}>500m 안에 24곳</div>
          <div style={{ fontSize: 11, color: MM.muted, marginTop: 2 }}>지금 영업 중인 매장 17곳</div>
        </div>
        <div style={{ display: 'flex', gap: 4 }}>
          <div style={{ width: 28, height: 28, borderRadius: 8, background: MM.deep, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="map" size={13} color="#fff"/></div>
          <div style={{ width: 28, height: 28, borderRadius: 8, background: '#fff', border: `1px solid ${MM.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="list" size={13} color={MM.muted}/></div>
        </div>
      </div>
      <div style={{ padding: '4px 16px 30px', overflow: 'auto', maxHeight: 240 }}>
        {[
          { n:'宇治園 시부야', d:'120m', t:'matcha', g:'S', open:true, busy:'한가함', wait:'대기 없음' },
          { n:'Marufuji', d:'340m', t:'deep', g:'A', open:true, busy:'평소 수준', wait:'10분' },
          { n:'茶筅 시부야', d:'420m', t:'cream', g:'A', open:false, busy:null, wait:null },
        ].map((s,i) => (
          <div key={i} style={{ display: 'flex', gap: 12, padding: '10px 8px', borderBottom: `1px solid ${MM.lineSoft}`, alignItems: 'center' }}>
            <Photo w={56} h={56} tone={s.t} label="" radius={10}/>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <GradeChip grade={s.g} size="sm"/>
                <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.terracotta, fontWeight: 600 }}>{s.d}</span>
              </div>
              <div style={{ fontSize: 13, fontWeight: 700, color: MM.deep, marginTop: 2, fontFamily: 'Noto Serif KR, serif' }}>{s.n}</div>
              {s.open ? (
                <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginTop: 2 }}>
                  <span style={{ fontSize: 10, color: MM.matcha, fontWeight: 600 }}>● 영업중</span>
                  <span style={{ fontSize: 10, color: MM.muted }}>· {s.busy} · 대기 {s.wait}</span>
                </div>
              ) : (
                <div style={{ fontSize: 10, color: MM.muted, marginTop: 2 }}>● 영업 종료 · 내일 10시 오픈</div>
              )}
            </div>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: '#fff', border: `1px solid ${MM.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="chevron-right" size={14} color={MM.deep}/>
            </div>
          </div>
        ))}
      </div>
    </div>
    <HomeIndicator/>
  </Phone>
);

Object.assign(window, {
  ScreenPlaceFull, ScreenPopularTimes, ScreenDirections, ScreenStreetView, ScreenAttributes, ScreenAround,
});
