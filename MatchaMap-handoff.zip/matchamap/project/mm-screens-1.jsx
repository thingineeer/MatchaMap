// MatchaMap — Screens 1–12
// Splash, onboarding, map views, store detail, search

// ─────────────────────────────────────────────────────────────
// 01. Splash
// ─────────────────────────────────────────────────────────────
const ScreenSplash = () => (
  <Phone dark>
    <StatusBar dark/>
    <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 32, background: 'radial-gradient(circle at 50% 40%, #2d3b1f 0%, #0f1808 100%)' }}>
      <div style={{ position: 'relative' }}>
        <svg width="88" height="100" viewBox="0 0 88 100">
          <path d="M44 8 C26 8, 14 22, 14 42 C14 64, 44 92, 44 92 C44 92, 74 64, 74 42 C74 22, 62 8, 44 8 Z" fill="#5a7a3a" stroke="#7fa450" strokeWidth="1"/>
          <path d="M28 44 C28 30, 38 24, 56 22 C54 38, 44 46, 28 44 Z" fill="#f7f5ee" opacity="0.95"/>
          <path d="M28 44 C36 38, 46 32, 54 26" stroke="#5a7a3a" strokeWidth="1" fill="none" opacity="0.5"/>
        </svg>
      </div>
      <div style={{ textAlign: 'center' }}>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 38, fontWeight: 700, color: '#f7f5ee', letterSpacing: '-0.02em' }}>말차맵</div>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 11, color: 'rgba(247,245,238,0.5)', letterSpacing: '0.3em', marginTop: 8 }}>MATCHAMAP</div>
      </div>
      <div style={{ fontSize: 13, color: 'rgba(247,245,238,0.45)', fontFamily: 'Noto Serif KR, serif', fontStyle: 'italic', marginTop: 8 }}>한 잔의 말차로 떠나는 세계</div>
    </div>
    <div style={{ position: 'absolute', bottom: 60, left: 0, right: 0, textAlign: 'center', fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: 'rgba(247,245,238,0.3)', letterSpacing: '0.2em' }}>EST. 2026 · KYOTO</div>
    <HomeIndicator dark/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 02. Onboarding 1 — Value prop
// ─────────────────────────────────────────────────────────────
const ScreenOnboarding1 = () => (
  <Phone>
    <StatusBar/>
    <Photo h={420} tone="matcha" label="HERO · MATCHA WHISKED IN BOWL" w="100%"/>
    <div style={{ position: 'absolute', top: 240, left: 0, right: 0, height: 240, background: 'linear-gradient(180deg, transparent 0%, rgba(247,245,238,0.6) 50%, #f7f5ee 100%)' }}/>
    <div style={{ position: 'absolute', top: 380, left: 24, right: 24 }}>
      <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, letterSpacing: '0.3em', color: MM.terracotta, marginBottom: 16 }}>01 · 始まり</div>
      <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 34, fontWeight: 700, color: MM.deep, lineHeight: 1.25, letterSpacing: '-0.02em' }}>
        세상의 모든<br/>말차를 찾아서.
      </div>
      <div style={{ fontSize: 15, color: MM.muted, lineHeight: 1.6, marginTop: 16 }}>
        교토의 노포부터 뉴욕의 신상 카페까지.<br/>지도 위에서 만나는 한 잔의 여정.
      </div>
    </div>
    <div style={{ position: 'absolute', bottom: 80, left: 24, right: 24 }}>
      <div style={{ display: 'flex', gap: 6, marginBottom: 24 }}>
        <div style={{ width: 24, height: 4, borderRadius: 2, background: MM.deep }}/>
        <div style={{ width: 4, height: 4, borderRadius: 2, background: MM.line }}/>
        <div style={{ width: 4, height: 4, borderRadius: 2, background: MM.line }}/>
      </div>
      <button style={{ width: '100%', height: 56, borderRadius: 32, background: MM.deep, color: '#fff', border: 'none', fontSize: 16, fontWeight: 600, fontFamily: 'inherit', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
        시작하기 <Icon name="arrow-right" size={18} color="#fff"/>
      </button>
    </div>
    <HomeIndicator/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 03. Onboarding 2 — Taste preference
// ─────────────────────────────────────────────────────────────
const ScreenOnboarding2 = () => {
  const tastes = [
    { name: '우스차', en: 'Usucha', desc: '연하고 청량한', selected: true, tone: 'matcha' },
    { name: '코이차', en: 'Koicha', desc: '진하고 부드러운', selected: true, tone: 'deep' },
    { name: '말차 라떼', en: 'Latte', desc: '우유와 함께', selected: false, tone: 'cream' },
    { name: '하우지차', en: 'Hojicha', desc: '구수한 풍미', selected: false, tone: 'clay' },
    { name: '센차', en: 'Sencha', desc: '향긋한 잎차', selected: true, tone: 'warm' },
    { name: '디저트', en: 'Sweets', desc: '말차 디저트', selected: false, tone: 'cool' },
  ];
  return (
    <Phone>
      <StatusBar/>
      <div style={{ padding: '20px 24px 0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 32 }}>
          <Icon name="arrow-left" size={22}/>
          <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 11, color: MM.muted, letterSpacing: '0.15em' }}>02 / 03</div>
          <div style={{ fontSize: 14, color: MM.muted }}>건너뛰기</div>
        </div>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 28, fontWeight: 700, color: MM.deep, lineHeight: 1.3 }}>
          어떤 말차를<br/>좋아하시나요?
        </div>
        <div style={{ fontSize: 13, color: MM.muted, marginTop: 8 }}>여러 개 선택 가능 · 추천에 활용돼요</div>
      </div>
      <div style={{ padding: '32px 16px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        {tastes.map(t => (
          <div key={t.name} style={{
            border: t.selected ? `2px solid ${MM.deep}` : `1px solid ${MM.line}`,
            background: t.selected ? MM.cream : '#fff',
            borderRadius: 16, padding: 14, position: 'relative',
            aspectRatio: '1 / 1.05',
          }}>
            <Photo h={68} tone={t.tone} label={t.en} radius={10}/>
            <div style={{ marginTop: 10, fontWeight: 600, fontSize: 15, color: MM.deep }}>{t.name}</div>
            <div style={{ fontSize: 11, color: MM.muted, marginTop: 2 }}>{t.desc}</div>
            {t.selected && <div style={{ position: 'absolute', top: 8, right: 8, width: 22, height: 22, borderRadius: '50%', background: MM.deep, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="check" size={13} color="#fff" strokeWidth={2.5}/></div>}
          </div>
        ))}
      </div>
      <div style={{ position: 'absolute', bottom: 60, left: 24, right: 24 }}>
        <button style={{ width: '100%', height: 54, borderRadius: 28, background: MM.deep, color: '#fff', border: 'none', fontSize: 15, fontWeight: 600, fontFamily: 'inherit' }}>다음</button>
      </div>
      <HomeIndicator/>
    </Phone>
  );
};

// ─────────────────────────────────────────────────────────────
// 04. Onboarding 3 — Location permission
// ─────────────────────────────────────────────────────────────
const ScreenOnboarding3 = () => (
  <Phone>
    <StatusBar/>
    <div style={{ padding: '24px 24px 0' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <Icon name="arrow-left" size={22}/>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 11, color: MM.muted }}>03 / 03</div>
        <div style={{ width: 22 }}/>
      </div>
    </div>
    <div style={{ padding: '40px 32px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <div style={{ position: 'relative', width: 220, height: 220, marginBottom: 24 }}>
        <div style={{ position: 'absolute', inset: 30, borderRadius: '50%', border: `1px dashed ${MM.matcha}`, opacity: 0.4 }}/>
        <div style={{ position: 'absolute', inset: 60, borderRadius: '50%', border: `1px dashed ${MM.matcha}`, opacity: 0.6 }}/>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <MatchaPin size={60} grade="S" glow/>
        </div>
        <div style={{ position: 'absolute', top: 40, left: 18, width: 32, height: 32, borderRadius: 8, background: MM.cream, border: `1px solid ${MM.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><MatchaPin size={20} grade="A"/></div>
        <div style={{ position: 'absolute', bottom: 30, right: 14, width: 32, height: 32, borderRadius: 8, background: MM.cream, border: `1px solid ${MM.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><MatchaPin size={20} grade="B"/></div>
      </div>
      <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 26, fontWeight: 700, color: MM.deep, lineHeight: 1.3 }}>
        주변의 말차를<br/>발견하세요
      </div>
      <div style={{ fontSize: 14, color: MM.muted, marginTop: 12, lineHeight: 1.6, maxWidth: 280 }}>
        위치 권한을 허용하면 지금 있는 곳<br/>근처의 말차 매장을 추천해드려요.
      </div>
    </div>
    <div style={{ position: 'absolute', bottom: 60, left: 24, right: 24 }}>
      <button style={{ width: '100%', height: 54, borderRadius: 28, background: MM.deep, color: '#fff', border: 'none', fontSize: 15, fontWeight: 600, fontFamily: 'inherit', marginBottom: 10 }}>위치 허용하기</button>
      <button style={{ width: '100%', height: 48, borderRadius: 28, background: 'transparent', color: MM.muted, border: 'none', fontSize: 14, fontFamily: 'inherit' }}>나중에 설정</button>
    </div>
    <HomeIndicator/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 05. Map Main — World view
// ─────────────────────────────────────────────────────────────
const ScreenMapWorld = () => (
  <Phone>
    <WorldMap/>
    <StatusBar/>
    {/* Search bar floating */}
    <div style={{ position: 'absolute', top: 60, left: 16, right: 16, zIndex: 5 }}>
      <div style={{ background: 'rgba(247,245,238,0.95)', backdropFilter: 'blur(12px)', borderRadius: 14, padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 10, boxShadow: '0 4px 16px rgba(0,0,0,0.08)' }}>
        <Icon name="search" size={18} color={MM.muted}/>
        <div style={{ flex: 1, fontSize: 14, color: MM.muted }}>도시, 매장, 말차 종류 검색</div>
        <div style={{ width: 28, height: 28, borderRadius: 8, background: MM.deep, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="sliders" size={14} color="#fff"/></div>
      </div>
      {/* Region chips */}
      <div style={{ display: 'flex', gap: 8, marginTop: 10, overflow: 'hidden' }}>
        {['전체', '🇯🇵 일본', '🇰🇷 한국', '🇺🇸 미국', '🇪🇺 유럽'].map((r,i) => (
          <div key={i} style={{
            padding: '7px 14px', borderRadius: 20, fontSize: 12, fontWeight: 500,
            background: i === 0 ? MM.deep : 'rgba(247,245,238,0.9)',
            color: i === 0 ? '#fff' : MM.charcoal,
            backdropFilter: 'blur(8px)', whiteSpace: 'nowrap',
            boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
          }}>{r}</div>
        ))}
      </div>
    </div>
    {/* Pins on world map */}
    <div style={{ position: 'absolute', top: '32%', left: '88%', zIndex: 4 }}><MatchaPin size={28} grade="S" glow/></div>
    <div style={{ position: 'absolute', top: '34%', left: '82%', zIndex: 4 }}><MatchaPin size={22} grade="A"/></div>
    <div style={{ position: 'absolute', top: '38%', left: '78%', zIndex: 4 }}><MatchaPin size={20} grade="B"/></div>
    <div style={{ position: 'absolute', top: '28%', left: '50%', zIndex: 4 }}><MatchaPin size={24} grade="A"/></div>
    <div style={{ position: 'absolute', top: '32%', left: '53%', zIndex: 4 }}><MatchaPin size={20} grade="B"/></div>
    <div style={{ position: 'absolute', top: '32%', left: '20%', zIndex: 4 }}><MatchaPin size={26} grade="A"/></div>
    <div style={{ position: 'absolute', top: '38%', left: '22%', zIndex: 4 }}><MatchaPin size={20} grade="B"/></div>
    <div style={{ position: 'absolute', top: '52%', left: '43%', zIndex: 4 }}><MatchaPin size={20} grade="C"/></div>
    <div style={{ position: 'absolute', top: '62%', left: '85%', zIndex: 4 }}><MatchaPin size={20} grade="C"/></div>

    {/* Cluster bubbles */}
    <div style={{ position: 'absolute', top: '30%', left: '70%', zIndex: 4 }}>
      <div style={{ width: 44, height: 44, borderRadius: '50%', background: MM.matcha, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 14, border: '3px solid #fff', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }}>247</div>
    </div>

    {/* Stats banner */}
    <div style={{ position: 'absolute', bottom: 180, left: 16, right: 16, background: '#fff', borderRadius: 16, padding: 16, boxShadow: '0 8px 24px rgba(0,0,0,0.1)' }}>
      <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, letterSpacing: '0.2em', color: MM.terracotta, marginBottom: 6 }}>지금 이 순간</div>
      <div style={{ fontSize: 16, fontWeight: 600, color: MM.deep, lineHeight: 1.4 }}>
        전 세계 <span style={{ color: MM.terracotta }}>1,847개</span> 매장에서<br/>말차가 우려지고 있어요
      </div>
      <div style={{ display: 'flex', gap: 16, marginTop: 12, paddingTop: 12, borderTop: `1px solid ${MM.lineSoft}` }}>
        <div><div style={{ fontSize: 18, fontWeight: 700, color: MM.deep, fontFamily: 'Noto Serif KR, serif' }}>43</div><div style={{ fontSize: 10, color: MM.muted }}>국가</div></div>
        <div><div style={{ fontSize: 18, fontWeight: 700, color: MM.deep, fontFamily: 'Noto Serif KR, serif' }}>1,847</div><div style={{ fontSize: 10, color: MM.muted }}>매장</div></div>
        <div><div style={{ fontSize: 18, fontWeight: 700, color: MM.deep, fontFamily: 'Noto Serif KR, serif' }}>12k</div><div style={{ fontSize: 10, color: MM.muted }}>리뷰</div></div>
      </div>
    </div>
    {/* FAB */}
    <div style={{ position: 'absolute', bottom: 110, right: 16, width: 48, height: 48, borderRadius: '50%', background: '#fff', boxShadow: '0 4px 12px rgba(0,0,0,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 5 }}>
      <Icon name="compass" size={22} color={MM.deep}/>
    </div>
    <TabBar active="map"/>
    <HomeIndicator/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 06. Map — City zoom (Tokyo)
// ─────────────────────────────────────────────────────────────
const ScreenMapCity = () => (
  <Phone>
    <CityMap>
      {/* labels */}
      <div style={{ position: 'absolute', top: '15%', left: '14%', fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM.muted, letterSpacing: '0.15em' }}>YOYOGI PARK</div>
      <div style={{ position: 'absolute', top: '50%', left: '30%', fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.charcoal, letterSpacing: '0.1em', fontWeight: 500 }}>SHIBUYA</div>
      <div style={{ position: 'absolute', top: '30%', left: '72%', fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.charcoal, letterSpacing: '0.1em', fontWeight: 500 }}>OMOTESANDO</div>
      {/* pins */}
      <div style={{ position: 'absolute', top: '32%', left: '38%' }}><MatchaPin size={36} grade="S" glow/></div>
      <div style={{ position: 'absolute', top: '48%', left: '52%' }}><MatchaPin size={32} grade="A"/></div>
      <div style={{ position: 'absolute', top: '60%', left: '32%' }}><MatchaPin size={30} grade="A"/></div>
      <div style={{ position: 'absolute', top: '24%', left: '68%' }}><MatchaPin size={32} grade="B"/></div>
      <div style={{ position: 'absolute', top: '70%', left: '60%' }}><MatchaPin size={28} grade="C"/></div>
      <div style={{ position: 'absolute', top: '40%', left: '78%' }}><MatchaPin size={28} grade="B"/></div>
    </CityMap>
    <StatusBar/>
    {/* search */}
    <div style={{ position: 'absolute', top: 60, left: 16, right: 16, zIndex: 5 }}>
      <div style={{ background: '#fff', borderRadius: 14, padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 10, boxShadow: '0 4px 16px rgba(0,0,0,0.1)' }}>
        <Icon name="arrow-left" size={18}/>
        <div style={{ flex: 1, fontSize: 14, fontWeight: 500, color: MM.deep }}>도쿄 시부야</div>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.muted }}>24 매장</div>
      </div>
    </div>
    {/* Filter pills */}
    <div style={{ position: 'absolute', top: 118, left: 16, right: 16, display: 'flex', gap: 6, zIndex: 5 }}>
      {[{l:'정렬', i:'sort'},{l:'등급', i:null},{l:'영업중', i:null},{l:'우스차', i:null}].map((p,i) => (
        <div key={i} style={{ padding: '7px 12px', borderRadius: 16, fontSize: 12, fontWeight: 500, background: '#fff', boxShadow: '0 2px 6px rgba(0,0,0,0.06)', display: 'flex', alignItems: 'center', gap: 4 }}>
          {p.i && <Icon name={p.i} size={12}/>}
          {p.l}
        </div>
      ))}
    </div>
    {/* Right side controls */}
    <div style={{ position: 'absolute', top: 200, right: 16, display: 'flex', flexDirection: 'column', gap: 8, zIndex: 5 }}>
      {[ 'plus', 'world-pin', 'compass'].map((i,k) => (
        <div key={k} style={{ width: 40, height: 40, borderRadius: 12, background: '#fff', boxShadow: '0 2px 8px rgba(0,0,0,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Icon name={i} size={18} color={MM.deep}/>
        </div>
      ))}
    </div>
    {/* Bottom horizontal cards */}
    <div style={{ position: 'absolute', bottom: 100, left: 0, right: 0, display: 'flex', gap: 10, paddingLeft: 16, overflow: 'hidden', zIndex: 4 }}>
      {[
        { name: '茶筅 시부야', grade: 'S', dist: '0.3km', rating: 4.9 },
        { name: 'Marufuji', grade: 'A', dist: '0.5km', rating: 4.7 },
      ].map((s,i) => (
        <div key={i} style={{ width: 280, background: '#fff', borderRadius: 16, padding: 12, display: 'flex', gap: 12, boxShadow: '0 4px 16px rgba(0,0,0,0.08)', flexShrink: 0 }}>
          <Photo w={72} h={72} tone={i === 0 ? 'matcha' : 'deep'} label={s.name} radius={10}/>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <GradeChip grade={s.grade} size="sm"/>
              <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM.muted }}>{s.dist}</div>
            </div>
            <div style={{ fontSize: 14, fontWeight: 600, color: MM.deep, marginTop: 4 }}>{s.name}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 4 }}>
              <Stars value={s.rating} size={11}/>
              <span style={{ fontSize: 11, color: MM.muted }}>{s.rating}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
    <TabBar active="map"/>
    <HomeIndicator/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 07. Map — Store preview card (slide up from pin)
// ─────────────────────────────────────────────────────────────
const ScreenMapPreview = () => (
  <Phone>
    <CityMap>
      <div style={{ position: 'absolute', top: '22%', left: '46%' }}><MatchaPin size={48} grade="S" glow/></div>
      <div style={{ position: 'absolute', top: '15%', left: '20%' }}><MatchaPin size={26} grade="A"/></div>
      <div style={{ position: 'absolute', top: '30%', left: '78%' }}><MatchaPin size={26} grade="B"/></div>
    </CityMap>
    <StatusBar/>
    {/* Slide-up sheet */}
    <div style={{ position: 'absolute', bottom: 90, left: 0, right: 0, background: MM.cream, borderRadius: '24px 24px 0 0', padding: '12px 20px 20px', boxShadow: '0 -8px 30px rgba(0,0,0,0.12)', zIndex: 10 }}>
      <div style={{ width: 40, height: 4, background: MM.line, borderRadius: 2, margin: '0 auto 16px' }}/>
      {/* Hero */}
      <div style={{ display: 'flex', gap: 14, marginBottom: 16 }}>
        <Photo w={88} h={88} tone="matcha" label="UJI" radius={12}/>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <GradeChip grade="S" size="md"/>
            <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM.terracotta, letterSpacing: '0.1em' }}>EDITOR'S PICK</span>
          </div>
          <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 22, fontWeight: 700, color: MM.deep, marginTop: 4, lineHeight: 1.2 }}>宇治園 시부야</div>
          <div style={{ fontSize: 12, color: MM.muted, marginTop: 2 }}>우지 직영 · 1854년 창업</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 6 }}>
            <Stars value={4.9} size={12}/>
            <span style={{ fontSize: 12, color: MM.deep, fontWeight: 600 }}>4.9</span>
            <span style={{ fontSize: 11, color: MM.muted }}>(2,341)</span>
          </div>
        </div>
        <div style={{ width: 36, height: 36, borderRadius: '50%', background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1px solid ${MM.line}` }}>
          <Icon name="bookmark" size={16} color={MM.deep}/>
        </div>
      </div>
      {/* Quick info row */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
        {[{i:'clock',l:'영업중'},{i:'pin',l:'0.3km'},{i:'cup',l:'우스차·코이차'}].map((q,i) => (
          <div key={i} style={{ flex: 1, padding: '8px 10px', background: '#fff', borderRadius: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
            <Icon name={q.i} size={13} color={MM.matcha}/>
            <span style={{ fontSize: 11, color: MM.charcoal, fontWeight: 500 }}>{q.l}</span>
          </div>
        ))}
      </div>
      {/* CTAs */}
      <div style={{ display: 'flex', gap: 10 }}>
        <button style={{ flex: 2, height: 48, borderRadius: 24, background: MM.deep, color: '#fff', border: 'none', fontSize: 14, fontWeight: 600, fontFamily: 'inherit' }}>매장 상세 보기</button>
        <button style={{ flex: 1, height: 48, borderRadius: 24, background: '#fff', color: MM.deep, border: `1px solid ${MM.line}`, fontSize: 13, fontWeight: 600, fontFamily: 'inherit', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
          <Icon name="compass" size={14}/>길찾기
        </button>
      </div>
    </div>
    <TabBar active="map"/>
    <HomeIndicator/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 08. Store Detail — Header + Gallery
// ─────────────────────────────────────────────────────────────
const ScreenStoreDetail = () => (
  <Phone>
    <StatusBar/>
    <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 380, overflow: 'hidden' }}>
      <Photo w="100%" h={380} tone="matcha" label="STORE HERO"/>
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(0,0,0,0.4) 0%, transparent 30%, transparent 60%, rgba(0,0,0,0.5) 100%)' }}/>
    </div>
    {/* Top buttons */}
    <div style={{ position: 'absolute', top: 60, left: 16, right: 16, display: 'flex', justifyContent: 'space-between', zIndex: 10 }}>
      <div style={{ width: 38, height: 38, borderRadius: '50%', background: 'rgba(247,245,238,0.9)', backdropFilter: 'blur(12px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Icon name="arrow-left" size={18}/>
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <div style={{ width: 38, height: 38, borderRadius: '50%', background: 'rgba(247,245,238,0.9)', backdropFilter: 'blur(12px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="share" size={16}/></div>
        <div style={{ width: 38, height: 38, borderRadius: '50%', background: 'rgba(247,245,238,0.9)', backdropFilter: 'blur(12px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="bookmark" size={16}/></div>
      </div>
    </div>
    {/* Photo count */}
    <div style={{ position: 'absolute', top: 320, right: 16, padding: '6px 12px', borderRadius: 16, background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)', color: '#fff', fontSize: 11, fontFamily: 'IBM Plex Mono, monospace', display: 'flex', alignItems: 'center', gap: 5, zIndex: 10 }}>
      <Icon name="image" size={11} color="#fff"/> 1 / 24
    </div>
    {/* Content */}
    <div style={{ position: 'absolute', top: 340, left: 0, right: 0, bottom: 0, background: MM.cream, borderRadius: '28px 28px 0 0', padding: '24px 24px 100px', overflow: 'auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <GradeChip grade="S" size="md"/>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM.terracotta, letterSpacing: '0.15em' }}>EDITOR'S PICK · TOKYO</div>
      </div>
      <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 32, fontWeight: 700, color: MM.deep, lineHeight: 1.15, letterSpacing: '-0.02em' }}>宇治園 시부야</div>
      <div style={{ fontSize: 14, color: MM.muted, marginTop: 6 }}>일본 도쿄 시부야 · 우지 직영점 · 1854年</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 14, paddingBottom: 18, borderBottom: `1px solid ${MM.lineSoft}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <Stars value={4.9} size={14}/>
          <span style={{ fontSize: 14, fontWeight: 700, color: MM.deep }}>4.9</span>
          <span style={{ fontSize: 12, color: MM.muted }}>(2,341)</span>
        </div>
        <div style={{ width: 1, height: 14, background: MM.line }}/>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 12, color: MM.matcha, fontWeight: 600 }}>
          <Icon name="clock" size={12}/>영업중 · 21시 마감
        </div>
      </div>
      {/* Tabs */}
      <div style={{ display: 'flex', gap: 24, marginTop: 18, borderBottom: `1px solid ${MM.lineSoft}` }}>
        {['소개', '메뉴', '리뷰', '사진'].map((t,i) => (
          <div key={t} style={{ padding: '10px 0', fontSize: 14, fontWeight: i === 0 ? 700 : 500, color: i === 0 ? MM.deep : MM.muted, borderBottom: i === 0 ? `2px solid ${MM.deep}` : 'none', marginBottom: -1 }}>{t}</div>
        ))}
      </div>
      {/* About */}
      <div style={{ marginTop: 18 }}>
        <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 17, fontWeight: 600, color: MM.deep, marginBottom: 10 }}>이야기</div>
        <div style={{ fontSize: 14, color: MM.charcoal, lineHeight: 1.7 }}>
          1854년 우지 본점에서 시작해 7대째 이어지는 노포. 자체 다원에서 직접 재배한 잎으로 매일 아침 돌절구로 갈아낸 말차를 정통 다도식으로 제공합니다.
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 14 }}>
          {['#정통다도', '#우지직영', '#노포', '#7대째'].map(t => (
            <div key={t} style={{ padding: '5px 10px', borderRadius: 12, background: '#fff', border: `1px solid ${MM.lineSoft}`, fontSize: 11, color: MM.muted }}>{t}</div>
          ))}
        </div>
      </div>
      {/* Gallery preview */}
      <div style={{ marginTop: 22 }}>
        <div style={{ display: 'flex', gap: 8 }}>
          <Photo w={120} h={120} tone="matcha" label="01" radius={12}/>
          <Photo w={120} h={120} tone="deep" label="02" radius={12}/>
          <div style={{ width: 60, height: 120, borderRadius: 12, background: MM.deep, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', flexShrink: 0 }}>
            <span style={{ fontSize: 16, fontWeight: 700, fontFamily: 'Noto Serif KR, serif' }}>+22</span>
            <span style={{ fontSize: 9, opacity: 0.7 }}>사진</span>
          </div>
        </div>
      </div>
    </div>
    {/* Sticky CTA */}
    <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '12px 16px 28px', background: MM.cream, borderTop: `1px solid ${MM.lineSoft}`, display: 'flex', gap: 8, zIndex: 20 }}>
      <button style={{ width: 48, height: 48, borderRadius: 24, background: '#fff', border: `1px solid ${MM.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="phone" size={18} color={MM.deep}/></button>
      <button style={{ flex: 1, height: 48, borderRadius: 24, background: MM.deep, color: '#fff', border: 'none', fontSize: 14, fontWeight: 600, fontFamily: 'inherit' }}>예약 / 길찾기</button>
    </div>
    <HomeIndicator/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 09. Store — Menu tab
// ─────────────────────────────────────────────────────────────
const ScreenStoreMenu = () => {
  const menu = [
    { cat: '말차 단품', items: [
      { name: '특상 코이차', en: 'Tokujou Koicha', desc: '직영 다원 최고급 잎', price: '¥2,400', tag: 'S' },
      { name: '우스차 (碧)', en: 'Usucha · Midori', desc: '청량하고 산뜻한 입맛', price: '¥1,200', tag: 'A' },
      { name: '계절 한정 코이차', en: '初摘み', desc: '5월 첫물 잎', price: '¥3,800', tag: 'S', limited: true },
    ]},
    { cat: '디저트 페어링', items: [
      { name: '말차 와라비모찌', en: 'Warabi-mochi', desc: '직접 만든 화과자', price: '¥980', tag: 'A' },
      { name: '말차 파르페', en: 'Parfait', desc: '시즈오카 우유', price: '¥1,650', tag: 'A' },
    ]},
  ];
  return (
    <Phone>
      <StatusBar/>
      <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: `1px solid ${MM.lineSoft}` }}>
        <Icon name="arrow-left" size={20}/>
        <div style={{ fontSize: 15, fontWeight: 600, color: MM.deep }}>宇治園 시부야</div>
        <div style={{ flex: 1 }}/>
        <Icon name="share" size={18}/>
      </div>
      {/* Sub tabs */}
      <div style={{ display: 'flex', gap: 24, padding: '12px 24px 0', borderBottom: `1px solid ${MM.lineSoft}` }}>
        {['소개', '메뉴', '리뷰', '사진'].map((t,i) => (
          <div key={t} style={{ padding: '10px 0', fontSize: 14, fontWeight: i === 1 ? 700 : 500, color: i === 1 ? MM.deep : MM.muted, borderBottom: i === 1 ? `2px solid ${MM.deep}` : 'none', marginBottom: -1 }}>{t}</div>
        ))}
      </div>
      <div style={{ padding: '20px 24px 100px', overflow: 'auto', height: 'calc(100% - 200px)' }}>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM.muted, letterSpacing: '0.15em', marginBottom: 16 }}>MENU · 2026 SPRING</div>
        {menu.map(g => (
          <div key={g.cat} style={{ marginBottom: 28 }}>
            <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 19, fontWeight: 700, color: MM.deep, marginBottom: 12, paddingBottom: 8, borderBottom: `1px solid ${MM.deep}` }}>{g.cat}</div>
            {g.items.map((it,i) => (
              <div key={i} style={{ display: 'flex', gap: 14, padding: '14px 0', borderBottom: `1px dotted ${MM.line}` }}>
                <Photo w={72} h={72} tone={it.tag === 'S' ? 'deep' : 'matcha'} label={it.en} radius={10}/>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <GradeChip grade={it.tag} size="sm"/>
                    {it.limited && <div style={{ fontSize: 9, padding: '2px 6px', background: MM.terracotta, color: '#fff', borderRadius: 4, fontWeight: 600, letterSpacing: '0.05em' }}>한정</div>}
                  </div>
                  <div style={{ fontSize: 15, fontWeight: 600, color: MM.deep, marginTop: 4 }}>{it.name}</div>
                  <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.muted, marginTop: 1 }}>{it.en}</div>
                  <div style={{ fontSize: 12, color: MM.muted, marginTop: 4, lineHeight: 1.4 }}>{it.desc}</div>
                </div>
                <div style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 16, fontWeight: 700, color: MM.deep, alignSelf: 'flex-start' }}>{it.price}</div>
              </div>
            ))}
          </div>
        ))}
      </div>
      <HomeIndicator/>
    </Phone>
  );
};

// ─────────────────────────────────────────────────────────────
// 10. Store — Reviews tab
// ─────────────────────────────────────────────────────────────
const ScreenStoreReviews = () => {
  const reviews = [
    { user: '미나', avatar: 'cream', date: '2026.04.28', rating: 5, text: '교토 우지 본점만큼 깊은 코이차의 풍미. 다완을 받쳐드는 다도가의 손짓 하나하나가 예술이었어요.', photos: 3, likes: 47 },
    { user: 'yuki', avatar: 'matcha', date: '2026.04.21', rating: 4.5, text: '도쿄에서 정통 말차를 마실 수 있는 몇 안 되는 곳. 가격은 있지만 그만한 값어치를 합니다.', photos: 2, likes: 22 },
    { user: 'gibson', avatar: 'clay', date: '2026.04.15', rating: 5, text: 'A real gem in Shibuya. The owner explained each step of the tea ceremony.', photos: 1, likes: 18 },
  ];
  return (
    <Phone>
      <StatusBar/>
      <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: `1px solid ${MM.lineSoft}` }}>
        <Icon name="arrow-left" size={20}/>
        <div style={{ fontSize: 15, fontWeight: 600, color: MM.deep }}>宇治園 시부야</div>
        <div style={{ flex: 1 }}/>
        <Icon name="share" size={18}/>
      </div>
      <div style={{ display: 'flex', gap: 24, padding: '12px 24px 0', borderBottom: `1px solid ${MM.lineSoft}` }}>
        {['소개', '메뉴', '리뷰', '사진'].map((t,i) => (
          <div key={t} style={{ padding: '10px 0', fontSize: 14, fontWeight: i === 2 ? 700 : 500, color: i === 2 ? MM.deep : MM.muted, borderBottom: i === 2 ? `2px solid ${MM.deep}` : 'none', marginBottom: -1 }}>{t}</div>
        ))}
      </div>
      {/* Rating summary */}
      <div style={{ padding: '20px 24px', display: 'flex', gap: 20, alignItems: 'center', borderBottom: `1px solid ${MM.lineSoft}` }}>
        <div style={{ textAlign: 'center' }}>
          <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 44, fontWeight: 700, color: MM.deep, lineHeight: 1 }}>4.9</div>
          <Stars value={4.9} size={11}/>
          <div style={{ fontSize: 10, color: MM.muted, marginTop: 4 }}>2,341개</div>
        </div>
        <div style={{ flex: 1 }}>
          {[5,4,3,2,1].map(n => (
            <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
              <span style={{ fontSize: 10, color: MM.muted, width: 10 }}>{n}</span>
              <div style={{ flex: 1, height: 4, background: MM.lineSoft, borderRadius: 2, overflow: 'hidden' }}>
                <div style={{ width: `${[88,8,2,1,1][5-n]}%`, height: '100%', background: MM.matcha }}/>
              </div>
              <span style={{ fontSize: 10, color: MM.muted, width: 24, textAlign: 'right', fontFamily: 'IBM Plex Mono, monospace' }}>{[88,8,2,1,1][5-n]}%</span>
            </div>
          ))}
        </div>
      </div>
      {/* Reviews */}
      <div style={{ padding: '8px 24px 100px', overflow: 'auto' }}>
        {reviews.map((r,i) => (
          <div key={i} style={{ padding: '16px 0', borderBottom: `1px solid ${MM.lineSoft}` }}>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 8 }}>
              <Photo w={36} h={36} tone={r.avatar} label="" radius={18}/>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: MM.deep }}>{r.user}</div>
                <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.muted }}>{r.date}</div>
              </div>
              <Stars value={r.rating} size={11}/>
            </div>
            <div style={{ fontSize: 14, color: MM.charcoal, lineHeight: 1.6 }}>{r.text}</div>
            {r.photos > 0 && (
              <div style={{ display: 'flex', gap: 4, marginTop: 8 }}>
                {Array(r.photos).fill(0).map((_,j) => <Photo key={j} w={64} h={64} tone={['matcha','deep','clay'][j]} label="" radius={6}/>)}
              </div>
            )}
            <div style={{ display: 'flex', gap: 14, marginTop: 10 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: MM.muted }}><Icon name="heart" size={12}/>{r.likes}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: MM.muted }}><Icon name="message" size={12}/>댓글</div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ position: 'absolute', bottom: 28, right: 16, padding: '12px 18px', borderRadius: 24, background: MM.deep, color: '#fff', display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, fontWeight: 600, boxShadow: '0 6px 16px rgba(45,59,31,0.3)' }}>
        <Icon name="edit" size={14} color="#fff"/> 리뷰 작성
      </div>
      <HomeIndicator/>
    </Phone>
  );
};

// ─────────────────────────────────────────────────────────────
// 11. Search — Initial state
// ─────────────────────────────────────────────────────────────
const ScreenSearch = () => (
  <Phone>
    <StatusBar/>
    <div style={{ padding: '12px 16px 0', display: 'flex', gap: 10, alignItems: 'center' }}>
      <div style={{ flex: 1, height: 44, background: '#fff', borderRadius: 14, padding: '0 14px', display: 'flex', alignItems: 'center', gap: 10, border: `1px solid ${MM.line}` }}>
        <Icon name="search" size={16} color={MM.muted}/>
        <div style={{ flex: 1, fontSize: 14, color: MM.muted }}>검색어를 입력하세요</div>
        <Icon name="mic" size={16} color={MM.muted}/>
      </div>
      <div style={{ fontSize: 14, color: MM.deep, fontWeight: 600 }}>취소</div>
    </div>
    <div style={{ padding: '24px' }}>
      <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 17, fontWeight: 700, color: MM.deep, marginBottom: 14 }}>최근 검색</div>
      {['시부야 우지원', '코이차 도쿄', '말차 라떼 서울'].map((q,i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 0', borderBottom: `1px solid ${MM.lineSoft}` }}>
          <Icon name="clock" size={16} color={MM.muted}/>
          <div style={{ flex: 1, fontSize: 14, color: MM.charcoal }}>{q}</div>
          <Icon name="close" size={14} color={MM.muted}/>
        </div>
      ))}
      <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 17, fontWeight: 700, color: MM.deep, marginTop: 28, marginBottom: 14 }}>지금 인기 있는</div>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        {[{t:'#쿄토 노포',c:1},{t:'#서울 신상',c:2},{t:'#코이차',c:3},{t:'#말차 디저트',c:4},{t:'#뉴욕',c:5},{t:'#비건',c:6}].map(c => (
          <div key={c.t} style={{ padding: '8px 14px', borderRadius: 20, background: c.c <= 3 ? MM.deep : '#fff', color: c.c <= 3 ? '#fff' : MM.deep, border: c.c <= 3 ? 'none' : `1px solid ${MM.line}`, fontSize: 12, fontWeight: 500, display: 'flex', alignItems: 'center', gap: 6 }}>
            {c.c <= 3 && <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, opacity: 0.7 }}>0{c.c}</span>}
            {c.t}
          </div>
        ))}
      </div>
      <div className="mm-display" style={{ fontFamily: 'Noto Serif KR, serif', fontSize: 17, fontWeight: 700, color: MM.deep, marginTop: 28, marginBottom: 14 }}>도시별 둘러보기</div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {[{c:'TOKYO',k:'도쿄',n:'247',t:'matcha'},{c:'KYOTO',k:'쿄토',n:'412',t:'deep'},{c:'SEOUL',k:'서울',n:'89',t:'cream'},{c:'NEW YORK',k:'뉴욕',n:'56',t:'clay'}].map(c => (
          <div key={c.c} style={{ position: 'relative', borderRadius: 14, overflow: 'hidden', height: 96 }}>
            <Photo w="100%" h={96} tone={c.t} label={c.c}/>
            <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, transparent 30%, rgba(0,0,0,0.6))', padding: 12, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
              <div style={{ color: '#fff', fontFamily: 'Noto Serif KR, serif', fontWeight: 700, fontSize: 15 }}>{c.k}</div>
              <div style={{ color: 'rgba(255,255,255,0.7)', fontSize: 10, fontFamily: 'IBM Plex Mono, monospace' }}>{c.n} 매장</div>
            </div>
          </div>
        ))}
      </div>
    </div>
    <HomeIndicator/>
  </Phone>
);

// ─────────────────────────────────────────────────────────────
// 12. Search Results + Filters
// ─────────────────────────────────────────────────────────────
const ScreenSearchResults = () => {
  const results = [
    { name: '宇治園 시부야', city: '도쿄 · 시부야', grade: 'S', rating: 4.9, reviews: 2341, dist: '0.3km', tone: 'matcha', tags: ['우스차','코이차','노포'] },
    { name: 'Marufuji Tea House', city: '도쿄 · 오모테산도', grade: 'A', rating: 4.7, reviews: 892, dist: '1.2km', tone: 'deep', tags: ['우스차','디저트'] },
    { name: '茶筅', city: '도쿄 · 긴자', grade: 'A', rating: 4.6, reviews: 412, dist: '2.4km', tone: 'cream', tags: ['라떼','테이크아웃'] },
    { name: 'Sabō Tsubaki', city: '도쿄 · 진보쵸', grade: 'B', rating: 4.4, reviews: 198, dist: '3.1km', tone: 'clay', tags: ['디저트','북카페'] },
  ];
  return (
    <Phone>
      <StatusBar/>
      <div style={{ padding: '12px 16px 0', display: 'flex', gap: 10, alignItems: 'center' }}>
        <Icon name="arrow-left" size={20}/>
        <div style={{ flex: 1, height: 40, background: '#fff', borderRadius: 12, padding: '0 12px', display: 'flex', alignItems: 'center', gap: 8, border: `1px solid ${MM.line}` }}>
          <Icon name="search" size={14} color={MM.muted}/>
          <div style={{ flex: 1, fontSize: 13, color: MM.deep, fontWeight: 500 }}>도쿄 코이차</div>
          <Icon name="close" size={14} color={MM.muted}/>
        </div>
      </div>
      {/* Filter row */}
      <div style={{ padding: '14px 16px 12px', display: 'flex', gap: 6, overflow: 'hidden' }}>
        {[{l:'필터',i:'sliders',hl:true},{l:'정렬',i:'sort'},{l:'등급 A↑',i:null,active:true},{l:'영업중',i:null,active:true},{l:'1km 이내',i:null}].map((p,i) => (
          <div key={i} style={{ padding: '7px 12px', borderRadius: 16, fontSize: 12, fontWeight: 500, background: p.active ? MM.deep : p.hl ? '#fff' : '#fff', color: p.active ? '#fff' : MM.deep, border: p.active ? 'none' : `1px solid ${MM.line}`, display: 'flex', alignItems: 'center', gap: 4, whiteSpace: 'nowrap' }}>
            {p.i && <Icon name={p.i} size={12} color={p.active ? '#fff' : MM.deep}/>}
            {p.l}
          </div>
        ))}
      </div>
      <div style={{ padding: '0 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 11, color: MM.muted, letterSpacing: '0.1em' }}>{results.length}개 결과 · 평점 높은 순</div>
        <div style={{ display: 'flex', gap: 4 }}>
          <div style={{ width: 28, height: 28, borderRadius: 8, background: MM.deep, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="list" size={14} color="#fff"/></div>
          <div style={{ width: 28, height: 28, borderRadius: 8, background: '#fff', border: `1px solid ${MM.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="map" size={14} color={MM.muted}/></div>
        </div>
      </div>
      <div style={{ overflow: 'auto', height: 'calc(100% - 230px)', padding: '0 16px 100px' }}>
        {results.map((r,i) => (
          <div key={i} style={{ display: 'flex', gap: 12, padding: '14px 0', borderBottom: `1px solid ${MM.lineSoft}` }}>
            <Photo w={88} h={88} tone={r.tone} label={r.name.slice(0,3)} radius={10}/>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 3 }}>
                <GradeChip grade={r.grade} size="sm"/>
                <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: MM.muted }}>{r.dist}</div>
              </div>
              <div style={{ fontSize: 15, fontWeight: 700, color: MM.deep, fontFamily: 'Noto Serif KR, serif' }}>{r.name}</div>
              <div style={{ fontSize: 11, color: MM.muted, marginTop: 1 }}>{r.city}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 5 }}>
                <Stars value={r.rating} size={11}/>
                <span style={{ fontSize: 11, fontWeight: 600, color: MM.deep }}>{r.rating}</span>
                <span style={{ fontSize: 10, color: MM.muted }}>({r.reviews.toLocaleString()})</span>
              </div>
              <div style={{ display: 'flex', gap: 4, marginTop: 6 }}>
                {r.tags.map(t => <span key={t} style={{ fontSize: 10, color: MM.matcha, background: 'rgba(90,122,58,0.08)', padding: '2px 6px', borderRadius: 4 }}>{t}</span>)}
              </div>
            </div>
            <Icon name="bookmark" size={16} color={MM.muted}/>
          </div>
        ))}
      </div>
      <HomeIndicator/>
    </Phone>
  );
};

Object.assign(window, {
  ScreenSplash, ScreenOnboarding1, ScreenOnboarding2, ScreenOnboarding3,
  ScreenMapWorld, ScreenMapCity, ScreenMapPreview, ScreenStoreDetail,
  ScreenStoreMenu, ScreenStoreReviews, ScreenSearch, ScreenSearchResults,
});
