// MatchaMap v2 — lighter, white-toned, feminine palette
// Reuses Icon, Stars, Photo, MatchaPin, GradeChip from window (mm-shared.jsx)
// but overrides MM2 palette and provides v2 frame components.

const MM2 = {
  // Soft white/cream base
  bg: '#fbfaf7',
  paper: '#ffffff',
  cream: '#f5f1ea',
  // Muted matcha (less saturated, dustier)
  matcha: '#7a9560',
  matchaSoft: '#a8b994',
  matchaPale: '#e6ecde',
  deep: '#3d4a2d',          // softer than v1's #2d3b1f
  // Feminine accent — dusty rose / clay
  rose: '#c98b85',
  rosePale: '#f0d9d5',
  blush: '#e8c4c0',
  // Neutrals
  ink: '#2a2a2a',
  charcoal: '#3a3a3a',
  text: '#4a4a45',
  muted: '#a39e92',
  mutedSoft: '#c4bfb2',
  line: '#ebe7dc',
  lineSoft: '#f2efe6',
  gold: '#c9a566',
};

// ─── v2 status bar (lighter) ───
const StatusBar2 = ({ dark = false, time = '9:41' }) => {
  const c = dark ? '#fff' : MM2.ink;
  return (
    <div style={{ height: 54, padding: '18px 28px 6px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'relative', zIndex: 20, fontFamily: '-apple-system, system-ui' }}>
      <div style={{ fontSize: 16, fontWeight: 600, color: c }}>{time}</div>
      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        <svg width="17" height="11" viewBox="0 0 17 11"><rect x="0" y="7" width="3" height="4" rx="0.5" fill={c}/><rect x="4.5" y="5" width="3" height="6" rx="0.5" fill={c}/><rect x="9" y="2.5" width="3" height="8.5" rx="0.5" fill={c}/><rect x="13.5" y="0" width="3" height="11" rx="0.5" fill={c}/></svg>
        <svg width="25" height="12" viewBox="0 0 25 12"><rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.4" fill="none"/><rect x="2" y="2" width="19" height="8" rx="1.5" fill={c}/></svg>
      </div>
    </div>
  );
};

const HomeIndicator2 = ({ dark = false }) => (
  <div style={{ position: 'absolute', bottom: 8, left: 0, right: 0, display: 'flex', justifyContent: 'center', zIndex: 60, pointerEvents: 'none' }}>
    <div style={{ width: 134, height: 5, borderRadius: 3, background: dark ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.25)' }}/>
  </div>
);

const Phone2 = ({ children, w = 390, h = 844, bg = MM2.bg }) => (
  <div className="mm" style={{ width: w, height: h, background: bg, overflow: 'hidden', position: 'relative', fontFamily: 'Pretendard, -apple-system, system-ui, sans-serif', color: MM2.text }}>
    {children}
  </div>
);

// v2 tab bar — 4 tabs (지도/피드/위시리스트/내정보)
const TabBar2 = ({ active = 'map' }) => {
  const tabs = [
    { id: 'map', label: '지도', icon: 'map' },
    { id: 'feed', label: '피드', icon: 'users' },
    { id: 'wish', label: '위시리스트', icon: 'bookmark' },
    { id: 'me', label: '내정보', icon: 'user' },
  ];
  return (
    <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, background: 'rgba(255,255,255,0.96)', backdropFilter: 'blur(20px)', borderTop: `0.5px solid ${MM2.lineSoft}`, padding: '8px 12px 28px', display: 'flex', justifyContent: 'space-around', zIndex: 30 }}>
      {tabs.map(t => {
        const isActive = active === t.id;
        return (
          <div key={t.id} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, flex: 1 }}>
            <Icon name={isActive && t.icon === 'bookmark' ? 'bookmark-fill' : t.icon} size={22} color={isActive ? MM2.deep : MM2.muted} strokeWidth={isActive ? 2 : 1.5}/>
            <div style={{ fontSize: 10, color: isActive ? MM2.deep : MM2.muted, fontWeight: isActive ? 600 : 500 }}>{t.label}</div>
          </div>
        );
      })}
    </div>
  );
};

// v2 city map — even lighter, more white
const CityMap2 = ({ children }) => (
  <div style={{ position: 'absolute', inset: 0, background: '#f6f3eb' }}>
    <div style={{
      position: 'absolute', inset: 0,
      backgroundImage: `linear-gradient(0deg, transparent 49.5%, #fbf9f3 49.5%, #fbf9f3 50.5%, transparent 50.5%),
                        linear-gradient(90deg, transparent 49.5%, #fbf9f3 49.5%, #fbf9f3 50.5%, transparent 50.5%),
                        linear-gradient(33deg, transparent 49.7%, #f1ede1 49.7%, #f1ede1 50.3%, transparent 50.3%)`,
      backgroundSize: '60px 60px, 60px 60px, 110px 110px',
    }}/>
    {/* Park (soft sage) */}
    <div style={{ position: 'absolute', top: '20%', left: '12%', width: 90, height: 70, background: '#dde6cf', borderRadius: 18, opacity: 0.8 }}/>
    {/* River (very pale blue) */}
    <div style={{ position: 'absolute', top: 0, bottom: 0, left: '62%', width: 30, background: '#e3eae5', transform: 'rotate(-8deg)' }}/>
    {/* Blocks */}
    <div style={{ position: 'absolute', top: '35%', left: '25%', width: 50, height: 30, background: '#ede8d9', borderRadius: 2 }}/>
    <div style={{ position: 'absolute', top: '55%', left: '40%', width: 70, height: 24, background: '#ede8d9', borderRadius: 2 }}/>
    <div style={{ position: 'absolute', top: '15%', left: '70%', width: 40, height: 50, background: '#ede8d9', borderRadius: 2 }}/>
    {children}
  </div>
);

// v2 world map — lighter
const WorldMap2 = () => (
  <div style={{ position: 'absolute', inset: 0, background: '#f1ece0', overflow: 'hidden' }}>
    <svg width="100%" height="100%" viewBox="0 0 390 844" preserveAspectRatio="xMidYMid slice" style={{ position: 'absolute', inset: 0 }}>
      <defs>
        <pattern id="dots2" width="6" height="6" patternUnits="userSpaceOnUse">
          <circle cx="1" cy="1" r="0.5" fill="rgba(61,74,45,0.06)"/>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#dots2)"/>
      <path d="M30 200 Q15 230, 25 280 Q40 320, 80 330 Q110 320, 120 290 Q130 250, 100 210 Q70 180, 30 200 Z" fill="#e6dfc8" opacity="0.9"/>
      <path d="M90 380 Q80 420, 95 480 Q110 540, 125 540 Q140 510, 130 460 Q120 400, 110 380 Z" fill="#e6dfc8" opacity="0.9"/>
      <path d="M170 200 Q165 220, 180 240 Q200 245, 215 230 Q220 210, 200 195 Q180 190, 170 200 Z" fill="#e6dfc8" opacity="0.9"/>
      <path d="M180 280 Q170 320, 185 380 Q205 430, 230 420 Q240 380, 230 320 Q215 280, 195 275 Z" fill="#e6dfc8" opacity="0.9"/>
      <path d="M230 180 Q260 170, 320 195 Q360 220, 360 260 Q340 290, 290 285 Q250 275, 230 240 Q220 210, 230 180 Z" fill="#e6dfc8" opacity="0.9"/>
      <path d="M340 250 Q345 260, 348 275 Q346 285, 340 280 Q336 265, 340 250 Z" fill={MM2.matchaSoft} opacity="0.85"/>
      <path d="M310 430 Q300 450, 320 470 Q350 470, 355 450 Q345 430, 320 425 Z" fill="#e6dfc8" opacity="0.9"/>
    </svg>
  </div>
);

// v2 pin — softer
const MatchaPin2 = ({ size = 36, grade = 'S', glow = false }) => {
  const colors = {
    S: { bg: MM2.deep, leaf: MM2.matchaSoft },
    A: { bg: MM2.matcha, leaf: '#f0e8d4' },
    B: { bg: MM2.rose, leaf: '#fff' },
    C: { bg: '#fff', leaf: MM2.matcha },
  };
  const c = colors[grade] || colors.A;
  return (
    <div style={{ position: 'relative', width: size, height: size * 1.2, filter: 'drop-shadow(0 3px 6px rgba(61,74,45,0.18))' }}>
      {glow && <div style={{ position: 'absolute', inset: -4, borderRadius: '50%', background: c.bg, opacity: 0.18, animation: 'mm-pulse 2s ease-out infinite' }} />}
      <svg width={size} height={size * 1.2} viewBox="0 0 36 44">
        <path d="M18 2 C8 2, 2 9, 2 18 C2 28, 18 42, 18 42 C18 42, 34 28, 34 18 C34 9, 28 2, 18 2 Z" fill={c.bg} stroke="rgba(0,0,0,0.06)" strokeWidth="0.6"/>
        <path d="M11 22 C11 14, 17 10, 25 10 C24 18, 19 22, 11 22 Z" fill={c.leaf} opacity="0.95"/>
      </svg>
    </div>
  );
};

// v2 grade chip — softer
const GradeChip2 = ({ grade = 'S', size = 'md' }) => {
  const palette = {
    S: { bg: MM2.deep, fg: '#fff' },
    A: { bg: MM2.matcha, fg: '#fff' },
    B: { bg: MM2.rose, fg: '#fff' },
    C: { bg: MM2.cream, fg: MM2.deep },
  };
  const c = palette[grade] || palette.A;
  const dim = size === 'sm' ? { w: 20, h: 20, fs: 10 } : size === 'lg' ? { w: 32, h: 32, fs: 14 } : { w: 24, h: 24, fs: 11 };
  return (
    <div style={{ width: dim.w, height: dim.h, borderRadius: 4, background: c.bg, color: c.fg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'IBM Plex Mono, monospace', fontWeight: 500, fontSize: dim.fs }}>{grade}</div>
  );
};

// Lottie placeholder — animated dotted ring with leaf
const LottiePlaceholder = ({ size = 200, label = 'LOTTIE · 말차를 발견하세요' }) => (
  <div style={{ position: 'relative', width: size, height: size }}>
    <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: `1.5px dashed ${MM2.matchaSoft}`, animation: 'mm-rotate 18s linear infinite' }}/>
    <div style={{ position: 'absolute', inset: 18, borderRadius: '50%', border: `1px dashed ${MM2.rosePale}`, animation: 'mm-rotate 12s linear infinite reverse' }}/>
    <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <svg width={size * 0.42} height={size * 0.42} viewBox="0 0 100 100">
        <path d="M50 20 C30 25, 20 45, 25 70 C50 75, 70 55, 75 30 C65 22, 55 20, 50 20 Z" fill={MM2.matcha} opacity="0.85"/>
        <path d="M30 65 Q45 55, 65 35" stroke="#fff" strokeWidth="1.5" fill="none" opacity="0.6"/>
        <circle cx="50" cy="50" r="2" fill={MM2.deep}/>
      </svg>
    </div>
    <div style={{ position: 'absolute', bottom: -22, left: '50%', transform: 'translateX(-50%)', fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: MM2.muted, letterSpacing: '0.15em', whiteSpace: 'nowrap' }}>{label}</div>
  </div>
);

// Country flag chip helper
const CountryFlag = ({ code = 'jp', size = 18 }) => {
  const flags = {
    jp: '🇯🇵', kr: '🇰🇷', us: '🇺🇸', tw: '🇹🇼', uk: '🇬🇧', fr: '🇫🇷', it: '🇮🇹', cn: '🇨🇳', ca: '🇨🇦',
  };
  return <span style={{ fontSize: size }}>{flags[code] || '🌍'}</span>;
};

Object.assign(window, {
  MM2, StatusBar2, HomeIndicator2, Phone2, TabBar2, CityMap2, WorldMap2, MatchaPin2, GradeChip2, LottiePlaceholder, CountryFlag
});
